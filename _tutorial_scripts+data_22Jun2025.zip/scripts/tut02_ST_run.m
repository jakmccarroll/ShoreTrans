%% Victorian ShoreTrans (VST) model - Tutorial-02 --> Run ShoreTrans for select profiles (Apr 2025)
% run profiles in "tut01_prep_classify.m" first

% rmpath(genpath('C:\Dropbox'))
% rmpath(genpath('C:\Matlab'))
close all, clear all; clc ;

warning off ;
fontsz = 11 ;   % set default fontsize for images

Dir.tutorial = 'C:\Dropbox\_UoM\PUBS_UoM\paper3_VIC_ShoreTrans\tutorial'  ;    % tutorial folder --> replace with local file path
addpath(genpath(Dir.tutorial)) ;

Dir.tut_data = fullfile(Dir.tutorial, 'data') ;
Dir.images = fullfile(Dir.tutorial, 'images') ;  mkdir(Dir.images) ;

Dir.ST_funs = 'C:\Dropbox\7_MODELS\013_ShrTrns\functions' ; % set path for ShoreTrans functions --> in data repository "code_2_ShoreTrans" folder
addpath(Dir.ST_funs) ;


%% LIST OF PROFILE ID's (UID) FOR TUTORIAL

UID_ind = [9000; ...   % 1. 90-Mile - high dune
    10500; ...         % 2. 90-Mile - low-backed dune
    35115; ...         % 3. Dromana - low-energy  
    44444; ...         % 4. Ocean Grove - bluff
    45760; ...         % 5. Demons Bluff - cliff  
    47880 ; ...        % 6. Apollo Bay - seawall
    48030 ];           % 7. Marengo - low-backed dune (crest lower than adaptative dune translation pt elevation [7 m])


%% LOAD [PREPARED + CLASSIFIED] PROFILE (UID) 
% run profiles in "tut01_prep_classify.m" first

% UID1 = 35115  ;   % INPUT A PROFILE ID (UID) from the above "LIST OF PROFILE ID's"

UID1 = UID_ind(7) ;  % INPUT [1 -7] to select from the above "LIST OF PROFILE ID's"
fname = ['prof_prep_UID' num2str(UID1, '%05d') '.mat'] ;
cd(Dir.tut_data) ;
load(fname) ;
openvar('prof') ;


%% OPTIONS: Long-term variability (uncertainty bounds)

OPT_LTV.DoC_rng  =  0.1 ;   %  DoC uncert range (std as ratio to the mean. 10% std rng ~= 20% of 95% CIs)	
OPT_LTV.dS_rng  =  0.2 ;   %    SLR uncert range
OPT_LTV.dV_input_rng  =  0.2 ;   %    dV_input uncert range	
OPT_LTV.cliff_REC0_rng  = 0.3  ;   %   cliff recession uncert rng	


%% SHORETRANS (1) --> SETUP OPTIONS (use inputs from [prof] )

clc
[OPT_ST0] = VST_ST_setup(prof) ;
openvar('OPT_ST0') ;


%% SHORETRANS (2) --> RUN PROFILE TRANSLATION (MEAN ESTIMATE)

x0 = prof.x0 ;
z0 = prof.z0 ;
[outProf1,OUTPROF1, OPT_ST1] = ST_MAIN(x0, z0, OPT_ST0.dV_input , OPT_ST0)  ;

z1 = outProf1.z_final; % translated profile
z1_rock = outProf1.z_NE ;  
ST_good = outProf1.good_run ;


%% GET LOW-HIGH RANGE UNCERTAINTY BOUNDS FOR INPUTS

[varb] = VST_ST_uncert_bounds(OPT_ST0, OPT_LTV)  ;
openvar('varb') ;


%% SHORETRANS (3) -->> RUN LOW-RANGE SCENARIO
k = 1 ;

OPT = OPT_ST0 ;
OPT.DoC = varb.DoC(k) ;
OPT.dS = varb.dS(k) ;
OPT.dV_input = varb.dV_input(k) ;
OPT.cliff_REC_rate0 = varb.cliff_REC_rate0(k) ;
warning('off') ;
[outProf_lo,~, OPT_lo] = ST_MAIN(x0, z0, OPT.dV_input , OPT) ;

z1_lo = outProf_lo.z_final; % translated profile
z1_rock_lo = outProf_lo.z_NE ;


%% SHORETRANS (4) -->> RUN LOW-RANGE SCENARIO
k = 3 ;

OPT = OPT_ST0 ;
OPT.DoC = varb.DoC(3) ;
OPT.dS = varb.dS(3) ;
OPT.dV_input = varb.dV_input(3) ;
OPT.cliff_REC_rate0 = varb.cliff_REC_rate0(3) ;
warning('off') ;
[outProf_hi,~, OPT_hi] = ST_MAIN(x0, z0, OPT.dV_input , OPT) ;

z1_hi = outProf_hi.z_final; % translated profile
z1_rock_hi = outProf_hi.z_NE ;


%% PLOT02 ---> TRANSLATED PROFILE --> MEAN SCENARIO
run_str = 'run040' ;
figs_vis = 'on' ;
zones = prof.zones ;
smry = prof.smry ;
Trend = prof.Trend ;

tut_plot02_ST_output


%% PLOT03 ---> TRANSLATED PROFILE --> w/ LOW/HIGH RANGE UNCERTAINTY BOUNDS

tut_plot03_ST_uncert_lo_hi









%%








