%% VST - TUTORIAL --> MAKE CROPPED DATA FILES


HST_Dir

Dir.tutorial = 'C:\Dropbox\_UoM\PUBS_UoM\paper3_VIC_ShoreTrans\tutorial'  ;    % replace with local file path
addpath(genpath(Dir.tutorial)) ;

Dir.tut_data = fullfile(Dir.tutorial, 'data') ;
Dir.images = fullfile(Dir.tutorial, 'images') ;

%% SETUP + LOAD

if ~exist('omni', 'var')
    FATB_load_omni
end

%% UID INDEX [UID_ind]

UID_ind = [9000; ...   % 90-Mile - high dune
    10500; ...         % 90-Mile - low-backed dune
    35115; ...         % Dromana - low-energy  
    44444; ...         % Ocean Grove - bluff
    45760; ...         % Demons Bluff - cliff  
    47880 ; ...        % Apollo Bay - seawall
    48030 ];           % Marengo - Dune (low crest)   ---> no back-toe, classified as 'dune-high'


%% SHR --> CROP TO [SHR1] --> SELECT UIDs

shr1 = [] ;

shr1.UID = UID_ind ;
shr1.x   = shr.x(UID_ind) ;
shr1.y   = shr.y(UID_ind) ;
shr1.xT2 = shr.xT2(UID_ind, :) ;
shr1.yT2 = shr.yT2(UID_ind, :) ;
shr1.Trend = shr.Trend(UID_ind) ;

cd(Dir.tut_data) ;
save('tut_shr1.mat', 'shr1') ;

%% SHR --> CROP TO [SHR0] --> FULL VIC --> Just x,y-coords

shr0 = [] ;
shr0.UID = shr.UID ;
shr0.x   = shr.x ;
shr0.y   = shr.y;

cd(Dir.tut_data) ;
save('tut_shr0.mat', 'shr0') ;

%% XS --> CROP to [xs1] --> SELECT UIDS

xs1 = [] ;
xs1 = xs(UID_ind) ;
cd(Dir.tut_data) ;
save('tut_xs1.mat', 'xs1') ;

%% SMART --> [SMART1]

smart = omni.smrt ;
try,        smart = rmfield(smart, 'ind_smrt_xy2n') ; end   % BIG ARRAY (4M x 1) --> remove to reduce final file size

smart1 = smart ;

fn = fieldnames(omni.smrt) ;
Len = length(omni.smrt.x) ;
for k = 1 : length(fn)
    field1 = omni.smrt.(fn{k}) ;
    if length(field1) == Len
        smart1.(fn{k}) = field1(UID_ind) ;
    end
end

cd(Dir.tut_data) ;
save('tut_smart1.mat', 'smart1') ;

%% DoC --> [DoC1]  - includes wave stats

% openvar('DoC')
DoC1 = DoC ;

fn = fieldnames(DoC) ;
Len = length(DoC.UID) ;
for k = 1 : length(fn)
    field1 = DoC.(fn{k}) ;
    if length(field1) == Len
        DoC1.(fn{k}) = field1(UID_ind) ;
    end
end
% openvar('DoC1')

cd(Dir.tut_data)     ;
save('tut_DoC1.mat', 'DoC1') ;

%% geol --> [geol1] - includes wave stats

% openvar('geol')
geol1 = geol ;

fn = fieldnames(geol) ;
Len = length(geol.UID) ;
for k = 1 : length(fn)
    % k = 
    field1 = geol.(fn{k}) ;
   
    if istable(field1)
        geol1.(fn{k}) = field1(UID_ind,:) ;        
    elseif length(field1) == Len
        geol1.(fn{k}) = field1(UID_ind,:) ;
    end
end
% openvar('geol1')

cd(Dir.tut_data)     ;
save('tut_geol1.mat', 'geol1') ;

%%







%%




%%




%%





%%




%%