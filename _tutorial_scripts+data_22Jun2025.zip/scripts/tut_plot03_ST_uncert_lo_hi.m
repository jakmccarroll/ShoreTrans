

%% PLOT3 --> PLOT SHORETRANS OUTPUT --> LOW/HIGH UNCERTAINTY BOUNDS

x0 = prof.x0 ;
z0 = prof.z0 ;

z0_rock = prof.z_rock ;            
z1_rock = outProf1.z_NE ;
CAMi = prof.CAMi ;

SL1 = OPT.S_initial;

z1_lo       = z1_lo     ;
z1_av       = z1       ;
z1_hi       = z1_hi   ;

SL2_lo1  = OPT_lo.S_final ;        
SL2_hi1 = OPT_hi.S_final ;

DoC1_lo1 = OPT_lo.DoC ;            
DoC1_hi1 = OPT_hi.DoC ;     
DoC1_hi_ind = OPT_hi.DoC_ind ;

dV_lo1 = outProf_lo.dV ;
dV_av1 = outProf1.dV ;
dV_hi1 = outProf_hi.dV ;

dX_lo1 = outProf_lo.R_sh ;
dX_av1 = outProf1.R_sh ;
dX_hi1 = outProf_hi.R_sh ;      



%% [VARB] PLOT03 --> PREP OUTPUT VARS


fill_x1      = [x0; flipud(x0)] ;
fill_z1     = [z1_lo; flipud(z1_hi)] ;

fill_x2     = [x0(1) x0(end) x0(end) x0(1)] ;
fill_SL2    = [SL2_lo1 SL2_lo1 SL2_hi1 SL2_hi1] ;
fill_DoC1   = [DoC1_lo1 DoC1_lo1 DoC1_hi1 DoC1_hi1 ] ;

title1 = ['Flexi-' run_str '-Plot3: ShoreTrans Uncert Bounds, UID-' num2str(UID1) 10 ...
    'Low:  DoC = ' varb.DoC_str(1,:) ' m, SLR = ' varb.dS_str(1,:) ' m, ' ...
    'dV-input = ' varb.dV_str(1,:) ' m^3, dV-final = ' num2str(dV_lo1, '%0.0f') ' m^3, dX = ' num2str(dX_lo1, '%0.0f') ' m' 10 ...
    'Mid:  DoC = ' varb.DoC_str(2,:) ' m, SLR = ' varb.dS_str(2,:) ' m, ' ...
    'dV-input = ' varb.dV_str(2,:) ' m^3, dV-final = ' num2str(dV_av1, '%0.0f') ' m^3, dX = ' num2str(dX_av1, '%0.0f') ' m' 10 ...
    'High: DoC = ' varb.DoC_str(3,:) ' m, SLR = ' varb.dS_str(3,:) ' m, ' ...
    'dV-input = ' varb.dV_str(3,:) ' m^3, dV-final = ' num2str(dV_hi1, '%0.0f') ' m^3, dX = ' num2str(dX_hi1, '%0.0f') ' m'] ;

xlim1(1) = min(x0) + 100     ;     xlim1(2) = max(x0) - 500 ;
if ~isnan(DoC1_hi1)
    ylim1(1) = DoC1_hi1 - 6;
elseif ~isnan(DoC1_lo1)
    ylim1(1) = DoC1_lo1 - 8; 
else
    ylim1(1) = -10 ;
end

ylim1(2) = max(z0) + 4 ;


%% ROCK FILL SETUP [FILL Z0-ROCK ABOVE Z1-ROCK (full depth) ]


fill_x0          = [x0; flipud(x0)] ;
fill_z0_rock     = [z1_rock ; flipud(z0_rock)] ;  % fills any gap between Z0-ROCK and Z1-ROCK
R0_alpha = 0.25 ;

fill_z1_rock     = [ylim1(1) .* ones(size(x0)) ; flipud(z1_rock)] ;
R1_alpha = 0.3 ;


%% PLOT03 --> ST-OUT UNCERT BOUNDS

try, close(f3), end
f3 = figure('visible', figs_vis);
figpos(0,.2,.5,.5), hold on , grid off ;
title(title1, 'fontsize', fontsz - 1, 'fontweight', 'normal')  ;

legend(gca, '-dynamicLegend', 'location', 'northeast') ;

% FILL Z0-ROCK (above Z1-ROCK)
try
R0 = fill(fill_x0, fill_z0_rock, [.8 .8 .8], 'displayname', 'z0-rock', 'edgecolor', [.6 .6 .6]) ;
alpha(R0, R0_alpha)

R1 = fill(fill_x0, fill_z1_rock, [.6 .6 .6], 'displayname', 'z1-rock', 'edgecolor', [.4 .4 .4]) ;
alpha(R1, R1_alpha)
end

plot([x0(1) x0(end)], [SL1 SL1], 'b-', 'displayname', 'SL-1');
% plot(x0, z0_rock, ':', 'color', [.7 .5 .3], 'displayname', 'z0-rock') ;

F2 = fill(fill_x2, fill_DoC1, [.70 .35 .90], 'displayname', 'DoC1-uncert-rng', 'edgecolor', [.70 .35 .90]) ;
alpha(F2, 0.2)
F3 = fill(fill_x2, fill_SL2, [.3 .7 .95], 'displayname', 'SL2-uncert-rng', 'edgecolor', [.3 .7 .95]) ;
alpha(F3, 0.2)

F1 = fill(fill_x1, fill_z1, [.90 .85 .80], 'displayname', 'z1-uncert-rng', 'edgecolor', [.90 .85 .80]) ;
alpha(F1, 0.2)

plot(x0, z0, 'k', 'displayname', 'z0-initial', 'linewidth', 1) ;
plot(x0, z1_lo, ':', 'color', [.1 .4 .9],'displayname', 'z1-lo', 'linewidth', 1.5) ;
plot(x0, z1_av, '-', 'color', [.3 1 .2], 'displayname', 'z1-av', 'linewidth', 2) ;
plot(x0, z1_hi, '-.', 'color', [.9 .1 .3],'displayname', 'z1-hi', 'linewidth', 1.5) ;

try
if smry.wall_on
    plot( [x0(OPT_ST1.wall_ind) x0(OPT_ST1.wall_ind)], [-2 5], 'color', [.6 0 .6],'linewidth', 2, 'displayname', 'wall')
end
end

xlabel('Cross-shore distance (m)') ;            
ylabel('Elevation (m, AHD)') ;
xlim(xlim1) ;              ylim(ylim1) ;

xlim([200 1000])  ;


%% SAVE IMAGE
cd(Dir.images)
fname = [num2str(UID1, '%05d') '_plot03_uncert_lo_hi.png'] ;
print(fname, '-dpng', '-r100') ;



%%
