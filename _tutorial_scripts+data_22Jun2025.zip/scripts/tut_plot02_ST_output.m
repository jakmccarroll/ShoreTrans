%% PLOT02 ---> ST OUTPUT

x0 = prof.x0 ;            
z0 = prof.z0 ;
z0_rock = prof.z_rock ;            
z1_rock = outProf1.z_NE ;
CAMi = prof.CAMi ;

ST_good1 = outProf1.good_run ;


%% GET EXTRA VARS [IF ST_GOOD]

if ST_good1
    dV_input = OPT_ST1.dV_input ;
    dV_input_per_yr = prof.Trend.m3_yr  ;
    ToCr_ind = OPT_ST1.toeCrest_ind  ;
    SL0 = OPT_ST1.S_initial;
    dS = OPT_ST1.dS ;
    SL1 = SL0 + OPT_ST1.dS ;
    DoC1 = OPT_ST1.DoC ;

    wall_ind = OPT_ST1.wall_ind ;

    dV_in_str = num2str(dV_input, '%0.0f') ;
    dV_tot_str = num2str(outProf1.dV, '%0.0f') ;
    dV_err_str = num2str(outProf1.dV_error, '%0.1f') ;

    cliff_str = OPT_ST1.cliff_str  ;

    cliff_dX1 = outProf1.cliff_dX ;
    dX1 = outProf1.R_sh ;

else
    dV_input = [] ;
    dV_input_per_yr = [] ;
    ToCr_ind = nan  ;
    SL0 = nan ;
    dS = nan ;
    SL1 = nan ;
    DoC1 = nan ;
    wall_ind = nan ;    

    cliff_dX1 = nan ;
    dX1 = nan ;

    dV_in_str = 'nan' ;
    dV_tot_str = 'nan' ;
    dV_err_str = 'nan' ;
    cliff_str = 'nan' ;
end


%% PLOT02 --> SETUP

cm1 = jet(length(zones)) .* 0.8 ;

xlim1(1) = 200 ;
xlim1(2) = 1100 ;

ylim1(1) = min(z0) - 2 ; ylim1(2) = max(z0) + 2 ;

smrt_str = ['CLF-smrt = ' num2str(smry.CLF_smart) ' | CLF-detect = ' num2str(smry.CLF_detect) ' | CLF-TT = ' num2str(smry.CLF_TT) ... 
        '   |   CLF-switch = ' num2str(smry.CLF_switch)  '  |   BLUFF-switch = ' num2str(smry.BLUFF_switch) ...
    '    |    RIDGE-switch = ' num2str(smry.RIDGE_switch) '    |     ' 10 ...
    'INT1-smrt = ' num2str(smry.INT1_smart) '   |   INT2-smrt = ' num2str(smry.INT2_smart)  ...
    '   |   SUB1-smrt = ' num2str(smry.SUB1_smart) '   |   SUB2-smrt = ' num2str(smry.SUB2_smart) ...
    '   |   SUB-detect = ' num2str(smry.SUB_detect) '   |   ToCr-opt[1,2,3] = ' num2str(smry.ToCr_opt) '   |   wall = ' num2str(smry.wall_on) 10 ...
    ' Cliff-rate-0 = ' num2str(smry.CLF_TT_rate ) ' m/yr   |   Cliff-name: ' cliff_str  ] ;


%% ROCK FILL SETUP [FILL Z0-ROCK ABOVE Z1-ROCK (full depth) ]

fill_x0          = [x0; flipud(x0)] ;
fill_z0_rock     = [z1_rock ; flipud(z0_rock)] ;  % fills any gap between Z0-ROCK and Z1-ROCK
F0_alpha = 0.12 ;

fill_z1_rock     = [ylim1(1) .* ones(size(x0)) ; flipud(z1_rock)] ;
F1_alpha = 0.25 ;

%% PLOT02 --> RUN PLOT
try, close(f2), end
f2 = figure('visible', figs_vis)  ;
figpos(0.2, .05, .7, .5);           hold on , grid off ;
title(['Flexi-' run_str '-Plot2: ShoreTrans Output Profile, UID-' num2str(UID1) '  |          ST-good = ' num2str(ST_good1) 10 ...
    'SLR = ' num2str(dS) ' m     |     trend = ' num2str(Trend.m_yr_sm, '%0.2f') ' m/yr ' ...
    '   |    sediment budget = ' num2str(dV_input_per_yr, '%0.2f') ' m^3/m/yr     |   '  ...
    'dV-input = ' dV_in_str ' m^3/m' 10 ...
    'dV-final = ' dV_tot_str ' m^3/m, dV-error = ' dV_err_str ' m^3/m'  ...
    ', cliff-rec-dist. = ' num2str(cliff_dX1, '%0.0f') ' m' ...
    ', shore recess. dist. = ' num2str(dX1) ' m'  10 ...
    smrt_str], 'fontsize', fontsz - 1, 'fontweight', 'normal')  ;

legend(gca, '-dynamicLegend', 'location', 'southwest') ;

try
% FILL Z0-ROCK (above Z1-ROCK)
F0 = fill(fill_x0, fill_z0_rock, [.6 .5 .2], 'displayname', 'z0-rock', 'edgecolor', [.7 .6 .3]) ;
alpha(F0, F0_alpha)

F1 = fill(fill_x0, fill_z1_rock, [.7 .3 .1], 'displayname', 'z1-rock', 'edgecolor', [.9 .4 .2]) ;
alpha(F1, F1_alpha)
end

plot([x0(1) x0(end)], [SL0 SL0], 'b-', 'displayname', 'SL-0', 'linewidth', 0.5);
plot([x0(1) x0(end)], [SL1 SL1], 'b--', 'displayname', 'SL-1', 'linewidth', 0.5);
plot([x0(1) x0(end)], [DoC1 DoC1], '-.', 'displayname', 'DoC-1', 'color', [0.7 .3 .8] , 'linewidth', 1);


plot([x0(CAMi) x0(CAMi)], [z0(CAMi)-5 z0(CAMi)+5], '-', 'linewidth', 3, 'color', [.6 .5 .8], 'displayname', 'CAMS-structure') ;

plot(x0, z0, 'k', 'displayname', 'z0-initial', 'linewidth', 1.5) ;
plot(x0, z1, '--', 'displayname', 'z1-final', 'linewidth', 2, 'markersize', 3, 'color', [.3 .6 .2]) ;

try
    plot(x0(ToCr_ind), z0(ToCr_ind), 'kp', 'displayname',  'ST-TransPt', 'markersize', 8, 'markerfacecolor', 'y', 'linewidth', 1) ;
end

try
if smry.wall_on
    plot( [x0(wall_ind) x0(wall_ind)], [-2 5], 'color', [.6 0 .6],'linewidth', 2, 'displayname', 'wall')
end
end

xlabel('Cross-shore distance (m)') ;
ylabel('Elevation (m, AHD)') ;
xlim(xlim1) ; ylim(ylim1) ;


%% SAVE IMAGE
cd(Dir.images)
fname = [num2str(UID1, '%05d') '_plot02_ST-OUT.png'] ;
print(fname, '-dpng', '-r200') ;




%%
