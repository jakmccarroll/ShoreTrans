%% Victorian ShoreTrans (VST) model - Tutorial-01 --> Prepare and classify morphology of profile (Apr 2025)

% rmpath(genpath('C:\Dropbox'))
% rmpath(genpath('C:\Matlab'))
close all, clear all; clc ;

warning off ;
fontsz = 11 ;   % set default fontsize for images

Dir.tutorial = 'C:\Dropbox\_UoM\PUBS_UoM\paper3_VIC_ShoreTrans\tutorial'  ;    % replace with local file path

addpath(genpath(Dir.tutorial)) ;

Dir.tut_data = fullfile(Dir.tutorial, 'data') ;
Dir.images = fullfile(Dir.tutorial, 'images') ;  mkdir(Dir.images) ;


Dir.ST_funs = 'C:\Dropbox\7_MODELS\013_ShrTrns\functions' ; % ShoreTrans functions --> in data repository "code_2_ShoreTrans" folder
addpath(Dir.ST_funs) ;


%% LOAD DATA
cd(Dir.tut_data) ;
load('tut_shr1', 'shr1') ;               % select transects (shoreline point [x,y], transect points [xT2, yT2], shoreline trend - [Trend] from DEA-C(2023) )
load('tut_shr0', 'shr0') ;               % base shoreline for Victoria (DEA-C-2019, gaps filled with SmartLine)
load('tut_xs1.mat', 'xs1');              % cross-sections
load('tut_smart1.mat', 'smart1');        % SmartLine morphology
load('tut_CAMS.mat', 'CAMS') ;           % CAMS (Coastal Asset Management System) - database of coastal protection structures (DEECA Vic, 2022)
load('tut_DoC1.mat', 'DoC1') ;           % Depth of Closure (derived with VanRijn-2014 + Wave Statistics - VIC hindcast model (Liu et al., 2022)
load('tut_geol1.mat', 'geol1') ;           % Geology - cliff recession rates (Tonkin and Taylor, 2023)


%% LIST OF PROFILE ID's (UID) FOR TUTORIAL

UID_ind = [9000; ...   % 1. 90-Mile - high dune
    10500; ...         % 2. 90-Mile - low-backed dune
    35115; ...         % 3. Dromana - low-energy  
    44444; ...         % 4. Ocean Grove - bluff
    45760; ...         % 5. Demons Bluff - cliff  
    47880 ; ...        % 6. Apollo Bay - seawall
    48030 ];           % 7. Marengo - low-backed dune (crest lower than adaptative dune translation pt elevation [7 m])


%% SELECT PROFILE (UID) TO CLASSIFY

% UID1 = 35115  ;   % INPUT A PROFILE ID (UID) from the above "LIST OF PROFILE ID's"

UID1 = UID_ind(1) ;  % INPUT [1 -7] to select from the above "LIST OF PROFILE ID's"

% Get profile data --> [prof]
[prof] = VST_get_prof(UID1, shr1, xs1 ) ;
openvar('prof') ;

%% SET OPTIONS (1) --> CLASSIFICATION AND SHORETRANS SETTINGS

% OPTIONS: SEA LEVEL RISE
OPT_SLR.SL0 = 0 ;  % initial sea level (m AHD)
OPT_SLR.dS_dt0 = 0.0003 ; % initial rate of SLR	(m/yr)
OPT_SLR.dS  = 1 ;  % total SLR	(m)
OPT_SLR.dt  = 90 ;  % time period (years - over which total SLR occurs)	

% OPTIONS: Check profile (good/bad)
OPT_CHK = []  ;            % if any [z-values > 0] offshore of [max_x_shr]
OPT_CHK.max_x_shr = 400 ;      %  -->> set profile to bad (profile stays above MSL, or rises up offshore)

% OPTIONS: Extend profile (onshore + offshore) 
% --> (prevents model errors, extensions should be outside range of profile change)
OPTX = [] ;
OPTX.ext_on_m = 300 ;   % offshore extend length (m, 0.01 slope)
OPTX.ext_off_m = 300 ;  % onshore extend length (m, flat level)

% OPTIONS: ZONES --> set base elevations for defining intertidal zone
OPTZ.toe_z = 2.5 ;      % base of dune toe elevation
OPTZ.int_base_z = -1 ;  % base of intertidal zone 

% OPTIONS: Depth of Closure (DoC) ---------> inc. setting for LOW-ENERGY profiles (BeachFace method)
OPT_DoC = [] ;
OPT_DoC.DoC_BF_z = -0.5 ;       % base of BeachFace (BF) --> max elevation to set DoC if profile is low energy, and a deeper DoC is not found
OPT_DoC.BF_slope_thresh = 0.01 ;    % Set a threshold slope (e.g., 0.01) --> once it gets flatter than this, set the DoC_BF
OPT_DoC.toe_z   = OPTZ.toe_z ;           % dune toe elevation (standard base level)                        
OPT_DoC.toe_z_low_E   = 2 ;              % dune toe elevation for low energy profiles
OPT_DoC.int_base_z = OPTZ.int_base_z ;    % base of intertidal zone 
OPT_DoC.slope_smooth_span = 50 ;   % moving average span when finding where the profile flattens out (smooths over bars)
OPT_DoC.Hb_thresh  = 0.4 ;          % avg breaking wave ht --> values below this are classed 'LOW ENERGY'

% OPTIONS: Dune Toe / Crest settings
OPT_ToCr.To_z_lvl = OPTZ.toe_z ;    %  Toe z level
OPT_ToCr.Bk_z_lvl = 2 ;             % Back-toe z level
OPT_ToCr.Cr_z_max = 7 ;             %  Crest max elevation   == ADAPTIVE DUNE TRANSLATION POINT ELEVATION
OPT_ToCr.Cr_flat_top_w = 10 ;       %  Crest width (flat top)
OPT_ToCr.Cr_x_rng = 200 ;           %  Range to look for crest onshore from toe

%% SET OPTIONS (2) --> CLASSIFICATION AND SHORETRANS SETTINGS
% OPTIONS: Cliff settings
OPTC.min_ang =  30 ;              % min angle to be classed as cliff
OPTC.min_clf_ht = 5 ;          % min cliff ht
OPTC.gap_max = 5  ;          % max gap in slope section
OPTC.To_z =   OPTZ.toe_z   ;        % cliff toe elevation (initial)
OPTC.To_slp_chk =  1    ;        % Additional check to ensure TOE is offshore of steep section [1 - ON (default) ; 2 - OFF ]
OPTC.To_min_ind_unext = 100    ;        % MIN INDEX (of x0 position) to search for TOE (not inc. prof extension)
OPTC.To_max_ind_unext = 300   ;         %  MAX INDEX to search for TOE
OPTC.Cr_rng = 100       ;     % X-shore RANGE to seach for CREST (onshore of initial toe detection pt)
OPTC.cons_ratio_H = 0.5  ;          % cliff conservation ratio (HARD cliff)
OPTC.cons_ratio_S = 0.25  ;          % cliff conservation ratio (SOFT cliff)
OPTC.dV_input_cliff = 1  ;          % Adjust dV_input to account for [dV-cliff] input [1=ON; 0=OFF];
OPTC.dV_cliff_adjust = 1 ;           % Reduce the full [dV_cliff] by this factor (otherwise too much erosion back to rock)
OPTC.TT_rate_meth = 2  ;          % T+T REC0 value + uncert method , [1 = avg of T+T-mean , T+T-5%], [2 - T+T 'mean rate'] 

% OPTIONS: Subtidal rock outcrops
OPTR.st_z  =  -1   ;     %   start of subtidal zone (elevation)
% OPTR.st_i  =  []   ;   %   start of subtidal zone (index)
OPTR.X_ind_min  = 400    ;   %   minimum X-ind start point
% OPTR.en_z  =  []   ;   %   end of subtidal zone (elevation)
% OPTR.en_i  =  []   ;   %   end of subtidal zone (index)   ----> USE IF APPLYING ROCK CHECK ONLY TO DoC [i.e., OPT.go_to_end = false]
OPTR.go_to_end  = 1    ;   %   apply rock check to end of profile (if FALSE, do NOT allow rock offshore of OPT.en_i)
OPTR.gap_max  =   100  ;   %   join rock sections with gaps between less than [GAP_MAX]
OPTR.sec_min  =   10  ;   %   delete rock sections with extent less than [SEC_MIN]
OPTR.dz_limit  =   0.08  ;   %   threshold slope per metre cross-shore (above this, class as rock)

% OPTIONS: Bluffs and ridges
OPT_blf.z_av_min    =    12   ;    %   if mean onshore z higher than this (AND NO CLIFF), then a BLUFF will be inserted
OPT_blf.z_for_x_st   =    10   ;    %   if prof dips this level, bluff must start onshore of this point (a peak offshore of this point is likely a dune or RIDGE)
OPT_blf.zW_if_cliff_expect   =  6     ;    %   Bed elevation to insert wall, if cliff expected
OPT_blf.z_ridge_lim   =   20  ;    %   if any part of onshore profile is higher than this --> it gets rock under it 
OPT_blf.dz_surf2rock   =  1.5     ;    %   depth from surface to bluff rock

% OPTIONS: Rock (non-erodible) layer
OPT_RL.rock_depth = 2.5 ;   %	depth-to-rock layer

% OPTIONS: Trend + Sediment Budget
OPT_TnB.sm_span = 11 ;  % moving average span (transects alongshore) for smoothing shoreline trend 

% OPTION: Long-term variability (uncertainty bounds)
OPT_LTV.DoC_rng  =  0.1 ;   %  DoC uncert range (std as ratio to the mean. 10% std rng ~= 20% of 95% CIs)	
OPT_LTV.dS_rng  =  0.2 ;   %    SLR uncert range
OPT_LTV.dV_input_rng  =  0.2 ;   %    dV_input uncert range	
OPT_LTV.cliff_REC0_rng  = 0.3  ;   %   cliff recession uncert rng	


%% CLASSIFICATION 1 - PROFILE PREPARATION, ZONE INDEXING and DoC

% 01 - Check if profile is good/bad
[prof] = VST_prepfun01_prof_check_bad(prof, OPT_CHK) ; 
prof.OPT_CHK = OPT_CHK ;
prof.OPT_SLR = OPT_SLR ;
prof.OPT_LTV = OPT_LTV ;

% 02 - Get SmartLine morphology classification
[smrtC] = VST_prepfun02_get_smart(UID1, smart1)   ;
prof.smrtC = smrtC ;

% 03 - Find intersections with coastal structures (CAMS database, DEECA)
[CAMS_ints] = VS1_CAMS_xs_intersect_fun_COPY(UID1, xs1, CAMS)  ;

% 04 - Extend profile on/offshore (prevents model errors, extensions should be outside range of profile change)
[prof.x0, prof.z0, OPTX] = ST_extend_x0_z0(prof.x00, prof.z00, OPTX)  ;        % ST = ShoreTrans function --> 
[prof, CAMS_ints] = VST_prepfun04_CAMS_int_ext(prof, CAMS_ints, OPTX.ext_on_m ) ;
prof.OPTX = OPTX ;

% 05 - WAVES and DoC1 settings (1) -----> get options for DoC 
[prof, wave1, DoCs] = VST_prepfun05_1_waves_DoC(prof, UID1, DoC1, OPT_DoC) ;

% 06 - CLASSIFY ZONES (backshore, intertidal-1, intertidal-2, subtidal-1, subtidal-2)
OPTZ.sub_base_z = DoCs.sub_base_z ;
[zones, OPTZ] = ST_zones_get_fun(prof.x0, prof.z0, OPTZ)  ;
prof.zones = zones ;
prof.zones_OPT = OPTZ ;

% ---> WAVES and DoC1 settings (2) -----> Set DoC1 for LOW ENERGY profiles (Beachface/slope rules)
[prof, DoCs] = VST_prepfun05_2_DoC_lowE_set(prof, DoCs, OPT_DoC) ;


%% CLASSIFICATION 2 - PROFILE MORPHOLOGY CLASSIFICATION


% 07 - DUNE TOE / CREST indexing
OPT_ToCr.To_z_lvl = prof.toe_z ;    % updated for LOW-E profs in step 05
[prof, ToCr] = VST_prepfun07_ToCr(prof, OPT_ToCr) ;

% 08 - CLIFF DETECTION
[clf, OPTC, prof, clf_TT, clf_calcs] = VST_prepfun08_cliff(UID1, geol1, prof, OPTC)  ;

% 09 - SUBTIDAL ROCK OUTCROP DETECTION
OPTR.en_z = prof.DoC1_Hb ;
[rockInd, OPTR] = ST_rock_auto_classify_subtide(prof.x0, prof.z0, OPTR)  ;
prof.rockInd = rockInd    ;
prof.rockInd_OPT = OPTR    ;

% 10 - BLUFF + RIDGE DETECTION
[bluff, prof] = VST_prepfun10_bluff_ridge(prof, OPT_blf) ;



%% CLASSIFICATION 3 - SUMMARY SETTINGS, MAKE ROCK LAYER, GET TREND

% 11 - PROFILE SUMMARY CLASSIFICATION SETTINGS
[smry, prof] = VST_prepfun11_summary(prof)  ;

% 12 - INTERPRET ROCK LAYER
[z_rock_out, prof] = VST_prepfun12_rocklayer(prof, OPT_RL) ;

% 13 - GET SHORELINE TREND AND SEDIMENT BUDGET
[Trend, prof] = VST_prepfun12_Trend(UID1, shr1, prof, OPT_TnB) ;


%% PLOT PREPARED + CLASSIFIED PROFILE

figs_vis = 'on' ;
run_str = 'run040' ;
tut_plot01_prep_prof


%% SAVE PROFILE CLASSIFICATION --> FOR INPUT TO SHORETRANS [see script "Tut02_run_ST"]

cd(Dir.tut_data) ;
save(['prof_prep_UID' num2str(UID1, '%05d') '.mat'], 'prof') ;





%%























%%




















%%