%% PLOT1    %% FULLY PREPPED w/ (ZONES + ROCKIND + CLIFF TOE/TOP)

%% GET VARS

x0 = prof.x0 ;        z0 = prof.z0 ;

% z_rock_sub = prof.rockInd.z1 ;
z_rock = prof.z_rock ;
clf_To_ind = clf.To_ind ;           clf_Cr_ind = clf.Cr_ind ;

ToCr_1 = ToCr.Bk_ind ;             ToCr_2 = ToCr.Cr_ind ;
ToCr_3 = ToCr.To_ind ;             ToCr_ST = ToCr.ST_ToCr_ind ;

CAMi = prof.CAMi ;
DoC1 = -prof.DoC1_select ;

prof_good1 = prof.prof_good ;


%% SMART_STR
smrt_str = ['CLF-smrt = ' num2str(smry.CLF_smart) ' | CLF-detect = ' num2str(smry.CLF_detect) ' | CLF-TT = ' num2str(smry.CLF_TT) ...
    '   |   CLF-switch = ' num2str(smry.CLF_switch) ...
    '    |    BLUFF-found = ' num2str(bluff.found)  '  |   BLUFF-switch = ' num2str(smry.BLUFF_switch) ...
    '    |    RIDGE-switch = ' num2str(smry.RIDGE_switch) '    |     ' 10 ...
    'INT1-smrt = ' num2str(smry.INT1_smart) ' | INT2-smrt = ' num2str(smry.INT2_smart) '  |   ' ...
    'SUB1-smrt = ' num2str(smry.SUB1_smart) ' | SUB2-smrt = ' num2str(smry.SUB2_smart) ...
    ' | SUB-detect = ' num2str(smry.SUB_detect) '   |   ToCr-opt[1,2,3] = ' num2str(smry.ToCr_opt) ' | wall = ' num2str(smry.wall_on) ] ;

%% SETUP PLOT [CMAP, XY-LIMS, rock-fill area]
cm1 = jet(length(zones)) .* 0.8 ;
xlim1(1) = min(x0) ;     xlim1(2) = max(x0) ;
ylim1(1) = min(z0) - 2 ; ylim1(2) = max(z0) + 2 ;

fill_x0          = [x0; flipud(x0)] ;
fill_z_rock     = [ylim1(1) .* ones(size(x0)) ; flipud(z_rock)] ;
F1_alpha = 0.1 ;

%% PLOT01 ---> RUN PLOT
try, close(f1), end
f1 = figure('visible', figs_vis)  ;
figpos(0.0, 0.4,.7,.5); hold on , grid off ;
title(['Flexi-' run_str '-Plot1: Prepped-Profile, UID-' num2str(UID1) '  |  prof-GOOD = ' num2str(prof_good1) ...
    '  |  Trend = ' num2str(Trend.m_yr_sm, '%0.2f') ' m/yr, ' ...
    'Budget = ' num2str(Trend.m3_yr, '%0.2f') ' m^3/yr' 10 ...
    smrt_str], 'fontsize', fontsz - 1)  ;

legend(gca, '-dynamicLegend', 'location', 'northeast') ;
% plot(x0, z_rock, ':', 'color', [1 .5 .3], 'displayname', 'z-rock') ;
F1 = fill(fill_x0, fill_z_rock, [.7 .3 .1], 'displayname', 'z0-rock', 'edgecolor', [.9 .4 .2]) ;
alpha(F1, F1_alpha)

plot(x0, z0, 'k', 'displayname', 'z0', 'linewidth', 1) ;
plot([x0(1) x0(end)], [0 0], 'b:', 'displayname', 'MSL', 'linewidth', 1) ;

plot([x0(CAMi) x0(CAMi)], [z0(CAMi)-5 z0(CAMi)+5], '-', 'linewidth', 3, 'color', [.6 .5 .8], 'displayname', 'CAMS-structure') ;

for k = 1 : length(zones)   % ZONES - INDEXES
    % ind = zones(k).ind ;
    ind = [zones(k).st_i : zones(k).en_i] ;
    if ~isempty(ind)
        plot(x0(ind), z0(ind), ':', 'color', cm1(k,:), ...
            'displayname', zones(k).name, 'linewidth', 4) ;

    end
end

if smry.CLF_detect
    plot(x0(clf_To_ind), z0(clf_To_ind), 'rs', 'markersize', 10, 'displayname', 'Cliff-toe') ;
    plot(x0(clf_Cr_ind), z0(clf_Cr_ind), 's', 'color', [0 .6 .1], 'markersize', 10, 'displayname', 'Cliff-crest') ;
end

% TOE-CREST IND [1,2,3] ---> UPDATE VERSION (DEC 2024)
plot(x0(ToCr_1), z0(ToCr_1), 'ko', 'displayname',  'Dune-Bk-ind', 'markersize', 10, 'markerfacecolor', 'y') ;
plot(x0(ToCr_2), z0(ToCr_2), 'co', 'displayname',  'Dune-Cr-ind', 'markersize', 10) ;
plot(x0(ToCr_3), z0(ToCr_3), 'bo', 'displayname',  'Dune-To-ind', 'markersize', 10) ;

try
plot(x0(ToCr_ST), z0(ToCr_ST), 'ko', 'displayname',  'Dune-select-ind', 'markersize', 8, 'markerfacecolor', 'r') ;
end

plot([xlim1], [0 0], '-', 'color', [.2 .2 .6], 'linewidth', 1, 'displayname', 'MSL0') ;
plot([xlim1], [DoC1 DoC1], '-.', 'color', [.2 .6 .6], 'linewidth', 1.5, 'displayname', 'DoC1') ;

xlabel('Cross-shore distance (m)') ;            ylabel('Elevation (m, AHD)') ;
xlim(xlim1); ylim(ylim1) ;

%% SAVE IMAGE
cd(Dir.images)
fname = [num2str(UID1, '%05d') '_plot01_prep.png'] ;
print(fname, '-dpng', '-r200') ;




%%



%%
