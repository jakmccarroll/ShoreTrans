%% VST_prepfun04_CAMS_int_ext --> if coastal structure intersection found, apply profile extension  --> APR 2025
% First run ShoreTrans profile extension: [prof.x_ext, prof.z_ext, OPTX] = ST_extend_x0_z0(prof.x00, prof.z00, OPTX)  ;
%
% Inputs: 
% --> [prof] structure --> as outputted from [VST_prepfun01_prof_check_bad]
% --> CAMS_ints - coastal structure intersections (see [VS1_CAMS_xs_intersect_fun] )
% --> ext_on_m  - onshore extension distance (m)


function [prof, CAMS_ints] = VST_prepfun04_CAMS_int_ext(prof, CAMS_ints, ext_on_m) 

if CAMS_ints.int_found
    CAMS_ints.X_ext_ind = CAMS_ints.X_back_ind + ext_on_m ;
else
    CAMS_ints.X_ext_ind = [] ;
end

% CAMS adjust INDEX TO EXTENDED PROF
prof.CAMS_ints = CAMS_ints ;
prof.CAMi = max(CAMS_ints.X_ext_ind) ;
prof.wall_i = max(CAMS_ints.X_ext_ind) ;


prof.CAMS_ints = CAMS_ints ;
prof.CAMS_01 = CAMS_ints.int_found ;


%%





