%% VS1_CAMS_xs_intersect_fun --> July 2024
% function [CAMS_T] = VS1_CAMS_site_intersect_fun(CAMS, T, X_chain)
%
% Intersect ONE TRANSECT (UID1) from [XS] struct, with CAMS
% 
% Inputs
%   UID1 --> single UID
%   xs   ---> VIC-wide X-SECTIONS structure
%   CAMS - structure with 1 row per structure. Must have CAMS.x,.y (or .X,.Y) as line coords.
%
% Outputs
        % ints(n,1).x_int = x_int;
        % ints(n,1).y_int = y_int;
        % ints(n,1).X_back_exact = dX      ;
        % ints(n,1).X_back_ind = X_ind     ;
        % ints(n,1).X_back = X(X_ind)      ;
%
% Example
%   HST_Dir, cd(Dir.CAMS), load('CAMS_20221102_MAT_Apollo_ext_Jul2024.mat', 'CAMS')
%   Site_ID = 26 
%   VS1_run_loaders   % ----> gets [T]
%   [CAMS_T] = VS1_CAMS_site_intersect_fun(CAMS, T)

function [ints] = VS1_CAMS_xs_intersect_fun(UID1, xs, CAMS)


%% EXTRACT [x,y,X] from [XS]

ind1 = find([xs.UID] == UID1) ;

x1 = xs(ind1).x ;
y1 = xs(ind1).y ;
X1 = xs(ind1).X ;
% z = xs(UID1).z ;   % depth not needed

X0 = X1 - X1(1) ;    % removes offset (first point on transect, X = 0)

%% HST_Dir, Site_ID = 26
% VS1_run_loaders            % -----> script that uses Site_ID
% cd(Dir.CAMS), load('CAMS_20221102_MAT_Apollo_ext_Jul2024.mat', 'CAMS')

% Site search box
buf = 1000 ;
Box.x_min = min(x1) - buf;
Box.x_max = max(x1) + buf;
Box.y_min = min(y1) - buf;
Box.y_max = max(y1) + buf;

Box.x = [Box.x_min, Box.x_max, Box.x_max, Box.x_min ] ;
Box.y = [Box.y_min, Box.y_min, Box.y_max, Box.y_max ] ;

% Check if CAMS has CAMS.x, CAMS.y
if isfield(CAMS, 'X') && ~isfield(CAMS, 'x')
    [CAMS.x] = deal(CAMS.X) ;
    [CAMS.y] = deal(CAMS.Y) ;
end

% Find structures within Site Box
ind1 = find(inpolygon([CAMS.x_mid], [CAMS.y_mid], Box.x, Box.y ) )'  ;
CAM1 = CAMS(ind1) ;


%% Get [INTS] -->  Loop through CAMS assets near site --->  [1 row per intersection, no min/max length]

ints = [] ;
ints.int_found = false ;
ints.x_int = nan   ;
ints.y_int = nan   ;
ints.X_back_exact = nan   ;
ints.X_back_ind = nan   ;
ints.X_back = nan   ;

n = 0 ;
for i = 1 : length(CAM1)         % for the i'th CAMS ASSET
    % i = 2
    Cx = CAM1(i).x ;
    Cy = CAM1(i).y ;

    [x_int,y_int] = polyxpoly(Cx, Cy,  x1, y1)    ;    
    dX = hypot(x_int - x1(1), y_int - y1(1))   ;  % dist from transect (start pt) to intersect pt

    if length(dX)>1
        [dX, ind] = max(dX)   ; % if more than one intersect, take the furthest offshore (occurs around headlands)
        x_int = x_int(ind);
        y_int = y_int(ind); % take max (most offshore) intersect
    end

    if ~isempty(x_int)
        ints.int_found = true ;
        n = n + 1 ;

        [~, X_ind] = min(abs(X0 - round(dX)))   ;  % index to X0 (where X0 is distance from start of transect)

        ints.x_int(n,1) = x_int;
        ints.y_int(n,1) = y_int;
        ints.X_back_exact(n,1) = dX      ;
        ints.X_back_ind(n,1) = X_ind     ;
        ints.X_back(n,1) = X1(X_ind)      ;
    end
end

%% END FUNCTION
end


%% 

%% SCRAPS


% if ~isempty(ints)
%     [~, ind2] = sort([ints.TID]) ;
%     ints = ints(ind2) ;
% end

%% Translate INTS to [T_int] --> length = [indUID] ---> with most offshore intersect

% CAMS_T.T = struct('TID', [], 'UID', [], ...
%     'c_asset_id_num', [] , 'struc_type' ,  [],  'type_code', []  )  ;
% 
% for i = 1 : length(T.x)
%     CAMS_T.T(i,1).TID = T.TID(i) ;
%     CAMS_T.T(i,1).UID = T.UID(i) ;
% 
%     if ~isempty(ints)
%         ind = find([ints.TID] == i)   ;  % index INTERSECTS for a TRANSECT
%         if length(ind) > 1   % if more than one INTERSECT ...
%             [~, ind2] = max([ints(ind).X_back_exact]) ;
%             ind = ind(ind2) ;   % ... select the MOST OFFSHORE
%         end
% 
%         if ~isempty(ind)
%             CAMS_T.T(i,1).c_asset_id_num = ints(ind).c_asset_id_num     ;
%             CAMS_T.T(i,1).struc_type =     ints(ind).struc_type ;
%             CAMS_T.T(i,1).type_code =      ints(ind).type_code   ;
% 
%             CAMS_T.T(i,1).x_int =         ints(ind).x_int ;
%             CAMS_T.T(i,1).y_int =         ints(ind).y_int    ;
%             CAMS_T.T(i,1).X_back_exact =  ints(ind).X_back_exact  ;
%             CAMS_T.T(i,1).X_back_ind =    ints(ind).X_back_ind      ;
%             CAMS_T.T(i,1).X_back =        ints(ind).X_back     ;
% 
%         else
% 
%             CAMS_T.T(i,1).x_int =         nan      ;
%             CAMS_T.T(i,1).y_int =         nan    ;
%             CAMS_T.T(i,1).X_back_exact =  nan   ;
%             CAMS_T.T(i,1).X_back_ind =    nan      ;
%             CAMS_T.T(i,1).X_back =        nan     ;
% 
%         end
% 
%     end
% end

%% SET OUTPUTS
% CAMS_T.CAM1 = CAM1  ;
% CAMS_T.ints = ints  ;


%%




%%










%%













%%