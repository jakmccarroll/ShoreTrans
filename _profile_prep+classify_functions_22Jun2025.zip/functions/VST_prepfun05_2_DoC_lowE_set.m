%% function [wave1, DoCs] = VST_prepfun05_1_waves_DoC(UID1, DoC)




function [prof, DoCs] = VST_prepfun05_2_DoC_lowE_set(prof, DoCs, varargin)

%% OPT DEFAULTS

OPT.DoC_BF_z = -0.5 ;       % base of BeachFace (BF) --> max elevation to set DoC if profile is low energy, and a deeper DoC is not found
                             % NOTE this is an elevation --> 
                             % % ---> there is some inconsistency over use of DEPTH (magnitude, always positive) and ELEVATION (negative for below 0 m AHD)
OPT.BF_slope_thresh = 0.01 ;    % Set a threshold slope (e.g., 0.01) --> once it gets flatter than this, index the DoC_BF 
                              % set as a POSITIVE value for deepening in offshore direction

OPT.BF_slope_thresh2 = 0.012 ;  % Threshold slope to determine (along with wave height) if LOW-ENERGY DoC is implemented

OPT.toe_z   = 2.5 ;           % dune toe elevation for normal profiles (not low energy)                           
OPT.toe_z_low_E   = 2 ;        % dune toe elevation for low energy profiles
OPT.int_base_z = -1   ;        % base of intertidal (elevation)
OPT.slope_smooth_span = 50 ;   % moving average span when finding where the profile flattens out (smooths over bars)

OPT.Hb_thresh  = 0.4 ;          % avg breaking wave ht --> values below this are classed 'LOW ENERGY'

OPT.DoC_method = 2  ;     % 1 = H0, 2 = Hb, 3 = Hrev ;

%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField',  'silentIgnore'); % 'silentIgnore' - added Mar2024 (JM)



%% 1.5b -->> DoC SELECT [ Hb or BEACHFACE --> (-0.5m) for LOW-Hb , LOW-SLOPE PROFS ]

prof.DoC1_select     = DoCs.DoC1_select ;
prof.DoC1_select_str = DoCs.DoC1_select_str ;

DoCs.DoC1_BF = false ;
prof.DoC1_BF = false ;

if DoCs.DoC1_Hb < OPT.Hb_thresh       % DoC is already very low (or ZERO)    ====>>> USE BEACHFACE METHOD
    prof.DoC1_select = DoCs.DoC1_beachface ;
    prof.DoC1_select_str = 'BeachFace' ;
    DoCs.DoC1_BF = true ;   
    prof.DoC1_BF = true ;

elseif prof.wave1.Hb_av < OPT.Hb_thresh && prof.zones_OPT.tan_B < OPT.BF_slope_thresh2     % LOW WAVES + LOW SLOPE ====>>> USE BEACHFACE METHOD
    prof.DoC1_select = DoCs.DoC1_beachface ;
    prof.DoC1_select_str = 'BeachFace' ;
    DoCs.DoC1_BF = true ;   
    prof.DoC1_BF = true ;


end




%% 