%% function [z_rock_final, prof] = VST_prepfun12_rocklayer(prof, OPT_RL)


function [z_rock_out, prof] = VST_prepfun12_rocklayer(prof, OPT_RL)


%% EXTRACTS VARIABLES
bluff = prof.bluff ;
smry = prof.smry ;
zones = prof.zones ;

z0 = prof.z0 ;
x0 = prof.x0 ;
rock_depth = OPT_RL.rock_depth ;


%% MAKE INITIAL ROCK LAYER    
z_rock = z0 - rock_depth ;


%% BACKSHORE ROCK (1)  ----> CLIFFS
% ind = zones(1).ind ;

if smry.CLF_switch
    ind = [1 : prof.clf.To_ind] ;
    z_rock(ind) = z0(ind) ;

elseif ~isempty(zones(2).st_i)

    ind1 = zones(1).ind ;
    ind2 = z0(ind1) > rock_depth ;  % high sections of dune set to rock = z_rock(zones(2).st_i) ;  % avoids any
    % z_rock(ind2) = 0 ;              % ... but low back sections (lagoon), stay at [z0 - rock_depth]

    z_rock(ind2) = z_rock(zones(2).st_i) ;   % avoids any crests between flat section and offshore

    % openvar('ind')
    % openvar('zones(1).ind')
end

z_rock_s1 = z_rock ;

%% BACKSHORE ROCK (2)  ----> BLUFFS (backup for no cliff found)
if smry.BLUFF_switch
    ind = [1 : bluff.wall_ind] ;
    z_rock(ind) = z0(ind) - bluff.dz_surf2rock ;
end
z_rock_s2 = z_rock ;


%% BACKSHORE ROCK (3)                 ----> RIDGE
if smry.RIDGE_switch
    ind = bluff.ridge_ind ;
    z_rock(ind) = z0(ind) - bluff.dz_surf2rock ;
end

% INT1 ROCK
if smry.INT1_smart > 0
    ind = zones(2).ind ;
    z_rock(ind) = z0(ind) ;
end

% INT2 ROCK
if smry.INT2_smart > 0
    ind = zones(3).ind ;
    z_rock(ind) = z0(ind) ;

end

z_rock_s3 = z_rock ;

% z_rock([zones(1).en_i : ) = z_rock(zones(3).st_i) ;    

%% [SUB1 + SUB2] ROCK   &&  INT-DETECTED-ROCK (added Feb 2025)
if smry.SUB1_smart > 0 || smry.SUB2_smart > 0 || smry.INT1_smart > 0 || smry.INT2_smart > 0
    if smry.SUB_detect
        ind = prof.rockInd.ind2 ;    % openvar('ind')
        z_rock(ind) = z0(ind) ;

    end
end

z_rock_s4 = z_rock ;

%% FINAL CHECK TO CATCH INTD-1 "DIPS AND SPIKES"

% SET [INTD-1] to flat level with first pt in [INTD-2]

try
    ind1 = find(z_rock < z_rock(zones(3).st_i) & x0 >= x0(zones(1).en_i)-100 & x0 <= x0(zones(2).en_i)  ) ;  
catch
    ind1 = [] ;
end

if ~isempty(ind1)
    z_rock(ind1) = z_rock(zones(3).st_i) ;
end

% SET [BACKSHORE] to flat level with first pt in [INTD-1]

try
    ind2 = find(z_rock < z_rock(zones(2).st_i) & x0 >= x0(zones(1).en_i)-100 & x0 <= x0(zones(1).en_i)  ) ; 
catch
    ind2 = [] ;
end
if ~isempty(ind2)
    z_rock(ind2) = z_rock(zones(2).st_i) ;
end


% DOUBLE CHECK NO Z-ROCK IS ABOVE Z-BED
ind3 = find(z_rock > z0 ) ;
if ~isempty(ind3)
    z_rock(ind3) = z0(ind3) ;
end


%% IF NO ROCK ANYWHERE IN SMART ---> DROP IT WAY DOWN
if smry.CLF_smart == 0 && smry.INT1_smart == 0 && smry.INT2_smart == 0 ...
        && smry.SUB1_smart == 0 && smry.SUB2_smart == 0 && ~smry.BLUFF_switch && ~smry.RIDGE_switch
    smry.no_rock_found = true ;
    % z_rock = z_rock - 20 ;
    z_rock = -50 .* ones(size(z0)) ;
end



%% ONSHORE OF WALL - MAKE UN-ERODIBLE  (DOES NOT INCLUDE BLUFF-WALLS)
if smry.wall_on
    ind = [1 : prof.CAMi] ;
    z_rock(ind) = z0(ind) ;
end



%% OUTPUTS
prof.z_rock = z_rock ;

z_rock_out = [] ;
z_rock_out.z_rock_s1 = z_rock_s1 ;
z_rock_out.z_rock_s2 = z_rock_s2 ;
z_rock_out.z_rock_s3 = z_rock_s3 ;
z_rock_out.z_rock_s4 = z_rock_s4 ;
z_rock_out.z_rock_final = z_rock ;



%% END FUNCTION
end


%% 


%%