

function [clf, OPTC, prof, clf_TT, clf_calcs] = VST_prepfun08_cliff(UID1, geol, prof, OPTC)


%% EXTRACT VARS

OPTX = prof.OPTX ;
OPT_SLR = prof.OPT_SLR ;

%% CLIFF DETECT
% OPT.To_min_ind = 140 ; % MIN INDEX (of x0 position) to search for TOE
% OPT.To_max_ind = 240 ; % MAX INDEX to search for TOE
OPTC.To_min_ind = OPTC.To_min_ind_unext + OPTX.ext_off_m  ;
OPTC.To_max_ind = OPTC.To_max_ind_unext + OPTX.ext_off_m  ; 

[clf, OPTC] = ST_cliff_ToCr_detect(prof.x0, prof.z0, OPTC)   ;

% openvar('OPTC')
% openvar('clf')

%% CLIFFS FROM T+T2023 REPORT 
% 

[clf_TT] = VST_f_get_TT_cliffs(UID1, geol) ;


if OPTC.TT_rate_meth == 1
    clf_TT.rate_for_ST = - mean([clf_TT.rate_mean, clf_TT.rate_5pc])   ;

elseif OPTC.TT_rate_meth == 2

    clf_TT.rate_for_ST = - mean(clf_TT.rate_mean)   ;

end


%% CLIFF PRE-CALCS (IF CLIFF EXPECTED IN TT[preferred] or SMRT[backup]  )

clf_calcs = [] ;
clf_calcs.dS            = OPT_SLR.dS  ;
clf_calcs.dt            = OPT_SLR.dt  ;
clf_calcs.SLR_rate0     = OPT_SLR.dS_dt0  ;

if clf_TT.good    % TT has cliff ---> USE IT
    
    clf_calcs.m_val         = clf_TT.m ;
    clf_calcs.REC_rate0     = clf_TT.rate_for_ST   ; 
    clf_calcs = ST_cliff_precalc(clf_calcs) ;

elseif prof.smrtC.clf == 1     % clf = 1 --> GENERIC HARD cliff   ---> see link to XLS below

    clf_calcs.m_val         = 0.15 ;
    clf_calcs.REC_rate0     = 0.08   ; 
    clf_calcs = ST_cliff_precalc(clf_calcs) ;

elseif prof.smrtC.clf == 2     % clf = 2 --> GENERIC SOFT cliff   ---> see link to XLS below

    clf_calcs.m_val         = 0.3 ;
    clf_calcs.REC_rate0     = 0.1   ; 
    clf_calcs = ST_cliff_precalc(clf_calcs) ;

elseif prof.smrtC.clf == 0     % clf = 0 --> NO CLIFF ---> GENERIC ERODABLE BLUFF ---> see XLS link -  "DUNE DEPOSITS"
    clf_calcs.m_val         = 0.5 ;
    clf_calcs.REC_rate0     = 0.1   ;   % rounded up from 0.08 in XLS
    clf_calcs = ST_cliff_precalc(clf_calcs) ;

    
end

% SEE T+T SUMMARY XLS FOR CHOICE OF HARD/SOFT GENERIC VALUES
% fname_xls02 = 'GeolUnit_Codes_Rates_m-value_T+T.xlsx' ;
% winopen(fname_xls02) ;  % match cliff sections to unit code --> get rate and m-factor

%% CONSERVATION RATIO ---> BASED ON SMART [HARD = 0.75  |   SOFT = 0.25    |   NO-VALUE = 1 ]

if prof.smrtC.clf == 1            % 1 = HARD
    % clf_calcs.cons_ratio = 0.667 ;
    % clf_calcs.cons_ratio = 0.5 ;
    clf_calcs.cons_ratio = OPTC.cons_ratio_H ;

elseif prof.smrtC.clf == 2        % 2 = SOFT
    % clf_calcs.cons_ratio = 0.333 ;
    % clf_calcs.cons_ratio = 0.25 ;
    clf_calcs.cons_ratio = OPTC.cons_ratio_S ;

else
    clf_calcs.cons_ratio = OPTC.cons_ratio_H ;
    
end


%% PUT OUTPUTS IN PROF

prof.clf = clf ;
prof.clf_OPT = OPTC ;
prof.clf_TT = clf_TT ;
prof.clf_calcs = clf_calcs ;
prof.clf_01_smrt = prof.smrtC.clf ;
prof.clf_01_TT   = clf_TT.good ;
prof.clf_01_found = clf.good ;



%%      
