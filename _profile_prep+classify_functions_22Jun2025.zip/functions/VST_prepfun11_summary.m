       

function [smry, prof] = VST_prepfun11_summary(prof)


%% EXTRACT VARS
bluff = prof.bluff ;


%% SUMMARY  --- (PROF.SMRY) for ROCK LAYER + SETTINGS
smry = [] ;

% ROCK-1 - BACK SHORE
smry.CLF_smart = prof.smrtC.clf ;
smry.CLF_detect = prof.clf.good ;
if smry.CLF_smart == 1 && smry.CLF_detect
    smry.CLF_type = 1 ;
    smry.CLF_str = 'HARD cliff' ;
elseif  smry.CLF_smart == 2 && smry.CLF_detect
    smry.CLF_type = 2 ;
    smry.CLF_str = 'SOFT cliff' ;
elseif  smry.CLF_smart == 0 && ~smry.CLF_detect
    smry.CLF_type = 0 ;
    smry.CLF_str = 'NO cliff' ;
elseif  smry.CLF_smart == 1 && ~smry.CLF_detect
    smry.CLF_type = -1 ;
    smry.CLF_str = 'smart (YES), detect (NO)' ;
elseif  smry.CLF_smart == 0 && smry.CLF_detect
    smry.CLF_type = -2 ;
    smry.CLF_str = 'smart (NO), detect (YES)' ;
else
    smry.CLF_type = 0 ;
    smry.CLF_str = 'NO cliff' ;
end

if (prof.clf_01_smrt > 0  || prof.clf_01_TT)   &&  smry.CLF_detect
    smry.CLF_switch = true;
else
    smry.CLF_switch = false;
end

%% SUMMARY  --- CLIFFS,  BLUFFS, RIDGES

% T+T CLIFF RATE
smry.CLF_TT = prof.clf_TT.good ;
smry.CLF_TT_rate = prof.clf_TT.rate_for_ST ;

% BLUFF (backup for no cliffs FOUND, if there is a high backshore, AND [SMRT or T+T] has CLIFFS)
% if ~smry.CLF_switch && [prof.clf_01_smrt || prof.clf_01_TT]                     % ~smry.CLF_switch && bluff.found
%     smry.BLUFF_switch = true ;
if ~smry.CLF_switch && bluff.found
    smry.BLUFF_switch = true ;
else
    smry.BLUFF_switch = false ;
end

% RIDGE (part of BLUFF finding)
% if ~smry.CLF_switch && bluff.ridge_found
if ~smry.CLF_switch && bluff.ridge_found
    smry.RIDGE_switch = true ;
else
    smry.RIDGE_switch = false ;
end

%% SUMMARY  --- ROCK OUTCROPS

% ROCK-2 - INTERTIDAL
smry.INT1_smart = prof.smrtC.intd1 ;
smry.INT2_smart = prof.smrtC.intd2 ;

% ROCK-3 - SUBTIDAL
smry.SUB1_smart = prof.smrtC.subt1 ;
smry.SUB2_smart = prof.smrtC.subt2 ;
smry.SUB_detect = prof.rockInd.rock_found;

% TRANS TYPE - ROLL VS ENCROUSH
% smry.roll_str = prof.roll_str ;
smry.roll_type = prof.roll_type ;
smry.ToCr_opt = prof.ToCr_opt ;

% WALL
smry.wall_on = prof.CAMS_01 ;
smry.wall_bluff_ridge = false ;  % workaround wall for ridge and bluff (only if no REAL wall present)
if ~smry.wall_on && (smry.BLUFF_switch || smry.RIDGE_switch)
    smry.wall_bluff_ridge = true ;
end

%% PUT SMRY IN PROF
prof.smry = smry ;



%% END FUNCTION 
end



%%





