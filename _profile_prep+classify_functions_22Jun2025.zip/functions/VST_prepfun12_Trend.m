%% function [Trend, prof] = VST_prepfun12_Trend(UID1, shr, prof, OPT_TnB) --> TREND AND SEDIMENT BUDGET


function [Trend, prof] = VST_prepfun12_Trend(UID1, shr, prof, OPT_TnB)


%% EXTRACT VARIABLES


clf = prof.clf ;
clf_TT = prof.clf_TT ;
clf_calcs = prof.clf_calcs ;
OPTC = prof.clf_OPT ;
OPTZ = prof.zones_OPT ;
smry = prof.smry ;

%% TREND get (m/yr --> m3/yr)
Trend.sm_span = OPT_TnB.sm_span ;

ind1 = find(shr.UID == UID1) ;

Trend.m_yr = shr.Trend(ind1) ;   % shoreline trend (m/yr ---> from DEA)
try,   Trend.m_yr_sm = nanmean(shr.Trend(ind1 - Trend.sm_span : ind1 + Trend.sm_span)) ; % smoothed shoreline trend --> moving avg alongshore
catch, Trend.m_yr_sm = Trend.m_yr ;       end
% Trend.h_a = OPTZ.toe_z - OPTZ.sub_base_z ;   % active profile height (using ZONES settings including DoC)
Trend.h_a = OPTZ.toe_z - (-prof.DoC1_select) ;
Trend.m3_yr = Trend.h_a * Trend.m_yr_sm ;    % volume trend (sediment budget) ---> based on smoothed shoreline trend

% openvar('Trend')



%% SOFT CLIFSS ADJUSTMENT (6 MAR 2025) --> ACCOUNT FOR CLIFF EROSION VOLUME IN HIGH END ESTIMATE

if OPTC.dV_input_cliff == 1                % ADJUST FOR CLIFF INPUT --> set in XLS
    Trend.cliff_adjust = true ;

    if smry.CLF_switch           % smry.CLF_type == 1  || smry.CLF_type == 2     %  1 = SOFT CLIFF 2 = SOFT CLIFF

        cliff_rate = clf_TT.rate_for_ST  ;
        clf_ht = clf.clf_ht    ;
        cliff_cons_ratio = clf_calcs.cons_ratio   ;
        trend_cliff_vol = cliff_rate .* clf_ht .* cliff_cons_ratio   ;

        % adjust_coeff = 0.5 ;
        adjust_coeff = OPTC.dV_cliff_adjust ;
        Trend.cliff_m3_yr = trend_cliff_vol .* adjust_coeff ;
        
        % Trend.cliff_m3_yr = trend_cliff_vol ;

        Trend.m3_yr_no_cliff_vol = Trend.m3_yr ;
        Trend.m3_yr = Trend.m3_yr_no_cliff_vol - abs(Trend.cliff_m3_yr) ;  
        %  'rate_for_ST' is NEGATIVE ; 'rate_mean, 5% etc' are POSITIVE (so -(abs) is workaround)

    else   % NOT CLIFF

        Trend.cliff_m3_yr = nan ;
        Trend.m3_yr_no_cliff_vol = nan ;

    end

else
    Trend.cliff_adjust = false ;
    Trend.cliff_m3_yr = nan ;
    Trend.m3_yr_no_cliff_vol = nan ;

end


%% PPB - SUSPECTED NOURISHMENT FIX

% Trend.PPB_ind = [34015 : 44196 ] ;
Trend_PPB_ind = [34015 : 44196 ]'  ;
Trend.PPB_nour_fix_0  = false ;
Trend.m3_yr_no_PPB_fix = nan; 


if ismember(UID1, Trend_PPB_ind) & Trend.m_yr_sm > 0.3 

    Trend.m3_yr_no_PPB_fix = Trend.m3_yr  ; 
    Trend.m3_yr = 0    ;
    Trend.PPB_nour_fix_0 = true   ;

end



%% ADD TREND TO PROF
prof.Trend = Trend ;

%%    

% openvar('Trend')
% openvar('smry')
% openvar('clf')

% openvar('clf_calcs')

% openvar('geol')


% rate_mean = geol.rate_mean(45760)
