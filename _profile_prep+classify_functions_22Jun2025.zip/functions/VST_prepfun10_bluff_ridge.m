


function [bluff, prof] = VST_prepfun10_bluff_ridge(prof, OPT_blf)


%% EXTRACT VARS
zones = prof.zones ;
smrtC = prof.smrtC ;

clf = prof.clf ;
clf_calcs = prof.clf_calcs ;
clf_TT = prof.clf_TT ;

z0 = prof.z0 ;

%% 1.9 - BLUFFS + RIDGE CHECK ---> PICK UP ELEVATED BACKSHORE, NO CLIFFS, LIKELY ON BEDROCK    ------->>>>> NEEDS FUNCTION

bluff = [] ;
bluff.ind_on = zones(1).ind ;

bluff.z_av_on = mean(prof.z0(bluff.ind_on), 'omitnan') ;
bluff.z_max_on = max(prof.z0(bluff.ind_on)) ;

bluff.z_av_min = OPT_blf.z_av_min ;   % if mean onshore z higher than this (AND NO CLIFF), then a BLUFF will be inserted
bluff.z_for_x_st = OPT_blf.z_for_x_st ;   % if prof dips this level, bluff must start onshore of this point (a peak offshore of this point is likely a dune or RIDGE)
bluff.z_for_x_st_low_bluff = OPT_blf.zW_if_cliff_expect ;   % wall insertion level if cliff expected

bluff.z_ridge_lim = OPT_blf.z_ridge_lim  ;  % if any part of onshore profile is higher than this --> it gets rock under it
bluff.dz_surf2rock = OPT_blf.dz_surf2rock  ;

bluff.precalc_clf_rec_tot = clf_calcs.REC_total_av ;

bluff.found = false ;
bluff.low_bluff = false ;
bluff.wall_ind = nan ;

% CHECK IF ANY ROCK IS PRESENT  (ANY ---> SMRT, TT, CLIFF-DETECT)
bluff.rock_any = false ;

if smrtC.clf > 0 || smrtC.intd1 > 0 || smrtC.intd2 > 0 || smrtC.subt1 > 0 || smrtC.subt2 > 0 % CHECK SMRT FOR ROCKS
    bluff.rock_any = true ;

elseif clf_TT.good          % CHECK TT FOR CLIFFS
    bluff.rock_any = true ;

elseif clf.good       % CHECK CLIFF DETECTION FOR CLIFFS FOUND
    bluff.rock_any = true ;

elseif bluff.z_av_on > 20 % (bluff.z_av_min + 15)      % (AV BACK HT) --> 2nd LAST RESORT --->>> IT'S SUPER HIGH , COULDn'T POSSIBLY BE A DUNE!!!
    bluff.rock_any = true ;    


elseif bluff.z_max_on > 23                % (SINGLE MAX PEAK) --> LAST RESORT --->>> IT'S SUPER HIGH , COULDn'T POSSIBLY BE A DUNE!!!
    bluff.rock_any = true ;    

end


%% BLUFF CHECK
if bluff.z_av_on >= bluff.z_av_min  &  bluff.rock_any        % if the average elevation onshore is high...

    % GET BLUFF [WALL] LOCATION
    bluff.wall_ind_z_min = find(z0 <= bluff.z_for_x_st , 1, 'first')   ;           % wall ind --> Z_FOR_X_ST rule
    bluff.wall_ind_clf_rec = zones(1).en_i - floor(abs(bluff.precalc_clf_rec_tot)) ;  % wall ind --> PRECALC CLF RECESSION RULE

    bluff.wall_ind = min(bluff.wall_ind_z_min, bluff.wall_ind_clf_rec)  ;   % bluff wall ind FINAL (take MIN of 2 options)

    % bluff.wall_ind = find(z0 >= bluff.z_for_x_st  & x0 < x0(bluff.wall_ind), 1, 'last') ;

    if ~isempty(bluff.wall_ind)            % ... and a bluff toe is found ...
        bluff.found = true ;             % ... a bluff is 'FOUND' (but won't be used if a cliff is present)
    end
end




%% LOWER BLUFFS (IF CLIFF EXPECTED) ---->>> THIS WILL CATCH ANY EXPECTED CLIFF --> INSERT WALL AT 6m  - OR - CLF_REC_IND [MIN of the 2]
if smrtC.clf > 0 || clf_TT.good    

    bluff.found = true    ;             % 
    bluff.low_bluff = true    ;

    % GET BLUFF [WALL] LOCATION
    try
        bluff.wall_ind_z_min = find(z0 >= bluff.z_for_x_st_low_bluff , 1, 'last')    ;           % wall ind --> Z_FOR_X_ST rule
    catch
        bluff.wall_ind_z_min = nan ;
    end

    bluff.wall_ind_clf_rec = zones(1).en_i - floor(    abs(bluff.precalc_clf_rec_tot)   ) ;  % wall ind --> PRECALC CLF RECESSION RULE
    bluff.wall_ind = min(bluff.wall_ind_z_min, bluff.wall_ind_clf_rec)  ;   % bluff wall ind FINAL (take MIN of 2 options)


    if isempty(bluff.wall_ind)
           bluff.wall_ind = prof.ToCr.To_ind - 100 ;    % last resort, if prof too low, put wall 100 m onshore of toe 

    end


end



%% RIDGE CHECK
z_temp = z0 ;                               % take a temp version of z0          % openvar('z_temp')
z_temp(zones(2).st_i : end) = nan ;         % ... nan the offshroe
z_temp(z_temp < bluff.z_ridge_lim) = nan ;  % ... nan anything below the ridge limit

if bluff.found
    z_temp(1 : bluff.wall_ind) = nan ;        % ... nan points found to be BLUFF
end
% ind1 = find(~isnan(z_temp)) ;               % ... if anything left ---> it's a RIDGE
ind_st = find(~isnan(z_temp), 1, 'first') ;
ind_en = find(~isnan(z_temp), 1, 'last') ;
ind1 = [ind_st : ind_en]' ;

bluff.ridge_found = false;
if ~isempty(ind1) & bluff.rock_any           % ALLOWS CLIFFS HERE --->>> BUT [PREP_SUMMARY STOPS RIDGE IF CLIFF PRESENT]
    bluff.ridge_found = true ;
    bluff.ridge_ind = ind1 ;
end



%% ADD TO PROF
prof.bluff = bluff ;


%%


%% 90-MILE - MANUAL FIX

% bluff_ninety_mile_ind = [7500 : 11000]' ;
% 
% if ismember(UID1, bluff_ninety_mile_ind )
%     bluff.found = false ;     
%     bluff.ridge_found = false ;   
% end






%%
%%






%%