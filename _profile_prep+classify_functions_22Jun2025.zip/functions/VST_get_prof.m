%% VST --> get profile data by inputting profile UID (Apr 2025)
% Inputs 
% ---> UID
% ---> shr (shoreline points, transect [3-point], Trend [DEA-C-2023] )
% ---> xs (cross-section data)
%
% Output --> prof.x, .y, .X, .xT2, .yT2, Trend
% -- x,y --> coordinates in MGA GDA94 zone-55
% -- X   --> cross-shore distance
% -- xT2, yT2 --> 3 pt transect coords
% -- Trend --> shoreline trend from Digitial Earth Australia Coastlines (2023 update)


function [prof] = VST_get_prof(UID1, shr, xs)

% prof = [] ;

prof.UID = UID1 ;

ind1 = find(shr.UID == UID1) ;   % profile ID
prof.x_shr = shr.x(ind1) ;       % shoreline point - x-coord
prof.y_shr = shr.y(ind1) ;       % shoreline point - y-coord
prof.xT2    = shr.xT2(ind1,:) ;  % transect - x-coords (onshore, shoreline, offshore)
prof.yT2    = shr.yT2(ind1,:) ;  % transect - y-coords (on, shr, off)

ind2 = find([xs.UID] == UID1) ;
prof.xx = xs(ind2).x(:) ;           % x-map coord for each point on x-section
prof.yy = xs(ind2).y(:) ;           % y-map coord for each point on x-section
prof.x00 = xs(ind2).X(:) ;          % x-shore distance for each point on x-section
prof.z00 = xs(ind2).z(:) ;          % bed elevation for each point on x-section


%%