%% function [prof, ToCr, OPT_ToCr] = VST_prepfun07_ToCr(prof, OPT_ToCr) 
% index dune toe/crest 



function [prof, ToCr, OPT_ToCr] = VST_prepfun07_ToCr(prof, OPT_ToCr) 



% FIND TO-CR [BACK-TOE / TOE / CREST] --> ALTERNATE ROLL/ENCROACH APPROACH  [ST_dune_ToCr_detect]
% clc
[ToCr, OPT_ToCr] = ST_dune_ToCr_detect(prof.x0, prof.z0, OPT_ToCr) ;
% openvar('ToCr')  
% openvar('OPT_ToCr')


% IF BEACHFACE RULE DOC --> SET ROLL=0 (to ENCROACH)
if strcmpi(prof.DoC1_select_str, 'BeachFace')
    ToCr.ST_ToCr_opt = 3 ;
    ToCr.ST_rollover = 0 ;
    ToCr.ST_ToCr_ind = prof.zones(2).st_i ;
end


prof.ToCr = ToCr;
prof.OPT_ToCr = OPT_ToCr ;
prof.ToCr_opt = ToCr.ST_ToCr_opt ;
prof.roll_type = ToCr.ST_rollover ;




%%



