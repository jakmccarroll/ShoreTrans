%% function [varb] = VST_ST_uncert_bounds(OPT_ST0, OPT_LTV) 
% get low+high range uncertainty bounds
% 
% Variable with uncertainty bounds applied:
% 'DoC', - depth of closure (DoC1) 
% 'dS',  - sea level rise magnitude
% 'dV_input',  - sediment budget (total volume gain/loss to profile)
% 'cliff_REC_rate0' - initial cliff recession rate


function [varb] = VST_ST_uncert_bounds(OPT_ST0, OPT_LTV) 


varb = [] ;
varb.rng = [OPT_LTV.DoC_rng; OPT_LTV.dS_rng; OPT_LTV.dV_input_rng; OPT_LTV.cliff_REC0_rng] * 1.96 ; % fixed uncertainty [%] range around the mean value
varb.vars = {'DoC', 'dS', 'dV_input', 'cliff_REC_rate0'} ; % variables as they appear in OPT_ST (output from previous run)
fn = varb.vars   ;

for k = 1 : length(varb.rng)
    varb.(fn{k})(1,1)  = OPT_ST0.(fn{k}) .* (1 - varb.rng(k)) ;
    varb.(fn{k})(2,1)  = OPT_ST0.(fn{k}) ;
    varb.(fn{k})(3,1)  = OPT_ST0.(fn{k}) .* (1 + varb.rng(k)) ;
end

k = 3 ;
if OPT_ST0.(fn{k}) > 0    % if ACCRETING (dV_input > 0) switch around scenarios (1 = low range = higher accretion ; 3 = high range = lower accretion)
    varb.(fn{k})(1,1)  = OPT_ST0.(fn{k}) .* (1 + varb.rng(k)) ;
    varb.(fn{k})(3,1)  = OPT_ST0.(fn{k}) .* (1 - varb.rng(k)) ;    
end

varb.DoC_str = num2str(varb.DoC, '%0.1f') ;
varb.dS_str  = num2str(varb.dS,  '%0.1f') ;
varb.dV_str  = num2str(varb.dV_input,  '%0.0f') ;
varb.cliff_REC_rate0_str  = num2str(varb.cliff_REC_rate0,  '%0.2f') ;










