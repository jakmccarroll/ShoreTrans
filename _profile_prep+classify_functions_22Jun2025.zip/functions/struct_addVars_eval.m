% struct_addVars_eval
% ADD VARIABLES TO A STRUCTURE USING [EVAL] --> SCRIPT NOT A FUNCTION (DEC 2024)


for i = 1 : length(vars)
    str1= char(vars{i}) ;
    eval([struct_name '.' str1 ' = ' str1 ';']) ;
end

