


function [OPT_ST0] = VST_ST_setup(prof)

%% EXTRACT VARS FROM [prof]

OPT_SLR = prof.OPT_SLR ;
zones = prof.zones ;
smry = prof.smry ;
bluff = prof.bluff ;
clf = prof.clf ;
clf_calcs = prof.clf_calcs ;
clf_TT = prof.clf_TT ;

%% 2.1 ST SETUP (1)
% openvar('prof')

OPT = ST_OPT_defaults   ; % generate OPT (default settings)
OPT.dS = OPT_SLR.dS ;
OPT.dt = OPT_SLR.dt ;

OPT.DoC =  -prof.DoC1_select ;
OPT.DoC_first_last = 1 ;  % 1 = DoC will be the FIRST point that dips below the set level;
OPT.toeCrest_ind = zones(2).st_i ;

% SET ROCK --> (this sets up INT and SUB ROCK)    ---> (CLIFF AND WALL NEED MORE)
OPT.rockSwitch = 1   ;
OPT.rockLayer = prof.z_rock   ;

OPT.shortOutput = 1  ;
OPT.error_bypass = 1  ;

OPT.cliff_switch = 0 ;
OPT.cliff_str = 'NO CLIFF' ;        
OPT.cliff_REC_rate0 = nan ;

% SET ROLL / ENCROACH + ToCr IND ---> UPDATED Dec 2024

OPT.rollover = prof.ToCr.ST_rollover ;
OPT.toeCrest_ind = prof.ToCr.ST_ToCr_ind ;
OPT.roll_backSlope = 15 ; 
OPT.roll_flatCap = prof.OPT_ToCr.Cr_flat_top_w ;     % FLAT-CAP DUNE -->> added 26 MAR 2025


% OLD ROLLOVER METHOD
% OPT.rollover = prof.roll.vars.type  ;
% if OPT.rollover == 1
    % OPT.toeCrest_ind = [] ;     % allow ST to find CREST
    % OPT.roll_backSlope = 30 ; 
% end

% SLUMP SETTINGS
OPT.slumpCheck = 1 ; 
OPT.slumpCap   = 15;    


%% 2.1 ST SETUP (2)        
% CLIFF SETTINGS
if smry.CLF_switch       %  smry.CLF_smart > 0 && smry.CLF_detect
    OPT.cliff_switch = 1 ;
    % OPT.cliff_REC_rate0 = -0.1 ;
    % OPT.cliff_vol_conserve_ratio = 0.5   ;
    OPT.toeCrest_level = [] ;
    OPT.toeCrest_ind = clf.To_ind ;
    OPT.rollover = 0 ;
    OPT.cliff_ind = clf.To_ind ;
    OPT.cliff_slope = clf.clf_ang ;

    OPT.cliff_erode_platform = 1 ;
    OPT.cliff_m_coeff = prof.clf_calcs.m_val ;

    OPT.cliff_REC_rate0 = -(abs(clf_calcs.REC_rate0)) ;     % MAKE RECESSION RATE NEGATIVE FOR ST
    OPT.cliff_vol_conserve_ratio = clf_calcs.cons_ratio ; 

    OPT.cliff_SLR_rate0 = OPT_SLR.dS_dt0; % initial rate of SLR (default = 3mm/year)    
    
    OPT.cliff_erode_to_rock_check = true ;

    if smry.CLF_TT
        OPT.cliff_str = clf_TT.name     ;
        % OPT.cliff_REC_rate0 = smry.CLF_TT_rate ; 
    
        % if smry.CLF_type == 1
        %     OPT.cliff_vol_conserve_ratio = 0.75   ;
        % elseif smry.CLF_type == 2
        %     OPT.cliff_vol_conserve_ratio = 0.25   ;      
        % end

    elseif smry.CLF_type == 1
        OPT.cliff_str = 'HARD' ;
        % OPT.cliff_REC_rate0 = -0.05 ;
        % OPT.cliff_vol_conserve_ratio = 0.75   ;

    elseif smry.CLF_type == 2
        OPT.cliff_str = 'SOFT' ;
        % OPT.cliff_REC_rate0 = -0.1 ;
        % OPT.cliff_vol_conserve_ratio = 0.25  ;

    end

end

% CLIFF WITH INTERTIDAL ROCK PLATFORM  ----> SET CLIFF TOE TO BOTTOM OF INT1 (stop cliff eroding behind shore platform)
% if smry.CLF_smart > 0 && smry.CLF_detect && smry.INT1_smart > 0
%     OPT.cliff_ind = zones(2).en_i      ; 
%     OPT.toeCrest_ind = zones(2).en_i    ; 
% end

%% 2.1 ST SETUP (3)
% WALL SETTINGS
OPT.redist_ratio = 0.67   ;
OPT.wall_no_erode_behind = 1 ;
if smry.wall_on
    OPT.wallSwitch = 1  ;
    OPT.wall_ind = prof.wall_i  ;
    OPT.wall_z_min_check = 1 ; % 1 = check to see if pt offshore of wall has eroded below WALL_Z_MIN
    OPT.wall_z_min = -2;
end

% BLUFF WALL SETTINGS  (PUT AFTER WALL)
if smry.BLUFF_switch && ~smry.wall_on
    OPT.wallSwitch = 1  ;     % WORKAROUND to stop erosion onshore of ridge --> make it a wall
    OPT.wall_ind = bluff.wall_ind  ;
    % smry.wall_bluff_ridge = true ;
    OPT.wall_z_min_check = 1 ; % 1 = check to see if pt offshore of wall has eroded below WALL_Z_MIN
    OPT.wall_z_min = -2;
end

% RIDGE WALL SETTINGS  (PUT AFTER WALL)
if smry.RIDGE_switch && ~smry.wall_on
    % OPT.toeCrest_ind = zones(2).st_i ;  % set ToCr pt back to dune toe, rollover of crest or back toe doesn't work with ridge
    OPT.wallSwitch = 1  ;     % WORKAROUND to stop erosion onshore of ridge --> make it a wall
    OPT.wall_ind = bluff.ridge_ind(end)  ;
    % smry.wall_bluff_ridge = true ;
    OPT.wall_z_min_check = 1 ; % 1 = check to see if pt offshore of wall has eroded below WALL_Z_MIN
    OPT.wall_z_min = -2;
end

% TREND (SEDIMENT BUDGET)
dV_input_per_yr = prof.Trend.m3_yr  ; % sediment budget (deficit) = -100 m3/m
dV_input = dV_input_per_yr * OPT.dt   ;

OPT.dV_input_per_yr  = dV_input_per_yr ;
OPT.dV_input = dV_input   ;
OPT_ST0 = OPT ;



%%



%%







