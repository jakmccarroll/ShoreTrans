%% function [indSec] = index_logical_sections(logicArray)
% https://au.mathworks.com/matlabcentral/answers/801531-find-the-index-range-of-ones-trues
%
% EXAMPLE
% logicArray = [0,0,1,0,0,1,1,0,1,1,1,0,1,1,1,1];
% [indSec] = index_logical_sections(logicArray)

function [indSec] = index_logical_sections(logicArray)

logicArray = logicArray(:) ;

st = strfind([0 logicArray'], [0 1]) ;
en = strfind([logicArray' 0], [1 0]) ;

% out = [starts(:), stops(:)]

indSec = [] ;

for i = 1 : length(st)
    indSec(i,1).st = st(i);
    indSec(i,1).en = en(i);    
    indSec(i,1).ind = [st(i) : en(i)]';
    indSec(i,1).length = length(indSec(i,1).ind) ;
end


end





