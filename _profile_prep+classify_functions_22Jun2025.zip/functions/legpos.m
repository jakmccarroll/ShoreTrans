%% legpos -> set legend position
% RJM, 27/3/2020
%
% Create the legend first (with a handle), then set a 4-coordinate position
% function legpos(h, pos)
% INPUTS
    % h = handle of legend
    % pos = position as a 1x4 vector [x_origin, y_origin, x_size, y_size]
        % all positions are RELATIVE, e.g., if pos(1) = 1.1, this will...
        % ... shift the x-origin positive by 10%
% EXAMPLE
% f1 = figure(1)
% L1 = legend
% pos = [1, 0.9, 1, 1.2]
% legpos(L1, pos)

function legpos(h, pos)

currentPosition = get(h, 'position');
set(h, 'position',...
    [currentPosition(1)*pos(1), currentPosition(2)*pos(2),...
    currentPosition(3)*pos(3), currentPosition(4)*pos(4)]);

