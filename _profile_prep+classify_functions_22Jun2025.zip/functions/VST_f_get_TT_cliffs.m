


function [clf_TT] = VST_f_get_TT_cliffs(UID1, geol)


clf_TT = [] ;
clf_TT.UID = UID1 ;

ind1 = find(geol.UID == UID1) ;


clf_TT.unit_ID = geol.unit_ID(ind1) ;
if ~isnan(clf_TT.unit_ID)
    clf_TT.name = char(geol.name(ind1)) ;
else
    clf_TT.name = 'No TT-cliff' ;
end
clf_TT.rate_mean = geol.rate_mean(ind1) ;
clf_TT.rate_10pc = geol.rate_10pc(ind1) ;
clf_TT.rate_5pc = geol.rate_5pc(ind1) ;
clf_TT.rate_used_TT = geol.rate_used(ind1) ;

% clf_TT.rate_for_ST = - clf_TT.rate_mean ;      %   USE MEAN RATE (LOWER VALUE) FOR SHORETRANS --> TT VALUES ARE TOO HIGH
% clf_TT.rate_for_ST = - clf_TT.rate_5pc ;       %   USE TTs 5pc rate

% clf_TT.rate_for_ST = - mean([clf_TT.rate_mean, clf_TT.rate_5pc])   ;   % MOVED THIS BACK TO FATB_f_prep_cliff


clf_TT.m  = geol.m_val(ind1) ;

clf_TT.good = false ;
if ~isnan(clf_TT.unit_ID), clf_TT.good = true; end




% % EXCEL --> MANUALLY TAGGED ALL T+T ROCK UNITS (based VIC 1:250,000) TO UID
% cd(Dir.data)
% HST_Dir
% cd(Dir.geology)
% cd(fullfile(Dir.geology, 'rockUnits_2_UID_T+T')) ;
% 
% fname_xls01 = 'Geology250_T+T_to_UID.xlsx' ;
% fname_xls02 = 'GeolUnit_Codes_Rates_m-value_T+T.xlsx' ;
% 
% winopen(fname_xls01) ;         % every cliff section across VIC (from T+T 2023)
% winopen(fname_xls02) ;  % match cliff sections to unit code --> get rate and m-factor












