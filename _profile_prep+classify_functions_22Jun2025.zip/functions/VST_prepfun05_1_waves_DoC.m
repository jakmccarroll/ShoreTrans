%% function [wave1, DoCs] = VST_prepfun05_1_waves_DoC(UID1, DoC)




function [prof, wave1, DoCs] = VST_prepfun05_1_waves_DoC(prof, UID1, DoC, varargin)

%% OPT DEFAULTS

OPT.DoC_BF_z = -0.5 ;       % base of BeachFace (BF) --> max elevation to set DoC if profile is low energy, and a deeper DoC is not found
                             % NOTE this is an elevation --> 
                             % % ---> there is some inconsistency over use of DEPTH (magnitude, always positive) and ELEVATION (negative for below 0 m AHD)
OPT.BF_slope_thresh = 0.01 ;    % Set a threshold slope (e.g., 0.01) --> once it gets flatter than this, set the DoC_BF
                              % set as a POSITIVE value for deepening in offshore direction
OPT.toe_z   = 2.5 ;           % dune toe elevation for normal profiles (not low energy)                           
OPT.toe_z_low_E   = 2 ;        % dune toe elevation for low energy profiles
OPT.int_base_z = -1   ;        % base of intertidal (elevation)
OPT.slope_smooth_span = 50 ;   % moving average span when finding where the profile flattens out (smooths over bars)

OPT.Hb_thresh  = 0.4 ;          % avg breaking wave ht --> values below this are classed 'LOW ENERGY'

OPT.DoC_method = 2  ;     % 1 = H0, 2 = Hb, 3 = Hrev ;

%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField',  'silentIgnore'); % 'silentIgnore' - added Mar2024 (JM)

%% EXTRACT VARS
BF_z = OPT.DoC_BF_z ;
z0 = prof.z0 ;
span = OPT.slope_smooth_span ;
BF_slope_thresh = OPT.BF_slope_thresh  ;  % Set a threshold slope (e.g., 0.01) --> once it gets flatter than this, set the DoC_BF

%% WAVES (from DoC ---> wave1)
wave1 = [] ;

ind1 = find([DoC.UID] == UID1) ;

wave1.Hs0_av = DoC.Hs_av(ind1) ;
wave1.Tp_av = DoC.Tp_av(ind1) ;
wave1.alpha0 = DoC.alpha0(ind1) ; % dir rel to shr
wave1.Hb_av = DoC.Hb_av(ind1) ;
% prof.wave1 = wave1 ;
% openvar('wave1') ;

%% DoC (get x3 --> DoC1_H0, DoC1_Hb, DoC1_Hrev)
% H0 ---> mean sig wave ht - offshore
% Hb ---> mean sig wave ht - breaking  (VanRijn 2014)
% Hrev --> mean sig wave ht - to breaking, then reverse shoaled  (reversing VanRijn 2014)

DoCs = [] ;
DoCs.DoC1_H0  = DoC.DoC1_H0(ind1) ;
DoCs.DoC1_Hb  = DoC.DoC1_Hb(ind1) ;
DoCs.DoC1_rev = DoC.DoC1_rev(ind1) ;

switch OPT.DoC_method
    case 1
        DoCs.DoC1_select = DoCs.DoC1_H0 ;
        DoCs.DoC1_select_str = 'Hall-1, Offshore' ;

    case 2
        DoCs.DoC1_select = DoCs.DoC1_Hb ;
        DoCs.DoC1_select_str = 'Hall-1, BreakPoint' ;

    case 3
        DoCs.DoC1_select = DoCs.DoC1_Hrev ;
        DoCs.DoC1_select_str = 'Hall-1, Reverse shoal' ;
end

%% USE SLOPE THRESHOLD TO FIND DoC-BEACHFACE

dz0 = [0; diff(z0(:))] ;   % Take the GRADIENT (SLOPE) of profile
dz0s = smooth(dz0, span) ;   % Smooth is (50-pt span)

% find 1st pt OFFSHORE of INT_1, DEEPER than -0.5m AND --> slope is FLATTER than BF_SLOPE_THRESHOLD
DoC_BF_ind = find(z0 <= BF_z & dz0s > -BF_slope_thresh, 1, 'first') ;

if isempty(DoC_BF_ind)
    DoC_BF_ind = find(z0 <= BF_z, 1, 'first') ;
end

if ~isempty(DoC_BF_ind)
    DoC1_beachface = -z0(DoC_BF_ind) ;    % note DoC is POSITIVE [DEPTH] here

    if DoC1_beachface > DoCs.DoC1_select    % CATCH DoC1_beachface DEEPER than  DoC1_Hb
      DoC1_beachface = -BF_z ;            % note DoC is POSITIVE [DEPTH] here
    end

else
    DoC1_beachface = -BF_z ;            % note DoC is POSITIVE [DEPTH] here
end

DoCs.DoC1_beachface = DoC1_beachface   ;


%% ADD TO PROF
prof.DoCs = DoCs ;
prof.DoC1_select = DoCs.DoC1_select ;
prof.DoC1_Hb = DoCs.DoC1_select ;
prof.wave1 = wave1 ;

%% INDEX "LOW-ENERGY" (Hb_av < 0.4)

prof.low_E = false ;
if wave1.Hb_av < OPT.Hb_thresh
    prof.low_E = true ;
end

%% SET DUNE TOE ELEVATION  --> STANDARD AND LOW-E PROFILES 
prof.toe_z = OPT.toe_z ;
if prof.low_E
    prof.toe_z = OPT.toe_z_low_E ;       % ADJUST DUNE TO (down to 2m)  ---> if LOW_E = TRUE
end


%% SET [BASE OF SUBTIDAL] ELEVATION (DoC1)

if -DoCs.DoC1_select < OPT.int_base_z
    DoCs.sub_base_z = -DoCs.DoC1_select ;
else
    DoCs.sub_base_z = OPT.int_base_z - 5 ; % catches DoC_Hb = 0 
                                        % (set sub_base an arbitrary depth below int_base)
end


%% 1.5 - ZONES GET  ----> use DoC1_Hb for sub_base_z 
% [zones, OPTZ] = ST_zones_get_fun(prof.x_ext, prof.z_ext, OPTZ)  ;
% prof.zones = zones ;
% prof.zones_OPT = OPTZ ;



%% 1.5b -->> DoC SELECT [ Hb or BEACHFACE --> (-0.5m) for LOW-Hb , LOW-SLOPE PROFS ]
% 
% prof.DoC1_select = DoCs.DoC1_Hb ;
% prof.DoC1_select_str = 'Hall-1, BreakPoint' ;
% 
% if DoCs.DoC1_Hb < 0.4       % DoC is already very low (or ZERO)    ====>>> USE BEACHFACE METHOD
%     prof.DoC1_select = DoCs.DoC1_beachface ;
%     prof.DoC1_select_str = 'BeachFace' ;
%     prof.DoC1_BF = true ;
% 
% elseif prof.wave1.Hb_av < 0.4 && prof.zones_OPT.tan_B < 0.012     % LOW WAVES + LOW SLOPE ====>>> USE BEACHFACE METHOD
%     prof.DoC1_select = DoCs.DoC1_beachface ;
%     prof.DoC1_select_str = 'BeachFace' ;
%     prof.DoC1_BF = true ;
% end




%% 