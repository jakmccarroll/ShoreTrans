%% function [smrtC] = VS1_ST_smrtCodes_clf_int_sub  --------->> NEED MODIFY TO MAKE CODES FLEXIBLE
% Get SMRT SIMPLE CODES (0,1,2) FOR CLF, INT and SUB zones
% 
% Input: smart ---> output of VS1_smart_load_CAMS_intrsct 
%
% Output: smrtC -->   ---> each field has length(TID) with value   
%             smrtC.clf          % 0 - NO cliff     % 1 - HARD cliff     % 2 - SOFT cliff    
%             smrtC.intd1        % 0 - sand     % 1 - mixed sand-rock     % 2 - rock
%             smrtC.intd2
%             smrtC.subt1
%             smrtC.subt2
%
% XLS with code conversion list
% fname = fullfile(Dir.smartline, 'Smartline_CATEGORIES_XLS.xlsx')   ;
% cd(Dir.smartline)
% winopen(fname) ;


function [smrtC] = VST_prepfun02_get_smart(UID1, smart)


% crop [smart] to UID1
ind1 = find(smart.UID == UID1) ;
fn = fieldnames(smart) ;
Len = length(smart.x) ;
for k = 1 : length(fn)
    field1 = smart.(fn{k}) ;
    if length(field1) == Len
        smart.(fn{k}) = field1(ind1) ;
    end
end


% METADATA
smrtC.meta = ...
    {'clf = 1 --> HARD cliff' ;
     'clf = 2 --> SOFT cliff' ;
     'intd1,2 = 4 --> MIXED sand/rock' ;
     'intd1,2 = [1,2] --> ROCK' ;
     'subt1,2 = 2 ---> ROCK'} ;

% SMART CLASS - CLIFFS 
% 0 - NO cliff     % 1 - HARD cliff     % 2 - SOFT cliff
smrtC.clf = zeros(size(smart.back_n)) ;
ind1 =  find(ismember(smart.back_n, [1])) ;  
smrtC.clf(ind1) = 1;     % 1 - HARD cliff  
ind2 =  find(ismember(smart.back_n, [2])) ;
smrtC.clf(ind2) = 2;   % 2 - SOFT cliff

% SMART CLASS - INTERTIDAL ROCKS    
% 0 - sand     % 1 - mixed sand-rock     % 2 - rock
smrtC.intd1 = zeros(size(smart.intd1_n)) ;   % 0 - sand / mud (NO ROCK)
ind1 =  find(ismember(smart.intd1_n, [4])) ;
smrtC.intd1(ind1) = 1;   % 1 - mixed sand-rock
ind2 =  find(ismember(smart.intd1_n, [1,2])) ;
smrtC.intd1(ind2) = 2;   % 2 - rock

smrtC.intd2 = zeros(size(smart.intd2_n)) ;      % 0 - sand / mud (NO ROCK)
ind1 =  find(ismember(smart.intd2_n, [4])) ;
smrtC.intd2(ind1) = 1;          % 1 - soft OR mixed sand-rock
ind2 =  find(ismember(smart.intd2_n, [1,2])) ;
smrtC.intd2(ind2) = 2;           % 2 - HARD OR SOFT ROCK

% SMART CLASS - SUBTIDAL ROCKS    ------>>> % 0 - 
smrtC.subt1 = zeros(size(smart.subt1_n)) ;
ind2 =  find(ismember(smart.subt1_n, [1])) ;
smrtC.subt1(ind2) = 2 ;     % 2 = ROCK

smrtC.subt2 = zeros(size(smart.subt2_n)) ;
ind2 =  find(ismember(smart.subt2_n, [1])) ;
smrtC.subt2(ind2) = 2 ;     % 2 = ROCK


%%


end
























