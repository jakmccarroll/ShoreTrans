%% function [zones, OPT] = ST_zones_get_fun(x0, z0, varargin)  ----------->>>> NOV 2024
% index profile zones [back, int1, int2, sub1, sub2]
%
% INPUTS --> x0, z0, OPT
%
% OUTPUTS [zones, OPT]
% zones.name


function [zones, OPT] = ST_zones_get_fun(x0, z0, varargin)


%% SET DEFAULTS (OPT)
OPT.toe_z = 2.5 ; % dune/cliff toe elevation
OPT.int_base_z = -1.5 ; % dune/cliff toe elevation
OPT.sub_base_z = -10 ; % dune/cliff toe elevation

OPT.int_mid_z = []   ;
OPT.sub_mid_z = []   ;

%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'silentIgnore'); 

if isnan(OPT.int_mid_z)
    OPT.int_mid_z = [] ;          % REPLACE NANS WITH EMPTY
end


if isnan(OPT.sub_mid_z)
    OPT.sub_mid_z = [] ;             % REPLACE NANS WITH EMPTY
end


%% SET VARS FROM OPT

toe_z = OPT.toe_z  ; % dune/cliff toe elevation
int_base_z = OPT.int_base_z  ; % dune/cliff toe elevation
sub_base_z = OPT.sub_base_z ; % dune/cliff toe elevation

int_mid_z = OPT.int_mid_z    ;
sub_mid_z = OPT.sub_mid_z   ;

%% GET MID PTS FOR [INTD, SUBT]

if isempty(int_mid_z)
    int_mid_z = mean([toe_z, int_base_z])   ;    
end

if isempty(sub_mid_z)
    sub_mid_z = mean([int_base_z, sub_base_z])   ;    
end

zones_z = [toe_z ,  int_mid_z , int_base_z  ,  sub_mid_z,    sub_base_z ]'  ;

%% Create segments struct [ZONES.NAME]
zones = [] ;
zones(1,1).name = 'back' ;
zones(2,1).name = 'int1' ;
zones(3,1).name = 'int2' ;
zones(4,1).name = 'sub1' ;
zones(5,1).name = 'sub2' ;

%% Get INDEXES of zone boundary elevations 
zones_i(1,1) = 1   ;                                        % START of BACK

try
    zones_i(2,1) = find(z0 >  zones_z(1), 1, 'last') + 1  ;     % START of INT1
catch
    zones_i(2,1) = nan  ;
end

try
    zones_i(3) = find(z0 <  zones_z(2) & x0 > x0(zones_i(2)) , 1, 'first')     ;     % START of INT2 
catch
    zones_i(3) = nan;
end
    
try
    zones_i(4) = find(z0 <  zones_z(3) & x0 > x0(zones_i(3)) , 1, 'first')     ;     % START of SUB1
catch
    zones_i(4) = nan;   
end

try
    zones_i(5) = find(z0 <  zones_z(4) & x0 > x0(zones_i(3)) , 1, 'first')     ;     % START of SUB2
catch
    zones_i(5) = nan ;
end

try
    zones_i(6,1) = find(z0 <  zones_z(5)  & x0 > x0(zones_i(4)) , 1, 'first')     ;     % END   of SUB2
catch
    zones_i(6) = nan ;
end

%% Fill ZONE indexes

for i = 1 : length(zones)
    st_i = zones_i(i) ;
    en_i = zones_i(i+1) - 1 ;

    if ~isnan(st_i) && ~isnan(en_i)

        mid_i = round( (st_i + en_i)/2   ) ;
        zones(i).st_i = st_i ;
        zones(i).en_i = en_i ;
        zones(i).mid_i = mid_i ;
        zones(i).ind = [st_i : en_i ]' ;

    else
        zones(i).st_i = [] ;
        zones(i).en_i = [] ;
        zones(i).mid_i = [] ;
        zones(i).ind = [] ;

        % zones(i).st_i = nan ;
        % zones(i).en_i = nan ;
        % zones(i).mid_i = nan ;
        % zones(i).ind = nan ;
    end
end

%% Set OUTPUT VARS [OPT]

% OPT.x0 = x0 ;
% OPT.z0 = z0 ;
OPT.int_mid_z = int_mid_z ;
OPT.sub_mid_z = sub_mid_z ;
OPT.zones_z = zones_z ;
OPT.zones_i = zones_i ;

%% ACTIVE PROFILE HEIGHT [H_A], WIDTH [W_A] , SLOPE [TAN_B]
OPT.h_a = zones_z(1) - zones_z(end) ;
OPT.w_a = zones_i(end) - zones_i(1) ;
OPT.tan_B = OPT.h_a / OPT.w_a  ;


%% END FUNCTION
end





















%%










%%









%%