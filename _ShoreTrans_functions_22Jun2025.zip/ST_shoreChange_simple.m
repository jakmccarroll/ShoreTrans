
function [dX, OPT] = ST_shoreChange_simple(varargin)



%% SET DEFAULTS (OPT)
OPT.SLR =  1   ;      % Sea level rise

OPT.DoC =  []  ;      % Depth of Closure
OPT.back_z = 2.5 ;  % elevation of back of active beach

OPT.h_a =  []  ;      % height of active profile
OPT.w_a =  [] ;      % width of active profile 
OPT.tan_B = 0.02 ;      % profile slope [tan_B = h_a / w_a]

OPT.dV = []     ;      % profile volume change (sediment budget)
OPT.dV_yr = []    ;      % profile volume change (sediment budget)
OPT.Years = 100   ;    % number of years projected


%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'silentIgnore'); 

%% SET VARIABLES

SLR    = OPT.SLR(:) ;
DoC    = -abs(OPT.DoC(:)) ;   % makes DoC negative
back_z = OPT.back_z(:) ;
h_a    = OPT.h_a(:) ;
w_a    = OPT.w_a(:) ;
tan_B  = OPT.tan_B(:) ;
dV     = OPT.dV(:) ;
dV_yr  = OPT.dV_yr(:) ;
Years  = OPT.Years(:) ;

%% CALC SLOPE (TAN_B) and (W_A) (if either is missing)

if isempty(h_a)
    h_a = back_z - DoC ;
    OPT.h_a = h_a ;
end

if isempty(DoC)
    DoC = back_z - h_a ;
    OPT.DoC = DoC ;
end

if isempty(tan_B)
    tan_B = h_a ./ w_a ;
    OPT.tan_B = tan_B ;
end

if isempty(w_a)
    w_a = h_a ./ tan_B ;
    OPT.w_a = w_a ;
end

if isempty(SLR)
    SLR = zeros(size(tan_B)) ;
    OPT.SLR = SLR ;
end

if isempty(dV) & isempty(dV_yr)
    dV = zeros(size(tan_B)) ;
    OPT.dV = dV ;

    dV_yr = dV ./ Years ;
    OPT.dV_yr = dV_yr ;

elseif isempty(dV) & ~isempty(dV_yr)
    dV = dV_yr .* Years ;
    OPT.dV = dV ;

elseif isempty(dV_yr)
    dV_yr = dV ./ Years ;
    OPT.dV_yr = dV_yr ;

end


%% SHORELINE CHANGE CALCULATION (BRUUN PLUS SIMPLE VOL-2-SHR)

dX.SLR_rec = -SLR./tan_B ;                % shoreline change due to SLR (Bruun rule)
dX.sedi_budg = dV./h_a  ;                 % shoreline change due to sediment budget trend
dX.total = dX.SLR_rec + dX.sedi_budg ;    % TOTAL shoreline change

dX.n = length(dX.total) ;

%% GET MEAN AND PCNTILES

if dX.n > 20

    dX.SLR_rec_mean   = nanmean(dX.SLR_rec) ;
    dX.sedi_budg_mean = nanmean(dX.sedi_budg) ;    
    dX.tot_mean       = nanmean(dX.total) ;

    dX.tot_99   = -prctile(-dX.total, 99) ;
    dX.tot_95   = -prctile(-dX.total, 95) ;
    dX.tot_90   = -prctile(-dX.total, 90) ;
    dX.tot_75   = -prctile(-dX.total, 75) ;
    dX.tot_50   = -prctile(-dX.total, 50) ;
    dX.tot_25   = -prctile(-dX.total, 25) ;
    dX.tot_10   = -prctile(-dX.total, 10) ;
    dX.tot_05   = -prctile(-dX.total,  5) ;
    dX.tot_01   = -prctile(-dX.total,  1) ;

end

%% GET INDEXES FOR PERCENTILES (BASED ON RANDOM SAMPLE CALCULATIONS)

if dX.n > 20

    [dX.tot_sort, dX.ind] = sort(-dX.total) ; 
    
    dX.ind_95 =  dX.ind(round(0.95 * dX.n)) ;
    dX.ind_50 =  dX.ind(round(0.50 * dX.n)) ;
    dX.ind_05 =  dX.ind(round(0.05 * dX.n)) ;

    % GET VARS FOR PERCENTILE INDEXES


    dX.p95_tot      = dX.total(dX.ind_95) ;  
    dX.p50_tot      = dX.total(dX.ind_50) ; 
    dX.p05_tot      = dX.total(dX.ind_05) ;     
    
    dX.p95_DoC      = DoC(dX.ind_95) ;   
    dX.p50_DoC      = DoC(dX.ind_50) ;    
    dX.p05_DoC      = DoC(dX.ind_05) ;

    dX.p95_SLR      = SLR(dX.ind_95) ;
    dX.p50_SLR      = SLR(dX.ind_50) ;
    dX.p05_SLR      = SLR(dX.ind_05) ;

    dX.p95_dV_yr    = dV_yr(dX.ind_95) ;    
    dX.p50_dV_yr    = dV_yr(dX.ind_50) ;
    dX.p05_dV_yr    = dV_yr(dX.ind_05) ;

    % dX.p95_SLR      = SLR(dX.ind_95) ;
    % dX.p95_DoC      = DoC(dX.ind_95) ;    
    % dX.p95_h_a      = h_a(dX.ind_95) ;
    % dX.p95_dV       = dV(dX.ind_95) ;
    % dX.p95_dV_yr    = dV_yr(dX.ind_95) ;
    % 
    % dX.p50_SLR      = SLR(dX.ind_50) ;
    % dX.p50_DoC      = DoC(dX.ind_50) ;    
    % dX.p50_h_a      = h_a(dX.ind_50) ;
    % dX.p50_dV       = dV(dX.ind_50) ;
    % dX.p50_dV_yr    = dV_yr(dX.ind_50) ;
    % 
    % dX.p05_SLR      = SLR(dX.ind_05) ;
    % dX.p05_DoC      = DoC(dX.ind_05) ;    
    % dX.p05_h_a      = h_a(dX.ind_05) ;
    % dX.p05_dV       = dV(dX.ind_05) ;
    % dX.p05_dV_yr    = dV_yr(dX.ind_05) ;

end

%% GET INDEXES FOR PERCENTILES OF VARS (JUST BASED ON VARS, NO CALCS)



%%
end

