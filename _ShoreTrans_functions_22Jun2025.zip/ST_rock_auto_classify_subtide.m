%% function [rockInd, OPT] = ST_rock_auto_classify_subtide(x0, z0, varargin)   ----> NOV 2024
% Check for ROCK in SUBTIDAL ---> based on ROUGHNESS


function [rockInd, OPT] = ST_rock_auto_classify_subtide(x0, z0, varargin)

%% SET DEFAULTS (OPT)
OPT.st_z = -1.5  ;   % start of subtidal zone (elevation)
OPT.st_i = [] ;      % start of subtidal zone (index)

OPT.X_ind_min = 1 ;    % search area starts offshore of here

OPT.en_z = -10  ;    % end of subtidal zone (elevation)
OPT.en_i = [] ;      % end of subtidal zone (index)   ----> USE IF APPLYING ROCK CHECK ONLY TO DoC [i.e., OPT.go_to_end = false]

OPT.go_to_end = true  ;  % apply rock check to end of profile (if FALSE, do NOT allow rock offshore of OPT.en_i) 

OPT.gap_max = 100 ;         % join rock sections with gaps between less than [GAP_MAX]
OPT.sec_min = 10 ;         % delete rock sections with extent less than [SEC_MIN]
OPT.dz_limit = 0.1 ;       % threshold slope per metre cross-shore (above this, class as rock)


%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'silentIgnore'); 

%% SET VARS (FROM OPT)

st_z = OPT.st_z ;
st_i = OPT.st_i ;
X_ind_min = OPT.X_ind_min ;
en_z = OPT.en_z ;
en_i = OPT.en_i ;

dz_limit = OPT.dz_limit ;
gap_max = OPT.gap_max ;
sec_min = OPT.sec_min ;

%% IF PROF IS ALL (or mostly) NANS ---> END FUNCTION

ind_good_z = find(~isnan(z0))   ;
n_good_z = length(ind_good_z)    ;

if n_good_z < 100
    rockInd.prof_good = false ;
    rockInd.ind1_01 = nan  ;
    rockInd.ind1 = nan  ;
    
    rockInd.ind2_01 = nan  ;
    rockInd.ind2 = nan  ;

    rockInd.x1 = nan ;
    rockInd.z1 = nan ;
    rockInd.rock_found = false ;
    return
end



%% GET CHANGE IN ELEVATION FOR EACH PT CROSS-SHORE (per 1 m)

dz = [0; diff(z0)] ;

%% GET / FIND SUBTIDAL [ST/EN] INDEX

if isempty(st_i)
    try
        % START OF SUB 1
        st_i = find(z0 < st_z & x0 >= x0(X_ind_min), 1, 'first') ; % update FEB 2025

        % % st_i = find(z0 <  st_z, 1, 'first')     ;     % START of SUB1
        % st_i = find(z0 >  st_z, 1, 'last') + 1     ;     % START of SUB1
    catch
        st_i = nan;   
    end
end

if isempty(en_i)
    try
        en_i = find(z0 <  en_z, 1, 'first')     ;     % END   of SUB2
    catch
        en_i = nan ;
    end
end

%% IF ST_I = NAN ---> END FUNCTION
if isnan(st_i)
    rockInd.prof_good = false ;
    return
end

%% ROUGHNESS INDEX 1 -->> SIMPLE RULE ---> [ABS(DZ) > DZ_LIMIT]
ind1_01 = abs(dz) > dz_limit ;    
ind1 = find(ind1_01) ;  



%% ROUGHNESS INDEX 2.1 --->>>  REMOVE VALUES ONSHORE OF SUBTIDAL (ST_I)

ind2_01 = ind1_01 ;
ind2_01(1 : st_i - 1) = false ;     % !. REMOVE VALUES ONSHORE OF SUBTIDAL

%% ROUGHNESS INDEX 2.2 --->>>  JOIN ROCK SECTIONS WITH SMALL GAPS BETWEEN [GAP_MAX]

for i = 1 : length(ind1) - 1

        if ind1(i) >= st_i     % if index of 'rough' pt is in subtidal...
            gap1 = ind1(i+1) - ind1(i) ;  % calculate gap to next rough pt
        
            if gap1 > 1 && gap1 < gap_max    % check if gap length is below limit [dX_lim]
                gap_i = [ind1(i) : ind1(i+1)]'  ;   % index the gap
                ind2_01(gap_i) = true ;          % fill the gap
            end
        end

end

%% ROUGHNESS INDEX 2.3 --->>>  REMOVE SHORT ROCK SECTIONS [SEC_MIN]

indSec2 = index_logical_sections(ind2_01) ;
for i = 1 : length(indSec2)
    if indSec2(i).length < sec_min
        ind_shrt = indSec2(i).ind ;
        ind2_01(ind_shrt) = false ;
    end
end
ind2 = find(ind2_01) ;

%% ROUGHNESS INDEX 2.4 --->>> IF [OPT.go_to_end = false] REMOVE ROCK FROM BEYOND [EN_I]

if ~OPT.go_to_end
    ind2_01(st_i : end ) = false ;     % !. REMOVE VALUES ONSHORE OF SUBTIDAL
end

%% SET ROCK INDEXES [ROCKIND]

rockInd.st_i = st_i ;
rockInd.en_i = en_i ;

% if n_good_z > 100
rockInd.prof_good = true ;

rockInd.ind1_01 = ind1_01 ;
rockInd.ind1 = ind1 ;
rockInd.ind1_meta = ['ind1 = exceeds slope limit - anywhere on profile'] ;

rockInd.ind2_01 = ind2_01 ;
rockInd.ind2 = ind2 ;
rockInd.ind2_meta = ['ind2 removes: (!) short section; (2) onshore of st_i; (3) offshore of en_i'] ;


% make [x1,z1] --> with NAN for NON-ROCK SECTIONS (FOR PLOTTING)
rockInd.x1 = x0 ;         
rockInd.x1(~ind2_01) = nan ;
rockInd.z1 = z0;
rockInd.z1(~ind2_01) = nan ;

% else
%     rockInd.x1 = [] ;
%     rockInd.z1 = [] ;
% end

rockInd.rock_found = false ;
if ~isempty(ind2)
    rockInd.rock_found = true ;
end


%% END FUNCTION
end







%%








%%
