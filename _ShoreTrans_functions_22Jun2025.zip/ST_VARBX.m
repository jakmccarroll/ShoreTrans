%% ST_VARBX --> Calculate storm demand impact on profile
% function [vx] = ST_VARBX(x0, z0, vx, OPT)
% 5/4/2021
% Follows the method in Kinsela et al. (2017)
    % Kinsela, M. A., Morris, B. D., Linklater, M., & Hanslow, D. J. (2017). 
    % Second-pass assessment of potential exposure to shoreline change in New South Wales,
    % Australia, using a sediment compartments framework. Journal of Marine Science and Engineering, 5(4), 61.
    % https://www.mdpi.com/2077-1312/5/4/61
%
% INPUTS
% x0 = input x-values for profile
% x0 = input z-values for profile
% vx.dV_target  % STORM DEMAND VOLUME (m3/m)
% vx.Z1 = 2;    % (Z1-BF-TOP) TOP of beachface
% vx.Z2 = 0;    % (Z2-BF-BOT) BOTTOM of BEACHFACE (take angle from Z1-BF-TOP to Z2-BF-BOT and shift onshore)
% vx.Z3 = -1;   % (Z3-PIV) PIVOT pt (join translated Z2-BF-BOT to original Z3-PIVOT pt)
% vx.Z4 = -6;   % (Z4-STRM-BOT) BOTTOM of STORM BAR pt (lost volume shifted as a sine curve offshore to 
% OPT   ----------> ST_MAIN OPT
% OPT.duneSlope = slump slope for dune
% OPT.toeCrest_level

function [vx, OPT] = ST_VARBX(x0, z0, vx, OPT)

%% SET DEFAULTS (OPT)
% OPT.wallSwitch =  0  ;    % seawall present = 1 ; no wall = 0
% 
% OPT.dV_target = -50 ;  % STORM DEMAND VOLUME (m3/m)
% OPT.Z1 = 2;    % TOP of beachface
% OPT.Z2 = 0;    % BOTTOM of BEACHFACE (take angle from TOP to MID and shift onshore)
% OPT.Z3 = -1;   % PIVOT pt (join translated MID to original PIVOT pt)
% OPT.Z4 = -6;   % BOTTOM of STORM BAR pt (lost volume shifted as a sine curve offshore to 

%% SETPROPERTY -> available with openEarthTools (Deltares)
% [OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'warnAppend '); 
% 
% vx.dV_target = OPT.dV_target ;
% vx.Z1 = OPT.Z1 ;    % TOP of beachface
% vx.Z2 = OPT.Z2 ;    % BOTTOM of BEACHFACE (take angle from TOP to MID and shift onshore)
% vx.Z3 = OPT.Z3 ;   % PIVOT pt (join translated MID to original PIVOT pt)
% vx.Z4 = OPT.Z4 ;   % BOTTOM of STORM BAR pt (lost volume shifted as a sine curve offshore to 

%% VOL TARGETS
dV = 9999;
dV_target = vx.dV_target;
vx.dX = 0;

if ~isfield(vx, 'disp_out')
    vx.disp_out = 0;
end

% dV ERROR OFFSET
% Add a small Vol offset (or buffer), to avoid always overshooting dV_target ...
% ... due to use of "while dV > dV_target"
% e.g., err_offset ~= (beachface profile height) ~= 2
% use if trying to reach a precise volume loss
if ~isfield(vx, 'err_offset')
    vx.err_offset = 0;   
end


%% IF NO WALL PRESENT
if OPT.wallSwitch == 0
    while dV > (dV_target + vx.err_offset)

        vx.dX = vx.dX - 1;
        vx = ST_VARBX_2(x0, z0, vx, OPT) ;
        dV = vx.dV;

        if vx.disp_out == 1
            disp(['VARBX: For dX = ' num2str(vx.dX) ' m,  dV = ' ...
                num2str(vx.dV, '%0.1f') ' m3/m']);
        end
    end
    vx.dV = dV;
end


%% IF WALL PRESENT
if OPT.wallSwitch == 1

    % JULY 2024  --> OPT.toeCrest_level2, OPT.DoC_ind don't exist
    %     --> run ST_MAIN (with zero change) as workaround to update OPT (NEEDS FIX!!!!!!)

    % if ~isfield(OPT, 'toeCrest_level2')       
    %     OPT.toeCrest_level2 = OPT.toeCrest_level ;
    % end

    while dV > dV_target
        vx.dX = vx.dX - 1;
%       vx.dX = -21

        vx = ST_VARBX_2(x0, z0, vx, OPT);
        dV_noWall = vx.dV;
        
        vx.z_noWall = vx.z_final;
        z_temp = vx.z_final; 
        z_temp(x0<x0(OPT.wall_ind) ) = z0(x0 < x0(OPT.wall_ind) );
        
        [vx.z_final, ~] = ST_WALL_VOL...
            (x0, z0, z_temp, vx.z_noWall, OPT, vx.dX);
        
        V_initial = trapz(x0(1:vx.i3), z0(1:vx.i3) - vx.Z3)  ;
        % offset z to vx.Z3 = base of storm cut
        V_final = trapz(x0(1:vx.i3), vx.z_final(1:vx.i3) - vx.Z3);
        dV = V_final - V_initial  ;
        
        if vx.disp_out == 1
            disp(['VARBX: For dX = ' num2str(vx.dX) ' m,  dV = ' ...
                num2str(dV, '%0.1f') ' m3/m']);
        end
    end
     vx.dV = dV;
end


%%







%%









%%