%% figpos -> set position of figure
% function figpos(ox,oy,sx,sy) 
    % set(gcf,'position',[sz(3)*ox sz(4)*oy sz(3)*sx sz(4)*sy]);
    % INPUTS
        % ox, oy -> fig x,y origin as a ratio of screensize
        % sx,sy -> fig x,y size as a ratio of screensize

function figpos(varargin)

if nargin==0
    ox=.3;
    oy=.2;
    sx=.5;
    sy=.6;

elseif nargin == 1
    ox = varargin{1}(1);
    oy = varargin{1}(2);
    sx = varargin{1}(3);
    sy = varargin{1}(4);  

elseif nargin == 4
    ox=varargin{1} ;
    oy=varargin{2} ;
    sx=varargin{3} ;
    sy=varargin{4} ;
end

r = groot; % Graphics properties
if size(r.MonitorPositions, 1) == 1
    ox = ox - floor(ox);
    disp('figpos detected only one monitor')
end

sz=get(0,'screensize')   ;
set(gcf,'position',[sz(3)*ox sz(4)*oy sz(3)*sx sz(4)*sy]);


end