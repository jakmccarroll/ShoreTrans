%% [shore1] = ST_groyne(shore, groyne, T_chain, OPT) - Mar 2024
% Input a shoreline and groyne (TID location, X-length)
% Output a new shoreline modified by the groyne impact on longshore drift
%
% INPUTS
% - shore - shore.x, shore.y, shore.TID, shore.xT, shore.yT
% - 
% ----> use VS1_prof2shr (on PROF struct --> NEEDS [U] struct as input - must be a VCMP Site)
%
% - groyne - groyne.x(2-pts), .y(2-pts), 
% ---- OR --- groyne.TID, groyne.X_extent
%
% - T_chain - struct, size(length(TID),1), .X,.x (1 x length(X_chain),.y(length(X_chain),1)
% ---> [T_chain, OPT] = shore_transects_chain(xT, yT, OPT)   ;
%
% - varargin = OPT (see SET DEFAULTS BELOW)
%
% OUTPUTS
% - shore1 - .X1,x1,y1 ;
% --- shore1.up_ind, .dn_ind --> index in TIDs updrift/downdrift
% --- shore.X_up, .X_dn ---> shoreline change for each transect -- length(.X_up) = length(up_ind) 
%  
% EXAMPLE
% OPT.X_ration = 0.7; OPT.dip_ratio = 0.2;
% OPT.prof = prof (structure with length(TIDs) --> 1 row per transect)
% ---> prof.TID, .x0, .z0 --> for STrans --> x0,y0 need size [1 x ~1000+] to reach DoC  
% [shore1] = ST_groyne(shore, groyne, T_chain, OPT) 

function [shore1, groyne1, OPT] = ST_groyne(shore, groyne, T_chain, varargin)

%% SET DEFAULTS (input 'OPT' to varargin when calling function) 

OPT.type = 1; % 1 = polynomial ; (NO OTHER OPTIONS AVAILABLE YET)

OPT.X_ratio = 0.8;
OPT.X_dist = [] ;
OPT.Y_ratio = 5 ; % alongshore extent ( = Y_ratio * X_dist)
OPT.Y_dist  = [];

OPT.drift_dir = 1 ; % 1 = in dirn of increasing TID | -1 = dirn decrease TID

OPT.dip_ratio = 0.25 ; % shape of shoreline curve around groyne
%   0 = linear | 0.25 = greater curve (parabola) 
%     avoid values > 0.25, get negative shore values away from groyne

% RUN VOLUME ON PROFS (SHORETRANS)
OPT.prof_switch = 0; % run profile volumes in ShoreTrans (0 - Off [default], 1 - On);
% --> if prof_switch is OFF --> output is [x1,y1] shoreline
% --> if prof_switch is ON  --> extra output [x1p, y1p]
OPT.prof = [];  % 
OPT.ST_OPT = []; % ST_MAIN OPTIONS


%% [OPT] SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'silentIgnore'); 

if isempty(OPT.ST_OPT)
    OPT.ST_OPT = ST_OPT_defaults ;
end

%% EXTRACT VARS
x = set_rowcol(shore.x, 'col') ;
y = set_rowcol(shore.y, 'col') ;

g_x = set_rowcol(groyne.x, 'col') ;
g_y = set_rowcol(groyne.y, 'col') ;


%% SHORELINE DISTANCE
[shore.S, shore.dS] = line_distance(shore.x, shore.y)  ;

%% GET Groyne Geometry
interS = InterX([x'; y'], [g_x'; g_y'])    ;
groyne.interS(1) = interS(1,1)   ;
groyne.interS(2) = interS(2,1)   ;

% LENGTH ASSUMES GROYNE IS SHORE NORMAL --->  NEEDS FIX !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
groyne.len1 = hypot(groyne.x(2) - groyne.interS(1) , groyne.y(2) - groyne.interS(2) )  ;

% inputs: x,y values; theta angle to rotate in degrees
% outputs: x1, y1 - the rotated values
% [x1,y1]=rotatefun(x,y,theta)

[~, Dist] = knnsearch(groyne.interS , [x,y])   ;
[~, srt_i] = sort(Dist) ;
TID_Dist = [ shore.TID(srt_i) , Dist(srt_i) ]  ;

% GET GROYNE LENGTH --> PROJECT GROYNE END PT ONTO TRANSECT LINE
TID_gi = TID_Dist(1,1)  ;
sh_i = shore.X_ind(TID_gi) ;
vector = [T_chain(TID_gi).x(sh_i), T_chain(TID_gi).y(sh_i) ; ...
    T_chain(TID_gi).x(end) , T_chain(TID_gi).y(end)  ]  ;
q = [groyne.x(end), groyne.y(end)]   ;
proj_pt = project_pt_on_line(vector, q) ;
% % EXAMPLE
% vector = [3,0; 7,10]; % = [x1,y1 ; x2,y2]
% q = [3,5];            % = [qx1, qy1]
% 
% [ProjPoint] = project_pt_on_line(vector, q)

groyne.len = hypot(vector(1,1) - proj_pt(1), vector(1,2) - proj_pt(2)   ) ;
groyne.TID_gi = TID_gi;
groyne.sh_i   = sh_i  ;
groyne.vector = vector;
groyne.proj_pt = proj_pt;

% GET NEGATIVE / POSITIVE ALONGSHORE TID INDEXES (adjacent to groyne)
if TID_Dist(1,2) == 0  % case where groyne on shore pt (theoretical)
    TID_neg_pos = TID_Dist(2:3,1) ;
else
    TID_neg_pos = TID_Dist(1:2,1) ;
end

TID_neg  = min(TID_neg_pos)  ;
TID_pos = max(TID_neg_pos)  ;
neg_st_i = find(shore.TID == TID_neg)  ;
pos_st_i = find(shore.TID == TID_pos)  ;

var_names = {'TID_neg', 'TID_pos', 'neg_st_i', 'pos_st_i'};
vars = {TID_neg, TID_pos, neg_st_i, pos_st_i};
groyne = add_vars2struct(groyne, var_names, vars) ;

% groyne.TID_neg = TID_neg;     groyne.TID_pos = TID_pos; 
% groyne.neg_st_i = neg_st_i;   groyne.pos_st_i = pos_st_i;


%% DISTANCE ALONGSHORE from GROYNE to SHORE PTS (NEG/POS ALONGSHORE FRAME --> NOT UP/DOWN)

% insert groyne into shoreline
xg = [x(1:neg_st_i); groyne.interS(1); x(pos_st_i :end)]  ; 
yg = [y(1:neg_st_i); groyne.interS(2); y(pos_st_i :end)]  ;

[Y1, dY1] = line_distance(xg, yg)   ; % distance alongshore from 1st shr pt (including groyne pt in shoreline)

gi = neg_st_i + 1   ;  %  index of groyne pt, in shoreline that includes groyne
dYg1 = Y1 - Y1(gi)   ; % distance alongshore from groyne

dYg0 = dYg1  ;
dYg0(gi) = [];  % distance from groyne to shr-pts (groyne REMOVED from shoreline)

var_names = {'gi','xg','yg','dYg1','dYg0'};
vars = {gi, xg, yg, dYg1, dYg0};
shore = add_vars2struct(shore, var_names, vars) ;

% shore.gi = gi;
% shore.xg = xg; % shoreline with groyne included 
% shore.yg = yg;
% shore.dYg1 = dYg1; % (with groyne INCLUDED) shoreline distance to groyne (length includes groyne pt)
% shore.dYg0 = dYg0; % (without groyne)

%% X-Y-EXTENT of ACCRETE / ERODE at GROYNE
X_ratio = OPT.X_ratio ;
Y_ratio = OPT.Y_ratio ;

if isempty(OPT.X_dist)
    X_dist = X_ratio * groyne.len  ;
    OPT.X_dist = X_dist   ; 
else
    X_dist = OPT.X_dist;
end

if isempty(OPT.Y_dist)
    Y_dist = Y_ratio * OPT.X_dist  ;
    OPT.Y_dist = Y_dist   ; 
else
    Y_dist = OPT.Y_dist;    
end

%% X-Y-EXTENT INDEXES
% neg_en_i = index furthest pt from groyne to be impacted (in NEGATIVE alongshore direction)
neg_en_i = find(dYg0 > -Y_dist, 1, 'first')   ; 
neg_en_TID = shore.TID(neg_en_i)  ;
neg_ind = [neg_en_i : neg_st_i ] ; % ind of groyne impact zone (in NEG dir = decreasing TID)

% pos_en_i = index furthest pt from groyne to be impacted (in POSITIVE alongshore direction)
pos_en_i = find(dYg0 <  Y_dist, 1, 'last')    ;
pos_en_TID = shore.TID(neg_en_i)  ;
pos_ind = [pos_st_i : pos_en_i ] ; % ind of groyne impact zone (in POS dir = increasing TID)


%% GET UP/DOWN IND
if OPT.drift_dir == 1
    up_st_i = neg_st_i;     up_en_i = neg_en_i;
    dn_st_i = pos_st_i;     dn_en_i = pos_en_i;    
    up_ind = neg_ind;   % UPDRIFT index (positive drift)
    dn_ind = pos_ind;   % DOWNDRIFT index (positive drift)
    TID_up = TID_neg;
    TID_dn = TID_pos;

elseif OPT.drift_dir == -1
    up_st_i = pos_st_i;     up_en_i = pos_en_i;
    dn_st_i = neg_st_i;     dn_en_i = neg_en_i;        
    up_ind = pos_ind;   % UPDRIFT index (negative drift)
    dn_ind = neg_ind;   % DOWNDRIFT index (negative drift)
    TID_up = TID_pos;
    TID_dn = TID_neg;
end

var_names = {'neg_en_i', 'neg_en_TID', 'neg_ind', 'pos_en_i', 'pos_en_TID', 'pos_ind',...
    'TID_up', 'TID_dn', 'up_st_i','up_en_i','dn_st_i','dn_en_i', 'up_ind', 'dn_ind'};
vars = {neg_en_i, neg_en_TID, neg_ind, pos_en_i, pos_en_TID, pos_ind,...
    TID_up, TID_dn,   up_st_i, up_en_i, dn_st_i, dn_en_i,      up_ind, dn_ind};
shore = add_vars2struct(shore, var_names, vars) ;
groyne = add_vars2struct(groyne, var_names, vars) ;

%% GROYNE SHAPE FUNCTION
Y_up = dYg0(up_ind)   ;
Y_dn = dYg0(dn_ind)   ;

% 2nd deg poly
% (m1,a) are 'gradient' and Y-offset of parabola
% (m2) is gradient of line

X_poly2 = @(YY, m2,a, m1,b) m2.*(YY + a).^2 + m1.*YY + b ;  

dip_ratio = OPT.dip_ratio   ;  % curve of line (ratio)
dip1 = dip_ratio .* X_dist  ;  % curve (magnitude)

a = Y_dist/2 ;           % parabola Y-shore-intercept (offset, x-axis)
m2 = dip1 / a^2 ;        % parabola gradient
b2 = dip1    ;           % parabola - X-shore-int (offset, y-axis) 

b1 = X_dist ;      % X-intercept (combined line and parabola)
m1 = X_dist / Y_dist ;   % gradient of line

if OPT.drift_dir == 1
    X_up = X_poly2(Y_up,  m2, a,   m1,  b1 - b2) ;
    X_dn = X_poly2(Y_dn, -m2, -a,  m1, -b1 + b2) ;

elseif OPT.drift_dir == -1
    X_up = X_poly2(Y_up,  m2, -a,  -m1,  b1 - b2) ;
    X_dn = X_poly2(Y_dn, -m2, a, -m1, -b1 + b2) ;
end

var_names = {'Y_up', 'Y_dn', 'X_poly2', 'dip_ratio', 'dip1', 'a', 'm2', 'b2', 'b1', 'm1'};
vars = {Y_up, Y_dn, X_poly2, dip_ratio, dip1, a, m2, b2, b1, m1};
groyne.shape = [];
groyne.shape = add_vars2struct(groyne.shape, var_names, vars) ;

%% OUTPUTS FROM SHAPE FUNCTION (X_ind1, x1, y1)

shore.X_up = X_up;
shore.X_dn = X_dn;

X_ind0 = shore.X_ind ;
X_ind1 = X_ind0;

X_ind1(up_ind) = X_ind0(up_ind) + round(X_up) ;
X_ind1(dn_ind) = X_ind0(dn_ind) + round(X_dn) ;

X1 = shore.X; x1 = x; y1 = y;

for i = 1 : length(T_chain)
    X1(i) = T_chain(i).X( X_ind1(i) ) ;
    x1(i) = T_chain(i).x(X_ind1(i)) ;
    y1(i) = T_chain(i).y(X_ind1(i)) ;
end

shore.X_ind1 = X_ind1;
shore.X1  = X1;
shore.x1 = x1; 
shore.y1 = y1;
shore.dX1 = X_ind1 - X_ind0 ;

%% SETUP OUTPUTS - SHORE1, GROYNE

shore1 = shore;
groyne1 = groyne;


%% RUN ST_TRANSLATOR FOR FIXED Xi

if OPT.prof_switch == 1
    prof1 = OPT.prof  ;

    [shore1, prof1] = ST_groyne_run_profs(shore, prof, OPT.ST_OPT)  ;

end



%% END FUNCTION
end

%%

%%

%% SCRAPS --> add vars to shore

% shore.neg_en_i = neg_en_i  ;
% shore.neg_en_TID = neg_en_TID  ;
% shore.neg_ind = neg_ind    ;
% 
% shore.pos_en_i = pos_en_i  ;
% shore.pos_en_TID = pos_en_TID  ;
% shore.pos_ind = pos_ind    ;
% 
% shore.TID_up = TID_up;
% shore.TID_dn = TID_dn;
% shore.up_ind = up_ind;
% shore.dn_ind = dn_ind;


%% SCRAPS --> X-Y-EXTENT IND (USING PRE-CALCD UP/DOWN CONVENTION)
% if OPT.drift_dir == 1
%     up_en_i = find(dYg0 > -Y_dist  , 1, 'first')  ;
%     up_en_TID = shore.TID(up_en_i)  ;
%     up_ind = [up_en_i : upi1 ] ;
% 
%     dn_en_i = find(dYg0 <  Y_dist, 1, 'last')    ;
%     dn_en_TID  = shore.TID(dn_en_i);
%     dn_ind = [dni1  : dn_en_i] ;
% 
% elseif OPT.drift_dir == -1
%     up_en_i = find(dYg0 > -Y_dist  , 1, 'first')  ;
%     up_en_TID = shore.TID(up_en_i)  ;
%     up_ind = [up_en_i : upi1 ] ;
% 
%     dn_en_i = find(dYg0 <  Y_dist, 1, 'last')    ;
%     dn_en_TID  = shore.TID(dn_en_i);
%     dn_ind = [dni1  : dn_en_i] ;
% 
% end

% shore.up_en_i = up_en_i  ;
% shore.up_en_TID = up_en_TID  ;
% shore.up_ind = up_ind    ;
% shore.dn_en_i = dn_en_i  ;
% shore.dn_en_TID = dn_en_TID  ;
% shore.dn_ind = dn_ind    ;


%% SCRAP --> UP/DOWN VERSION OF INDEX TID NEXT TO GROYNE
% if OPT.drift_dir == 1      % if DRIFT = POS --> TID_up is first
%     groyne.TID_up = min(TID_dn_up)  ;
%     groyne.TID_dn = max(TID_dn_up)  ;
% elseif OPT.drift_dir == -1  % if DRIFT = NEG --> TID_up is last
%     groyne.TID_up = max(TID_dn_up)  ;
%     groyne.TID_dn = min(TID_dn_up)  ;
% end

% DISTANCE ALONGSHORE from GROYNE to SHORE PTS (POS == DOWNDRIFT)
% upi = find(shore.TID == groyne.TID_up)  ;
% dni = find(shore.TID == groyne.TID_dn)  ;
% upi1 = upi; 
% dni1 = dni;
% xg = [x(1:upi); groyne.interS(1); x(dni:end)]  ;
% yg = [y(1:upi); groyne.interS(2); y(dni:end)]  ;
% [Y1, dY1] = line_distance(xg, yg)   ;
% 
% gi = upi + 1   ;
% dYg1 = Y1 - Y1(gi)   ;
% dYg0 = dYg1  ;
% dYg0(gi) = []; % 

% shore.xg = xg; % shoreline with groyne included 
% shore.yg = yg;
% shore.dYg1 = dYg1; % (with groyne INCLUDED) shoreline distance to groyne (length includes groyne pt)
% shore.dYg0 = dYg0; % (without groyne)

%%

% g_int = InterX([shore.x; shore.y], [groyne.x, groyne.y]) 
% g_int_i = find(y == groyne.y(1))    % groyne intersect index
% g_len = groyne.x(2) - x0(g_int_i)    % groyne length (x-shore, from initial shoreline)
% 

%% FIND OUTPUT SHORE (x1)
% dist_y = OPT.y_dist;
% dist_x = g_len .* OPT.x_ratio;
% 
% % UPDRIFT INDEX
% up_ind = [g_int_i : g_int_i + dist_y ]';
% 
% % LINE
% % x = my + b
% m =  dist_x / dist_y  % (rise/run) =
% b = dist_x;
% 
% 
% x1 = x0;

%% OUTPUTS





