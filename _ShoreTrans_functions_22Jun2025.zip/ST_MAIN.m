%% ST_MAIN
% May 2021, Jak McCarroll
% Use: Run SHORETRANS shoreface translation model
%
% INPUTS
    % x0, z0 -> profile coords, x-positive is offshore
    % dV_input -> sediment budget change (m3/m)
    % varargin (see SETTINGS below)
% OUTPUTS
    % outProf -> all outputs to a single structure,...
    % OPT -> returns initial settings, with modifications
function [outProf, outPROFS, OPT] = ST_MAIN(x0, z0, dV_input, varargin)

%% SETTINGS (VARARGIN, use SETPROPERTY from openEarthTools)
% Translation increment/distance
% x = positive offshore
%% SET DEFAULTS
OPT.dX    = 1;   % increment to translate profile off-/onshore (must be positive)
OPT.X_off = 0;    % max distance to translate profile OFFSHORE (progradation, default = 0)
OPT.X_on  = -100;  % max distance to translate profile ONSHORE (recession, default = -100)
OPT.X_dir = -1;   % trend profile movement -> -1=Receeding; +1=Prograding

% SLR options
OPT.dS = 1; % sea-level rise magnitude (default = 1 m)
    % set to 0 if no SLR
OPT.S_initial = 0; % initial sea-level (default = 0 m)
    % This will be non-zero when doing a second-stage of translation
OPT.dt = 80; % time step in years (Added NOV 2021 --> for cliff recession)
OPT.DoC  = -10; % (UPPER) Depth of closure (default = 10 m)
OPT.DoC_first_last = 2; % 1 = DoC will be the FIRST point that dips below the set level; 
    % 2 = DoC is LAST point (-1) above the level [default = 2]
OPT.DoC2 = []; % (LOWER) Depth of Closure 2 (default = if empty, set to DoC * 2)

% Profile shape options
    % provide either a z-level or index (relative to x0,z0)
    % for the position of the dune toe OR barrier crest
OPT.toeCrest_level   =  [];
OPT.toeCrest_ind  =  [];
    % If both _level and _ind are given, these are used.
    % If no input is given, the toe/crest ...
    % ... will be taken as the max elevation of the profile.   
    % wallLevel and toeCrestLevel can be equal
    % wall can be behind the toe (e.g. cliff buried behind dune face),...
    % ... OR wall can be in front of barrier (e.g. Torcross, where ...
    % ... sheet piling wall is offshore of top of berm/crest when moderately accreted)
OPT.toeCrest_fixedLevel = 0;   % 1 = toeCrest elevation does NOT rise with SL ...

OPT.rollover = 0  ; % use rollover (1 = ON, 0 = OFF, 2=ON (but don't keep up with SLR)
    % (ROLLOVER ON), barrier crest rolls back, maintaining height,...
    % ... and/or rising with sea-level. 
    % (ROLLOVER OFF), erosion will eat back into dune/barrier,...
    % ... crest height not mainteined or raised with SLR
    % (ROLLOVER = 2), barrier rolls back but is restricted to current absolute height,
    % ... will NOT maintain height relative to SLR

% HOW TO SET ROLLOVER OPTIONS TO MATCH "TYPE 1-4" in MCCARROLL ET AL. 2021 
    % TYPE 1 - FULL ROLLOVER
        % OPT.rollover = 1, OPT.toeCrest_ind = [index of LAGOON TOE]
    % TYPE 2 - ROLLOVER CREST (WITH BACKSLOPE), KEEP UP WITH SLR
        % OPT.rollover = 1, OPT.toeCrest_ind = [index of CREST OF BARRIER] OR OPT.toeCrest_level = [max(z0)]
    % TYPE 3 - ROLLOVER, DON'T KEEP UP WITH SLR (MAINTAIN INITIAL ELEVATION)
        % OPT.rollover = 2, OPT.toeCrest_ind = [index of CREST OF BARRIER] OR OPT.toeCrest_level = [max(z0)]
    % TYPE 4 - ENCROACH (NO ROLLOVER)
        % OPT.rollover = 0, OPT.toeCrest_ind = [index of DUNE TOE]

OPT.roll_backSlope = 4; % if rollover is ON... (default = 4deg)
    % ... this is the angle (in degrees) of the onshore slope, ...
    % ... behind the the transformed barrier crest.
OPT.roll_flatCap = 0 ;     % [0 = OFF]
    % 1 = if roll_backSlope is applied, this adds a 'flat-top' to the dune crest
    % width of flat dune cap = [OPT.roll_flatCap]

OPT.duneSlump = 1; % use DUNE SLUMPING (1=ON, 0=OFF)
OPT.duneSlope = 30; % if rollover is OFF... (default = 30deg)
    % ... the dunes get eaten into and this is the angle of ...
    % ... repose of the dune post-translation duneface.
OPT.slumpCap   = 100; % when applying slumping, ignore pts above this level ...
    % ... this avoids slumping of steep cliffs / dunes that are well above the active profile.

OPT.duneAccrete   = 0;   % use DUNE ACCRETION (1=ON, 0=OFF)
OPT.duneAcc_Vol   = 100;   % VOLUME to accrete dunes
OPT.duneAcc_Dist  = 100; % DISTANCE (behind ToCr) over which to apply the DUNE VOL CHANGE

OPT.duneHGrow = 0;       % (1=ON, 0=OFF)  FORCE dunes to GROW HORIZONTALLY (take sediment from active shoreface)
OPT.duneHGrow_m = 0;     % METRES of HORZ DUNE GROWTH
% OPT.duneHGrow_V = 0;   % VOLUME of DUNE HORIZONTAL GROWTH
OPT.duneHGrow_crest = 0; % CREST of dune (ht above present SL) to grow from

% Rock layer options
OPT.rockSwitch = 0; % rock switch (1 = ON, 0 = OFF [default])
    % RockLayer ON -> a check is made to ensure the translated profile,...
    % ... stays above the rock layer (see next input, OPT.Rock_z)
    
OPT.rockLayer = z0 - 100; % CHANGE 31/1/2020, create DUMMY ROCK LAYER
    % ... to solve issues (e.g. in _SLUMP function) requiring rocks to run
% OPT.rockLayer=[]; % rock layer (vector, same size as z0)
    % If RockSwitch is ON, RockLayer is the rock profile

% Wall-redistribution ("imaginary erosion" zone behind wall/cliff)
    % using Beuzen2018
OPT.wallSwitch = 0; % erode "imaginary" zone behind a wall (ON=1,OFF=0 [default])
    % If a wall (or cliff) exists, erode into the area
    % ... behind the wall, then transfer ...
    % ... the eroded volume offshore of the wall.
    % ... NO EROSION CAN OCCUR ONSHORE of the WALL.
    % ROLLOVER=ON does not work with WALL=ON
% If wallSwitch = ON, provide either...
    % 1. wallLevel (z-level) -> wall starts when profile first dips below this point)
    % 2. wall_ind  (x0,z0 - index) -> wall starts at this position
    % If no input, max elevation of the profile will be used.
OPT.wall_level = nan;  
OPT.wall_ind   = nan; 
OPT.wall_x     = nan;
OPT.wall_overwash = 0; % Wall overwash (21/5/2020) 
    % if wall_overwash = 1, sediment is allowed to pile behind the wall 
    % ... for accretion / positive sediment budget cases
OPT.wall_z_min_check = 0; % 1 = check to see if pt offshore of wall has eroded below WALL_Z_MIN
    % ... translation loop will break once that pt is reached
OPT.wall_z_min = -2; % Cap on how much erosion can occur offshore the wall
    % Once erosion immediately off the wall reaches WALL_Z_MIN (+ dS),...
    % ... these profiles will get tagged and be excluded from further analysis
OPT.wall_no_erode_behind = 1 ; % 0 = allows erosion behind wall; 1 = no erosion behind wall permitted

OPT.redist_ratio = 0.33; % if wallRedist = ON...
    % ... this is the cross-shore portion of the profile that the...
    % ... "behind the wall" volume is transfered to,...
    % ... starting offshore of the wallLevel (or wall_ind) point.

% ERODIBLE CLIFFS (added Nov 2021)
% CLIFF EROSION
OPT.cliff_switch = 0; % Turn on cliff erosion (cliffSwitch = 1 --> ON)
OPT.cliff_ind = nan;
OPT.cliff_x = nan;
OPT.cliff_level = nan;
OPT.cliff_vol_conserve_ratio = 1; % Ratio of volume conserved if cliff eroded...
    % ... soft rock cliffs may have high levels of fine sediment, ...
    % ... which floats away so is ignored in subsequent vol calcs.
OPT.cliff_slope = nan;
OPT.cliff_slope_dx = 5; % x-shr distance (span onshore of cliff toe) to estimate cliff slope
OPT.cliff_SLR_rate0 = 0.003; % initial rate of SLR (default = 3mm/year)
OPT.cliff_SLR_rate1 = 0.01  ; % final rate of SLR % final rate of SLR
OPT.cliff_REC_rate0 =  -0.1; % initial rate of cliff recession
OPT.cliff_m_coeff = 1/2    ; % response factor "m" in ASHTON 2011
OPT.cliff_REC_rate1 = nan;
OPT.cliff_dX = nan;
% OPT.cliff_REC_rate1 = OPT.cliff_REC_rate0 * (OPT.cliff_SLR_rate1/OPT.cliff_SLR_rate0).^OPT.cliff_m_coeff; 
    % ... final rate of cliff recesion: r2 = r1*(dS_dt2 / dS_dt1)^m
    % ... (ASHTON, 2011)
% OPT.cliff_dX = OPT.cliff_REC_rate1 * OPT.dt;
OPT.cliff_dV = 0; % change in volume to active prof due to cliff erosion 
    % ... POSITIVE OPT.cliff_dV --> eroded cliff has ADDED to active prof volume

OPT.cliff_erode_platform = 2 ; % shape of erosion surface for cliff erosion zone
% 0 - no platform (?? - check results)
% 1 - flat surface at new sea level
% 2 - slope surface from new sea level (onshore) --> linear interp to rock surface offshore of original cliff toe

OPT.cliff_erode_to_rock_check = false ;   % catch profiles that erode all the way to rock

% -----

OPT.slumpCheck = 0; % (1=ON, 0=OFF) ---> runs across the final profile ...
    % ... to fix any vertical "sand cliffs", ...
    % ... this is required if prograding out from a vertical wall.
    % PROBLEM (19/2/2020) - SLUMPING can occur BEHIND WALLS
        % ... see DFIG3 script, and switch on duneSlump to investigate

OPT.deepOn     = 0; % Onshore tranport from <DoC1 (0=OFF [default], 1=ON)  
OPT.deepOn_V   = 0; % volume of deep onshore transport
                % Positive = Offshore; Negative = Onshore.
   
OPT.shortOutput = 1; % 0-FULL output (lots of memory, for debugging); 1 = SHORT Output (saves memory)
OPT.optimizer   = 1; % 1 = use OPTIMIZER function to find translation distance (FAST), 
    % 0 = translate profile across a fixed range
OPT.error_bypass = 0;  % when calling OPTIMIZER (from MAIN) a "catch-all" try/catch statement...
    % set OPT.error_bypass = 1 --> allow errors (e.g., if running many profiles, BAD profiles are NAN'd, but won't break the run).
    % set OPT.error_bypass = 0 --> break when an error occurs.
    
%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'warnAppend'); 
% [OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'silentIgnore'); 
% 'silentIgnore' - added Mar2024 (JM)
% 'warnAppend' - change to - Nov 2024 (JM)

OPT.dV_input = dV_input ;
OPT.SL0 = OPT.S_initial ;
OPT.SL1 = OPT.S_initial + OPT.dS ;

%% x0,z0 -> check format, make column vectors
if isrow(x0),     x0 = x0';    end
if isrow(z0),     z0 = z0';    end
if isrow(OPT.rockLayer),     OPT.rockLayer = OPT.rockLayer';    end

%% Translation increment (dX) and range (X_range)
% x is positive offshore
dx = x0(2) - x0(1); % little-dx = spacing of input profile
dX = OPT.dX;        % big-dX    = step-size to march profile on/offshore
X_dir = OPT.X_dir;
if X_dir == -1 % RECEEDING trend (default)
    X_range = [OPT.X_off: -dX : OPT.X_on]'; 
elseif X_dir == 1 % PROGRADING trend
    X_range = [OPT.X_on: dX : OPT.X_off]';  
else
    error(['X_dir not set correctly. X_dir must be -1 (receeding profile) or +1 (prograding profile),' ...
        ' dX sets the increment at which to calculate profile translation.']);
end
X_len = length(X_range);
OPT.X_len = X_len;
OPT.X_range = X_range;

% WARN IF X_on > 0
if OPT.X_on > 0 
    warning(['Onshore translation distance (X_on) has been set as a POSITIVE VALUE.'...
        10 'POSITIVE is OFFSHORE, therefore onshore translation must be a NEGATIVE VALUE']);
end

%% SLR settings
dS=OPT.dS; % sea-level rise magnitude (default = 1 m)
S_initial = OPT.S_initial;  % initial sea-level 
S_final   = S_initial + dS; % final sea-level
OPT.S_final = S_final;

%% DoC index (Depth of Closure)
% DoC - UPPER
DoC = OPT.DoC;
if OPT.DoC_first_last == 1
    DoC_ind = find(z0 < DoC, 1, 'first')   ;
elseif OPT.DoC_first_last == 2
    DoC_ind=find(z0 >= DoC, 1, 'last') + 1  ;
    % changed 13/5/2020, from 'first < DoC' to fix issue with full depletion
    % in front of wall detecting a DoC immediately offshore of wall
end

% DoC2 - LOWER
if isempty(OPT.DoC2) 
    OPT.DoC2 = DoC - 0.1; %  round(2*DoC); % DEEPER DoC
    % 27/2/2020 - changed default DoC2 to just below DoC to avoid issues with prof not extending deep enough
end
DoC2     = OPT.DoC2;
DoC2_ind = find(z0<DoC2, 1, 'first');

if isempty(DoC2_ind)
    warning('WARNING: Profile does not reach specified DoC2 depth. Using min(z0) as DoC2.');
    [~, DoC2_ind] = min(z0);
       
end
OPT.DoC2_ind = DoC2_ind;

%% Rollover & Slope settings
rollover       = OPT.rollover;
backSlope      = OPT.roll_backSlope;
duneSlump      = OPT.duneSlump;
duneSlope      = OPT.duneSlope;
slumpCap       = OPT.slumpCap;
slumpCheck     = OPT.slumpCheck;

%% Toe / Crest Position (ToCr)
% In varargin, set OPT.toeCrest_level OR OPT.toeCrest_ind.
ToCr_level = OPT.toeCrest_level;
ToCr_ind   = OPT.toeCrest_ind;

% get ToCr_ind if ToCr_level used as input
if isempty(ToCr_ind) && ~isempty(ToCr_level)
    ToCr_ind = find(z0 >= ToCr_level, 1 , 'last');

% get ToCr_level if ToCr_ind used as input    
elseif ~isempty(ToCr_ind) && isempty(ToCr_level)       
    ToCr_level = z0(ToCr_ind);
    
% set ToCr_level and ToCr_ind if no inputs given   
elseif (isempty(ToCr_ind) && isempty(ToCr_level)) || isnan(ToCr_level)
	ToCr_level = max(z0);
    ToCr_ind = find(z0 == ToCr_level, 1, 'last');
    warning(['Both OPT.toeCrest_level and OPT.toeCrest_ind are empty.' ...
        ' Profile max elevation used as dune toe / barrier crest.' ]);
end

OPT.toeCrest_ind = ToCr_ind;
OPT.toeCrest_level = ToCr_level;

ToCr_level2 = ToCr_level + dS; % toe/crest level after SLR
% if rollover == 1
%     ToCr_level2 = ToCr_level + dS; % toe/crest level after SLR
% else 
%     ToCr_level2 = ToCr_level;
% end

OPT.ToCr_level2 = ToCr_level2;
ToCr_x     = x0(ToCr_ind); % x-location of ToCr
OPT.ToCr_x = ToCr_x;

%% Rock layer settings
rock   = OPT.rockSwitch;
z_rock = OPT.rockLayer;

% FIX NEGATIVE DUNE VOL ISSUES, IF INPUT PROF IS BELOW DUNE LEVEL
% Occurs when (z0 onshore of ToCr_ind is below z_rock)
% Amended (9/6/2020) -> offshore zone (>toeCrest_ind) allows hypothetical "bed below rocks"
    % ...            -> onshore zone  (<=toeCrest_ind) raises the initial bed to rock level (CHANGES Z0!!!)
if rock == 1 
    ind = find(x0 <= x0(ToCr_ind) & z0 < z_rock);
    z0(ind) = z_rock(ind);     % Raise ONSHORE Z0 to Z_ROCK ...
end

%% Dune Accretion / Horizontal Growth Settings
duneAccrete   = OPT.duneAccrete;   % use DUNE ACCRETION (1=ON, 0=OFF)
duneAcc_Vol   = OPT.duneAcc_Vol;   % VOLUME to accrete dunes
duneAcc_Dist  = OPT.duneAcc_Dist;  % DISTANCE (behind ToCr) over which to apply the DUNE VOL CHANGE
% disp(['Dune dist = ' num2str(duneAcc_Dist)])

duneHGrow        = OPT.duneHGrow;       % (1 = ON, 2 = OFF)
duneHGrow_m      = OPT.duneHGrow_m;     % horz distance (m) to grow dune
duneHGrow_crest  = OPT.duneHGrow_crest; % crest of dune (ht above present SL) to grow from

%% Deep Onshore Transport Settings
deepOn     =  OPT.deepOn; 
deepOn_V   =  OPT.deepOn_V;

%% Wall Redistribution (as per Beuzen2018)
% ---------- THIS CAN BE MOVED TO A SEPARATE FUNCTION !! -------
% For profiles with a wall or non-erodible cliff, this sets the location of the
% wall. Potential erosion is calculated behind the wall 
% (using Atkinson2018 translation, assuming wall is not there),
% then the erosion volume is redistributed offshore of the wall.
wall       = OPT.wallSwitch;
wall_level = OPT.wall_level;
wall_ind   = OPT.wall_ind;
wall_x     = OPT.wall_x;

if wall == 1
    % if using wall_x, get wall_ind and wall_level
    if ~isnan(wall_x)
        [~,wall_ind]   = min(abs(x0 - wall_x));
        wall_level     = z0(wall_ind);
        OPT.wall_level  = wall_level;
        OPT.wall_ind    = wall_ind;
    % if wall_level is input, get wall_ind, then wall_x   
    elseif ~isnan(wall_level)
        wall_ind = find(z0<wall_level, 1, 'first') ;
        wall_x   = x0(wall_ind) ;
        OPT.wall_x = wall_x;
        OPT.wall_ind    = wall_ind;
    end
end

% Wall erosion limit
wall_z_min = OPT.wall_z_min  ;
if isnan(wall_ind) && wall == 1
    error('wall_ind is empty, check your wall settings!')
elseif wall == 1 && z0(wall_ind + 1) < wall_z_min
    OPT.z_min_initial = 1 ; % tag if INPUT PROF (z0) is already at MAX EROSION
else 
    OPT.z_min_initial = 0 ;
end

% Wall overwash (21/5/2020)
wall_overwash = OPT.wall_overwash; 
% if wall_overwash = 1, sediment is allowed to pile behind the wall 
    % ... for accretion / positive sediment budget cases

%% OLD WALL REDIST
% if wall == 1
%     % if wall_ind is input, get wallLevel
%     if isempty(wall_level) && ~isempty(wall_ind)
%         wall_level = z0(wall_ind);
%     
%     % if wallLevel is input, get wall_ind     
%     elseif ~isempty(wall_level) && isempty(wall_ind)
%         wall_ind = find(z0<wall_level, 1, 'first');
%     
%     % if both wallLevel and wall_ind are empty, use max height of profile
%     elseif isempty(wall_level) && isempty(wall_ind)
%         wall_level = max(z0);
%         wall_ind  = find(z0==wall_level, 1, 'last');
%         warning(['Both wall_ind and wall_level are empty.' ...
%             ' Profile max elevation used as wall location.' ]);
%         
%     end
% end

%% DUNE ACCRETION - if on, modify Z_RAISE and Z0
if duneAccrete==1
    % ACCRETE THE ACTIVE DUNES
    z0_temp = z0; % z0_temp is z0 modified by processes before the main loop,...
        % includes DUNE ACCRETION and DEEP ONSHORE TRANSPORT
    [~, ind_duneBack] = min(abs (x0 -  ( ToCr_x - duneAcc_Dist) ) ) ; % back point where the dune accretion starts
    dz_duneAcc = duneAcc_Vol / duneAcc_Dist;  % dz to accrete each dune cell
    z0_temp(ind_duneBack:ToCr_ind - 1) = z0(ind_duneBack:ToCr_ind - 1) + dz_duneAcc;
    
    % (DON'T!!) ERODE THE ACTIVE SHOREFACE -> allow translation to do the work (see notes below)
    
    active_len = x0(DoC_ind) - x0(ToCr_ind);
    dz_duneEro = - duneAcc_Vol / active_len;
%     z0_temp(ToCr_ind:DoC_ind) = z0(ToCr_ind:DoC_ind) + dz_duneEro;
    z0_temp(ToCr_ind:DoC_ind) = z0(ToCr_ind:DoC_ind);
        %  !!! (12/6/2020) leave z0_temp unaltered (don't add dune Erosion)...
        % ... instead rely on the algorithm to determine the correct (balancing) translation distance

    OPT.z_duneAcc       = z0_temp;
    OPT.dz_duneAcc      = dz_duneAcc;
    OPT.dz_duneEro      = dz_duneEro;
    
else
    z0_temp = z0;
end

%% DUNE HORIZONTAL GROWTH - if on, modify Z_RAISE and Z0
if duneHGrow == 1
    % HORIZ ACTIVE DUNES
    % includes DUNE ACCRETION, DUNE HORZ GROWTH, DEEP ONSHORE TRANSPORT
    
    ind1 = find(z0_temp >= S_initial + duneHGrow_crest , 1, 'last'); % dune crest index
    ind2 = find(x0 >= x0(ind1) + duneHGrow_m,  1, 'first'); % offshore pt to grow out to
    z0_temp(ind1:ind2) = S_initial + duneHGrow_crest ;
    
    % (DON'T!!) ERODE THE ACTIVE SHOREFACE -> allow translation to do the work (see notes below)

    OPT.duneHGrow_ind_crest       = ind1;  % dune crest index
    OPT.duneHGrow_ind_offPt       = ind2;  % offshore pt to grow out to
end

%% DEEP ONSHORE/OFFSHORE TRANSPORT (negative deepOn_V = onshore transport)
% see EMBf_VARB_TESTING_V2 for SINE CURVE AREA PROOFS

% SINE FUNCTION specifying WAVELENGTH (L) and AMPLITUDE (a)
% y = a .* sin(x.* (pi/ (L/2) ) ); 

% VOLUME OF HALF A SINE CURVE = AMPLITUDE (FULL WAVELENGTH/PI)
% V_(half wave sine) = a (L/pi)

% GIVEN A TARGET VOLUME, AND KNOWN HALF-WAVELENGTH, FIND AMPLITUDE
% a = pi*V / L

if deepOn == 1
	% ERODE(negative deepOn_V) / ACCRETE(positive) -> THE LOWER SHOREFACE
    lower_len = x0(DoC2_ind) - x0(DoC_ind+1);
%     dz_lowerEro = - deepOn_V / lower_len;
%     z0_temp(DoC_ind+1 : DoC2_ind) = z0_temp(DoC_ind+1 : DoC2_ind) + dz_lowerEro;

    bot_ind   = [DoC_ind+1 : DoC2_ind];
    x_bot     = x0(bot_ind);
    x_bot0    = x_bot - x_bot(1); % x-values for the bottom half of the profile, offset to start at 0
    a = (pi * -deepOn_V) / (2*lower_len); % amplitude
    dz_lowerEro = - a .* sin(x_bot0 .* (pi / (lower_len)));
    z0_temp(bot_ind) = z0_temp(bot_ind) + dz_lowerEro;

	% ACCRETE(neg)/ERODE(pos) THE UPPER SHOREFACE    
    active_len = x0(DoC_ind) - x0(ToCr_ind);
    dz_upperAcc =  -deepOn_V / active_len;
%     z0_temp(ToCr_ind:DoC_ind) = z0_temp(ToCr_ind:DoC_ind) + dz_upperAcc;
    z0_temp(ToCr_ind:DoC_ind) = z0_temp(ToCr_ind:DoC_ind);
    
    %  !!! (12/6/2020) leave z0_temp unaltered (don't add dune deepOn_V)...
    % ... instead rely on the algorithm to determine the correct (balancing) translation distance
        
end
OPT.z0_temp = z0_temp; % z0_temp = z0 + dune accretion + dune HORZ GROWTH + trend_x

%% CLIFF RECESSION (NEEDS SEPARATE FUNCTION!)

if OPT.cliff_switch == 1
    OPT.rockLayer_t0 = OPT.rockLayer ;  % pre-cliff erosion rock layer

    z0_temp = OPT.z0_temp;
    z1_rock_temp = OPT.rockLayer ;

    % Set CLIFF TOE = OPT.toeCrest 
    % ... current only option is for cliff toe to match the "dune toe"
    % ... buried cliffs would require an additional option to set 
    % ... OPT.cliff_ind != OPT.toeCrest_ind
    if isnan(OPT.cliff_ind)
        OPT.cliff_ind = OPT.toeCrest_ind;
    end
    OPT.cliff_x = x0(OPT.cliff_ind);
    OPT.cliff_level = OPT.toeCrest_level;
    
    % Get CLIFF SLOPE 
    if isnan(OPT.cliff_slope)
        dx = OPT.cliff_slope_dx; % "cliff run" --> default = 5m
        dy = z0_temp(OPT.cliff_ind - dx) - z0_temp(OPT.cliff_ind); % "cliff rise"
        OPT.cliff_slope = atan2d(dy, dx) ;
    end
    
    % FORCE CLIFF RECESSION
    m_val = OPT.cliff_m_coeff ;
    % OPT.cliff_SLR_rate1 = OPT.dS / OPT.dt  ; % final rate of SLR  --->> ERROR --> Fixed FEB 2025

    OPT.cliff_SLR_rate_av = OPT.dS / OPT.dt ; % average SLR rate
    % SLR_rate_av = (SR_rate0 + SR_rate1) ./ 2  
    % rearrange the above eq to get ...
    % SLR_rate1 = 2*SLR_rate_av - OPT.SLR_rate0  ;
    OPT.cliff_SLR_rate1  = 2*OPT.cliff_SLR_rate_av - OPT.cliff_SLR_rate0  ;


    OPT.cliff_REC_rate1 = OPT.cliff_REC_rate0 * (OPT.cliff_SLR_rate1/OPT.cliff_SLR_rate0).^m_val  ;       % M-COEFF (default = 0.5)
    % ... final rate of cliff recesion: r2 = r1*sqrt(dS_dt2 / dS_dt1)                                  % OPT.cliff_m_coeff = 1/2    ; % response factor "m" in ASHTON 2011
    
    OPT.cliff_REC_rate_av = ( OPT.cliff_REC_rate0 + OPT.cliff_REC_rate1 ) / 2 ;
    OPT.cliff_dX = OPT.cliff_REC_rate_av * OPT.dt  ;  % changed dX to AVG RATE - FEB 2025
        
    % INDEX CLIFF TOES [OLD = ind2] [NEW TOE = ind1]
    % ind1 = OPT.cliff_ind + round(OPT.cliff_dX)  ;    % ind1 = new cliff toe (t1)  
    ind1 = OPT.cliff_ind + floor(OPT.cliff_dX)  ;    % ind1 = new cliff toe (t1)      % round up (negative) ---> avoid cliff_dX=0 (MAR 2025)
         %   [extent of recession will extend ONSHORE of ind1 due to SLUMPING]
    ind2 = OPT.cliff_ind         ;                          % ind2 = old cliff toe (t0)
    OPT.cliff_rec_sti = [ind1]  ;
    OPT.cliff_rec_eni = [ind2]  ;

    z1_rock_temp(ind1:ind2) = OPT.cliff_level + OPT.dS;  
    % makes a flat eroded platform offshore of the cliff toe at the NEW CLIFF TOE LEVEL
    % z1_rock_temp(ind1:ind2) = OPT.SL1;  % makes a flat eroded platform offshore of the cliff toe at the new sea level

    % SLUMP THE CLIFF FACE (USING DUNE SLUMP FUNCTION)  (for Z1_ROCK)
    OPT1 = OPT;
    OPT1.duneSlump = 1;
    OPT1.duneSlope = OPT.cliff_slope;
    OPT1.rockSwitch = 0;
    [z1_rock_temp, ~, ~] = ...
        ST_SLUMP(x0, z0, z1_rock_temp, OPT1);

    % SLOPED SHORE PLATFORM (for Z1_ROCK)   [ROCK LEVEL]
    ind = [OPT.cliff_rec_sti : OPT.cliff_rec_eni] ;
    z_on =   z1_rock_temp(ind(1)) ;

    z_off_opt1  = OPT.SL0               ;
    z_off_opt2 = z1_rock_temp(ind2 + 1) ;
    z_off = max(z_off_opt1, z_off_opt2) ;

    z_slope_platform = interp1([ind(1), ind(end)], [z_on, z_off],  ind) ;
    z1_rock_temp(ind) = z_slope_platform ;

    % CHECK SHORE PLATFORM DOES NOT GO BELOW [z1_rock_temp(OPT.cliff_rec_eni) + 1 ]

    
    % UPDATE [Z0_TEMP] TEMP BED LEVEL --> FLAT (SAND) SURFACE FROM NEW CLIFF TOE TO OLD CLIFF TOE
    %  .... (SITS ABOVE SLOPING ROCK PLATFORM)

    %      [TEMP BED LEVEL] ---> (ONSHORE OF NEW CLIFF TOE [IND1] --> TEMP BED LEVEL = Z1_ROCK 
    z0_temp(1 : ind1) = z1_rock_temp(1 : ind1) ;  % adds new cliff face (with slump) 
        
    %     [TEMP BED LEVEL] ===>> (OFFSHORE of NEW CLIFF TOE [IND1] to OLD CLIFF TOE [IND2]) ==> update to FLAT SURFACE
    %          ... INTERP FLAT SURF TO [OLD CLIFF TOE - 1] i.e., [z0(ind2 - 1)]
    % ind = [OPT.cliff_rec_sti : OPT.cliff_rec_eni - 1] ;

    ind = [ind1 : ind2 - 1] ;
    z_on =   z1_rock_temp(ind1) ;      % onshore point is NEW CLIFF TOE [BED LEVEL set to equal ROCK LEVEL]

    z0_temp(ind) = z_on ;    % interps [new bed level at new cliff toe] to [old cliff toe - 1]  
                                 % ---> makes [Z1_RAISE] work properly
    % VOLUME CHANGE   
    V0_CLIFF = trapz(x0(1:ToCr_ind), z0(1:ToCr_ind)); % 
    V1_CLIFF = trapz(x0(1:ToCr_ind), z0_temp(1:ToCr_ind)); 
    OPT.cliff_dV = V1_CLIFF - V0_CLIFF  ;
    OPT.cliff_dV_keep = OPT.cliff_dV * OPT.cliff_vol_conserve_ratio  ;
    OPT.cliff_dV_lose = OPT.cliff_dV * (1 - OPT.cliff_vol_conserve_ratio )  ;

    OPT.rockLayer_t1 = z1_rock_temp ;  % post-cliff erosion rock layer
    OPT.rockLayer = z1_rock_temp    ;  % !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! NEED FIX !!!!!!!!!!!!!!!!!! (JAN 2025)
        % NEED FIX [OPT.rockLayer = z1_rock_temp] ... (JAN 2025)
        % ... --> CAUSES CONFUSION AS OPT(output) CONTAINS [t1] ROCK LAYER
        % ... ... BUT THIS IS NOT CLEAR !!!!!!!!!!
    % z_rock = OPT.rockLayer ;      % ...  new rock layer is prevented from eroding in the translation proces

    OPT.z0_temp = z0_temp ;
end
clear ind1 ind2

%% CLIFF SCRAPS TO DELETE

    % z_off  = z0_temp(ind2) + OPT.dS  ;    % offshore pt is BED LEVEL @ OLD CLF TOE + dS [i.e., a FLAT SURFACE]
    % z_on =   z1_rock_temp(ind(1)) ;      % onshore point is NEW CLIFF TOE [BED LEVEL set to equal ROCK LEVEL]
    % z_off  = z0_temp(ind(end) + 1) + OPT.dS  ;    % offshore pt is BED LEVEL @ [OLD CLF TOE]
    % z_temp_surf = interp1([ind(1), ind(end)], [z_on, z_off],  ind) ;



    % OPT.rockLayer(ind1) = z0_temp(ind1);  % UPDATE ROCK LAYER TO INCLUDE CLIFF EROSION
        % OPT.rockLayer(ind2) = repmat(S_initial, size(ind2))    ; % LOWER ROCK LAYER TO INITIAL SL IN ERODED CLIFF ZONE
    % OPT.rockLayer(ind2) = repmat(S_final, size(ind2))    ; % LOWER ROCK LAYER TO FINAL SL ========>>>> UPDATE NOV 2024

    % % INSERT SLOPED ROCK PLATFORM in ERODED CLIFF ZONE ---->> UPDATE NOV 2024
    % z_slope_platform = interp1([ind2(1), ind2(end)], [S_final, S_initial],  ind2) ;
    % OPT.rockLayer(ind2) = z_slope_platform ;


    % SET OUTPUTS
    % OPT.z0_temp = z0_temp;
    % ind1 = [1:OPT.cliff_ind]; % start of prof to new base of cliff
    % ind2 = [OPT.cliff_ind + round(OPT.cliff_dX) + 1 : OPT.cliff_ind + ] ;  % eroded cliff zone

    % CLIFF EROSION ZONE FILL -----> UPDATED DEC 2024
    % NOTES (16/12/2024)
    %   z0_temp ==> the bed level surface that gets translated
    %   OPT.z0_temp ---> careful this is updated for each section, then again before passing to translator
    %   OPT.rockLayer_t0 ===> input rock layer
    %   OPT.rockLayer_t1 ===> output rock layer (with recession)
    %   OPT.rockLayer  ==> set to equal OPT.rockLayer_t1 in this section (overwrites input values)
    %   OPT.z_raise ===> copy z0_temp, then raise active section by SLR
    %   --> 
    %   --> cliff erosion zone index = [ind1 : ind2]   --> from original cliff toe, to new cliff toe / face
    %        OPT.cliff_rec_sti = [ind1] ;
    %        OPT.cliff_rec_eni = [ind2] ;
    % 
    %   -----> rockLayer_t1 is SLUMPED --> but then the cliff erosion zone must be filled with a flat surface or slope (OPT.cliff_erode_platform)
    %           ---> OPT.cliff_platform_ind = [ind1 : ind2 + 1]  ;  % the "+1" is to join up to the rock layer offshore of the original toe
    %
    %   -----> z0_temp has to be eroded back to rockLayer_t1 (cliff recession)  ----> ind = [1 : ind1]
    %      -----> z0_temp across the 'cliff erosion platform' must interp from rock_t1(ind1) to z0(ind2)
    
    % CLIFF EROSION ZONE PLATFORM
    % if OPT.cliff_erode_platform == 1
    % 
    %     ind = [OPT.cliff_rec_sti + 1 : OPT.cliff_rec_eni ] ;
    %     OPT.rockLayer(ind) = OPT.SL1 ;  % makes a flat eroded platform offshore of the cliff toe at the new sea level
    % 
    % elseif OPT.cliff_erode_platform == 2   % makes a sloping rock platform from new sea level (onshore) to original rock layer offshore of cliff toe
    % 
    %     ind = [OPT.cliff_rec_sti + 1 : OPT.cliff_rec_eni + 1] ;
    % 
    %     z_on   = S_final ;
    %     z_off  = OPT.rockLayer(ind(end)) ;
    % 
    %     z_slope_platform = interp1([ind(1), ind(end)], [z_on, z_off],  ind) ;
    %     OPT.rockLayer(ind) = z_slope_platform ;
    % 
    % end

    % INTERP TEMP GROUND SURFACE (z0_temp) --> from new cliff toe [rockLayer(ind1)] to sand offshore of original cliff toe [z0(ind2 + 1)]
    % the complication is that the cliff is eroded BEFORE the sand

    % ind = [OPT.cliff_rec_sti : OPT.cliff_rec_eni + 1] ;
    % z_on   = OPT.rockLayer(ind(1)) ;
    % z_off  = z0_temp(ind(end)) ;
    % 
    % z_temp_slope = interp1([ind(1), ind(end)], [z_on, z_off],  ind) ;
    % z0_temp(ind) = z_temp_slope ;    


%% Z0_ROCK (MAX OF UNION OF ROCK AND Z0) -> added for OFFSHORE REEFS (18/2/2020)
% use this for the final calcs, V0 = pre any changes (including the z0_temp changes above)

if rock == 1 
    z0_rock = max(z0, z_rock)  ; % Take Z0_ROCK as max
elseif rock == 0
    z0_rock = z0; % added 9/6/2020, solved issue with NE layer causing issues, even when switched off
end
OPT.z0_rock = z0_rock;

%% Z0_ROCK -> Linear interp Z0 across ROCK OUTCROPS
if rock == 1
%     disp('interping across rocks')
    z_rock = OPT.rockLayer ;    % this rockLayer is now updated for cliff recession (if applicable)
    ind = (z0_rock <= z_rock)  ;    % index of OUTCROP (z0_rock == z_rock)  
    ind = ind(:) ;             % ... there shouldn't be any (z0_rock < z_rock) ... but use '<=' just in case

    % [CROP IND TO ACTIVE ZONE]  --> UPDATE 21/11/2024
    ind([1 : OPT.toeCrest_ind - 1]) = false ;
    ind([DoC_ind : length(z0_rock)]) = false ;

    % UPDATE NOV 2024 ---> USE [INDEX_LOGICAL_SECTIONS] FUNCTION
    [indSec] = index_logical_sections(ind) ;
    if ~isempty(indSec)
        ind_st = [indSec.st]' ;
        ind_en = [indSec.en]' ;

        ind2 = find(ind_st == ind_en) ; % remove single point indexes
        ind_st(ind2) = [] ;
        ind_en(ind2) = [] ; 

    else
        ind_st = [] ;
        ind_en = [] ;
    end
    
    % ================ OLD CODE BELOW (REMOVED NOV 2024)
    % INDEX OUTCROP SECTIONS
    % ind_st = []; % last NON-OUTCROP section BEFORE an outcrop
    % ind_en = []; % first NON-OUCROP section AFTER
    % for i = 2:length(ind)-1
    %     if ind(i)==0 && ind(i+1) == 1
    %         ind_st = [ind_st; i] ;
    %     elseif ind(i)==0 && ind(i-1) == 1
    %         ind_en = [ind_en; i] ;
    %     end
    % end    
    % 
    % if length(ind_en) < length(ind_st) % add end index if outcrop extends...
    %     ind_en = [ind_en; ind_st(end)]; % ... to end of profile
    %     ind_st(end) = ind_en(end) - 1 ;  % ADDED NOV 2024 --> fix error where ind_st(end) = ind_en(end)
    % end
    % ================= OLD CODE ABOVE (REMOVED NOV 2024)


    % LINEAR INTERP ACROSS OUTCROP SECTIONS  [CROP TO ACTIVE ZONE]  --> UPDATE 21/11/2024
    for i = 1 : length(ind_st)
        % try
            ind_st1 = ind_st(i) ;
            ind_en1 = ind_en(i) ;

            x_temp = [x0(ind_st1) x0(ind_en1) ];
            z_temp = [z0(ind_st1) z0(ind_en1) ];
            ind2 = [ind_st1:ind_en1];
            z0_temp(ind2) = interp1(x_temp, z_temp, x0(ind2))   ;
        % end
    end
    clear x_temp z_temp

end

%% RAISE input profile by SLR (z0 -> z1)
% OPT.z0_temp = z0_temp ;
z1 = z0_temp ; % z1 = INTERIM1 -> SLR RAISED PROFILE
z1(ToCr_ind:DoC_ind-1) = z0_temp(ToCr_ind:DoC_ind-1) + dS;  % 31/8/2020 changed from DoC_ind to ind - 1
OPT.z_raise = z1;

%% UPDATE OPTIONS [OPT] STRUCTURE
OPT.S_final = S_final;
OPT.DoC_ind = DoC_ind;
OPT.toeCrest_level  = ToCr_level;
OPT.toeCrest_level2 = ToCr_level2;
OPT.toeCrest_ind    = ToCr_ind;
% OPT.wall_level      = wall_level;
% OPT.wall_ind        = wall_ind;

%% OPTIMISED PROFILE TRANSLATION 
% call OPTIMISER - finds x-translation distance with minimum dV_error
% outProf=[];
if OPT.optimizer == 1
    
    try
    [Xi_winner, Xi_ind, outPROFS, OPT] = ST_OPTIMIZER(x0, z0, dV_input, OPT);
    OPT.Xi_winner = Xi_winner;
    OPT.Xi_ind    = Xi_ind;
    outProf = outPROFS(Xi_ind);
    outProf.good_run = true ;
    OPT.n_guesses = length(outPROFS);

    catch % CATCH ERORRS 
        if OPT.error_bypass == 1 % set OPT.error_bypass = 1 to allow errors if running many profiles.
            warning(['ShoreTrans failed to run. Check if the input profile extends far enough off/onshore. ' ...
            'All outputs set to [EMPTY]. "OPT.error_bypass = 1".']);
            ST_OUTPROF_empty; % generate empty output
            outPROFS = [];
            outProf.good_run = false ;
            
        elseif OPT.error_bypass == 0 % set OPT.error_bypass = 0 to break when an error occurs.
            error(['ShoreTrans failed to run. Check if the input profile extends far enough off/onshore.' 10 ...
                'To bypass errors, set "OPT.error_bypass = 1".']);
        end
    end
 
    if OPT.shortOutput == 0 && outProf.good_run
        disp(['Final estimate:' 10 ...
            'Translation distance = ' num2str(Xi_winner) ' m' 10 ...
            'dV_error = ' num2str(outProf.dV_error, '%0.2f') ' m^3/m' 10 ...
            'n guesses = ' num2str(OPT.n_guesses)]);
    end

else
    outProf = [] ;
    outProf.good_run = false ;

end

%% ERROR CATCHER --> DETERMINE CAUSE OF ERROR
outProf.FailType = '' ;

if OPT.error_bypass == 1 & ~outProf.good_run
   
    % CHECK FOR NO DEPTH OF CLOSURE FOUND
    if isempty(OPT.DoC_ind)
        warning(['Reason for FAILURE: No DoC found. Check profile depth. Try OPT.DoC_first_last = 1'])
        outProf.FailType = 'DoC not found' ;
    end
end


%% RANGE PROFILE TRANSLATION (NON-OPTIMISED)
if OPT.optimizer == 0
    outPROFS=[];
    for n = 1 : X_len % n = shift onshore (in metres as dx=1)

        Xi = X_range(n);
        [outProf1, OPT] = ST_TRANSLATOR(x0, z0, Xi, dV_input, OPT);
        outPROFS = [outPROFS; outProf1];
        
    end
    outProf = [];
end

%%

%%












%%
