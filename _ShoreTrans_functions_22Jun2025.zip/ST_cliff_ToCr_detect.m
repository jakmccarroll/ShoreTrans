%% function [clf, OPT] = ST_cliff_ToCr_detect(x0, z0, OPT)   ---> SEP 2024
% Detect CLIFF (TOE + CREST) locations, for a single x-sect profile
%
% Inputs
%   x0 - profile cross-shore position (1-m spacing)
%   z0 - profile elevation 
%   varargin - OPT (see below)
%
% Outputs
%   CLF = index of TOE / CREST locations, CLIFF INDEX etc
% 
% Example
%   OPT0.Site_ID  = 20   % SELECT SITE (DEMONS BLUFF EXAMPLE)
%   [Sites, Site1] = VS1_loading_suite_sites(Dir, OPT0)   ;
%   SID1 =  46 ; % select a survey
%   TID1 = 55 ; % select a profile
%   x0 = Site1.T.X0 ;
%   z0 = Site1.mrg2(SID1).prof(TID1).z_on_join ;
%   OPT.To_z = 2.3 ;
%   [clf, OPT] = ST_cliff_ToCr_detect(x0, z0, OPT)

function [clf, OPT] = ST_cliff_ToCr_detect(x0, z0, varargin)

%% -------> DEFAULT SETTINGS (OPT)

OPT.min_ang = 45   ;   % MIN SLOPE ANGLE for section of profile to count as a cliff
OPT.To_z    = 2.5  ;   % Approx elevation of cliff toe
OPT.To_slp_chk = 1 ;   % Additional check to ensure TOE is offshore of steep section   
%                       [1 - ON (default) ; 2 - OFF ]
OPT.To_min_ind = 140 ; % MIN INDEX (of x0 position) to search for TOE
OPT.To_max_ind = 240 ; % MAX INDEX to search for TOE
OPT.Cr_rng = 100 ; % X-shore RANGE to seach for CREST (onshore of initial toe detection pt)

OPT.min_clf_ht = 5 ; % MIN CLIFF HT --> shorter cliffs will be deleted

OPT.gap_max = 5 ;         % join rock sections with gaps between less than [GAP_MAX]

%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'warnAppend'); 

%% EXTRACT VARS FROM OPT
% OPT = OPTC
min_ang = OPT.min_ang ;
To_z = OPT.To_z ;
To_min_ind = OPT.To_min_ind ;
To_max_ind = OPT.To_max_ind ;
Cr_rng = OPT.Cr_rng ;
gap_max = OPT.gap_max ;

%% PRESET OUTPUTS AS NANS
To_ind0 = nan ;   % TOE (INITIAL)
To_ind = nan ;     % TOE (FINAL)
To_z_final = nan ;
Cr_ind0 = nan ;   % CREST (INITIAL)
Cr_ind = nan ;    % CREST (FINAL)
Clf_ind = nan ;
Cr_chord_X = nan ;
Cr_chord_z = nan ;
dist1 = nan ;
z0_slope = nan ;
slp_ind_01 = false ;
slp_ind = nan ;
good = false  ;
clf_ht = nan ;
clf_run = nan ;
clf_slp = nan ;
clf_ang = nan ;
comment1 = '' ;

%% FIND TOE LOCATION (INITIAL)
clear To_ind0

To_ind0 = find(z0 > To_z  &   x0 > x0(To_min_ind) & ...
    x0 < x0(To_max_ind) , 1, 'last') + 1    ;  % use [LAST + 1] RULE

% openvar('To_ind0')

%% FIND SLOPE INDEX (INDEX HIGH SLOPE SECTION)

if ~isempty(To_ind0)  % INITIAL TOE FOUND

    Cr_min_ind = To_ind0 - Cr_rng ;
    Cr_max_ind = To_ind0  ;
    Cr_rng_ind = [Cr_min_ind : Cr_max_ind ] ;
    Cr_rng_01 = ismember([1: length(x0)]', Cr_rng_ind) ;
    
    Cr_chord_X = [x0(Cr_min_ind) : x0(Cr_max_ind) ]' ;   % draw a CHORD from onshore limit, to TOE ...
    Cr_chord_z = linspace(z0(Cr_min_ind), z0(Cr_max_ind), length(Cr_chord_X))' ;
    
    v1 = [x0(Cr_min_ind), z0(Cr_min_ind)] ;
    v2 = [x0(Cr_max_ind), z0(Cr_max_ind)] ;
    dist1 = point_to_line_distance([x0, z0], v1, v2) ; % ... then find most DISTAL PT from CHORD
    dist1(~Cr_rng_01) = nan;
    [~, Cr_ind0 ] = max(dist1) ;   % MAX DIST METHOD CREST (INITIAL)
    
    z0_slope = [diff(z0); nan]   ;     % SLOPE (RISE / RUN = 1m) at each pt of prof
    % slp_ind_01 = z0_slope  < -tand(min_ang)    ;   % SLOPE ANGLE AT LEAST MIN_ANG (default 45deg)
    slp_ind_01 = z0_slope  < -tand(min_ang)  & x0 <= x0(To_ind0) + 5  ;   % SLOPE ANGLE AT LEAST MIN_ANG (default 45deg)   ---> added end pt as initial toe (7/4/2025)

end

%% SLOPE INDEX -   JOIN GAPS < [GAP_MAX]
ind1   = find(slp_ind_01)     ;   % SLOPE INDEX
slp_ind2_01 = slp_ind_01 ;

if length(ind1) > 1
    for i = 1 : length(ind1) - 1
    
        gap1 = ind1(i+1) - ind1(i) ;  % calculate gap to next rough pt
    
        if gap1 > 1 && gap1 < gap_max    % check if gap length is below limit [dX_lim]
            gap_i = [ind1(i) : ind1(i+1)]'  ;   % index the gap
            slp_ind2_01(gap_i) = true ;          % fill the gap
        end
    
    end

end

%% SLOPE INDEX --> TAKE LONGEST SECTION   ---> (7/4/2025)

ind2 = find(slp_ind2_01) ;
if ~isempty(ind2)
    indSec2 = index_logical_sections(slp_ind2_01) ;
    
    [~, ind_max_sec] = max([indSec2.length]) ;
    slp_ind   = indSec2(ind_max_sec(1)).ind    ;   % SLOPE INDEX
    slp_ind(slp_ind > To_max_ind) = [] ; 
end

%% FIND CREST LOCATION (INITIAL and FINAL)    
if ~isempty(To_ind0)    
    Cr_ind = find(x0 >= x0(Cr_ind0) & slp_ind_01 & x0 <= Cr_max_ind, 1 , 'first' )  ; % Final CREST INDEX ...
    %  ... at/beyond max dist pt AND passes steepness test

    if isempty(Cr_ind)
        Cr_ind = nan;  % NO CREST FOUND = NO CLIFF
        comment1 = 'Not steep enough --> NO CLIFF' ;
    end

else
    To_ind0 = nan ;  % NO TOE FOUND = NO CLIFF
    To_ind  = nan ;
    comment1 = 'No TOE found --> NO CLIFF' ;
    % Cr_ind = nan ;
end

%% FINAL TOE INDEX
if OPT.To_slp_chk == 1  &  ~isnan(To_ind0)  & ~isnan(Cr_ind)

    To_ind_chk = find(x0 > x0(slp_ind(end)) & z0 >= To_z ...   
        & z0 <= To_z + 1.5, 1, 'first' ) ;  % Added (To_z + 1.5 m) cap --> to stop TOES being TOO HIGH  (21/11/2024)
        % FINAL TOE INDEX is beyond steep section, and at/above approx toe elevation
    
    if ~isempty(To_ind_chk)   
        To_ind = To_ind_chk ;   % move TOE_IND onshore to FIRST beyond steep section, and at/above approx toe elevation
    else 
        To_ind = To_ind0  ;    % keep initial TOE-IND estimate (uses FIRST+1 so can be BELOW input toe level)
    end

    To_z_final = z0(To_ind) ;
end


%% FINAL CLIFF INDEX
if ~isnan(Cr_ind) && ~isnan(To_ind)
    Clf_ind = [Cr_ind : To_ind]' ;
    % good = true ;
else
    Clf_ind = nan;
    % good = false ;
end


%% CHECK FOR MIN CLIFF HEIGHT

if ~isnan(Clf_ind)
    clf_ht = z0(Cr_ind) - z0(To_ind) ;
    
    if clf_ht < OPT.min_clf_ht
        Clf_ind = nan   ;
        comment1 = 'Below MIN CLIFF HEIGHT --> NO CLIFF'   ;
    
    end

    % CHECK AVERAGE ONSHORE HT --> prevent false detections (Feb 2025)
    av_onshore_ht = nanmean(z0(1 : Cr_ind)) ;
    if av_onshore_ht < (OPT.min_clf_ht + OPT.To_z)
        Clf_ind = nan   ;
        comment1 = 'Onshore avg ht TOO LOW'   ;

    end
    

end

%% IS CLIFF FOUND ?? (GOOD ??) 

if ~isnan(Clf_ind)
    good = true ;
end

%% GET CLIFF SLOPE AND ANGLE
% if good
%     clf_run = x0(To_ind) - x0(Cr_ind) ;
%     clf_slp = clf_ht / clf_run ;
%     clf_ang = atan2d(clf_ht, clf_run) ;
% end

try
    clf_run = x0(To_ind) - x0(Cr_ind) ;
    clf_slp = clf_ht / clf_run ;
    clf_ang = atan2d(clf_ht, clf_run) ;
end


%% ADD FINAL CHECK ON CLIFF ANGLE

if good & clf_ang < min_ang
    
    good = false ;
    comment1 = 'Overall slope too low --> NO CLIFF'   ;
end

%% PUT OUTPUT VARS IN [CLF] 
clf = struct(...
    'x0', x0, ...
    'z0', z0, ...
    'To_ind0', To_ind0, ...
    'To_ind', To_ind, ...
    'To_z_final', To_z_final, ...
    'Cr_ind0', Cr_ind0, ...
    'Cr_ind', Cr_ind, ...
    'Clf_ind' , Clf_ind, ...
    'Cr_chord_X', Cr_chord_X, ...
    'Cr_chord_z', Cr_chord_z, ...
    'Cr_dist1', dist1, ...
    'z0_slope', z0_slope, ...
    'slp_ind_01', slp_ind_01, ...
    'slp_ind', slp_ind, ...
    'good', good, ...
    'clf_ht', clf_ht, ...
    'clf_run', clf_run, ...
    'clf_slp', clf_slp, ...
    'clf_ang', clf_ang, ...
    'comment', comment1 ) ;

%% END FUNCTION
end



%%