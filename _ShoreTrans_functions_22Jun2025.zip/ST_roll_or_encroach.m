%% ST_roll_or_encroach ---> NOV 2024
% input a profile, determine if translation type is ROLLOVER or ENCROACH

function [vars, cond, OPT] = ST_roll_or_encroach(x0, z0, varargin)


%% SET DEFAULTS (OPT)
OPT.off_z_level  = 1  ;  % elevation point onshore of which to determine mean slope (e.g, high tide line, dune toe, backshore line, shoreline etc)
OPT.off_x_limit = 700 ;      % [off_z_level] must be onshore of this x-value (catches BAD PROFILES - that rise up offshore) 
OPT.on_rng = 150 ;       % onshore range to calculate slope (defined onshore of [off_z_level])
OPT.crit_slope = 0 ;    % if slope is > [crit_slope] ---> Type = ROLLOVER (OPT.rollover = 1)
                         % if slope is < [crit_slope] ---> Type = ENROACH  (OPT.rollover = 2)
% e.g., if OPT.slope_bound = 0, POS+ sloping profs (i.e., dipping landward) will be classified ROLLOVER ...
% ... and NEG- sloping profs (i.e., dipping seaward) will be classified ENCROACH
OPT.slope_buf = 0.01 ;


OPT.crit_z = 5 ;    % min elevation for profiles to ENCROACH
OPT.z_buf  = 1 ;

OPT.default_type = 0 ;  % if translation type is indeterminate, default to [1-ROLLOVER ; 0-ENCROACH ] ;

%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'silentIgnore'); 

%% SETUP VARS
off_z_level = OPT.off_z_level ;
off_x_limit = OPT.off_x_limit ;
on_rng = OPT.on_rng ;
crit_slope = OPT.crit_slope ;
slope_buf = OPT.slope_buf ;

crit_z = OPT.crit_z ;
z_buf = OPT.z_buf ;

% pre-set NaNs
dun_ind = nan ; x_dun = nan ; z_dun = nan ;
z_fit = nan ;  rise1 = nan ; slope1 = nan ;
z_avg = nan ; z_avg_off = nan ; z_avg_on = nan ;
type1 = nan ;  

OPT.rollover = nan ;


%% FIND OFFSHORE LIMIT for SLOPE CALCULATION (E.G., DUNE TOE OR SHORELINE)
off_ind = find(z0(1:end-1) >= off_z_level, 1, 'last') + 1 ;
off_x = x0(off_ind) ;

%% FIND ONSHORE-DUNE REGION, GET SLOPE and MEAN/MAX HEIGHTS


% CATCH BAD PROFILES
if isempty(off_ind)  | off_x > off_x_limit              % Occurs if the profile never gets above high tide level    
    % class1 = nan ;       
    % type1 = 1 ;
    % class_str = 'rollover' ;   
    % cond = nan ;

    class1 = nan ;       
    type1 = 0 ;
    class_str = 'encroach' ;   
    cond = nan ;

    vars = struct(...
        'off_ind', off_ind, 'dun_ind', nan, 'x_dun', nan, 'z_dun', nan, ...
        'z_fit', nan, 'rise', nan, 'run', nan, 'slope', nan, ...
        'z_avg', nan, 'z_avg_on', z_avg_on, 'z_avg_off', z_avg_off, ...
        'z_max', nan, 'z_max_ind', nan, ...
        'class', class1, 'class_str', class_str, 'type', type1) ;

    return             % END FUNCTION HERE (IF BAD PROF)
end

%% INDEX ONSHORE-DUNE RANGE (from SHORE to a defined distance onshore)
if ~isempty(off_ind)
    
    dun_ind = [off_ind - on_rng : off_ind] ;
    x_dun = x0(dun_ind) ;
    z_dun = z0(dun_ind) ;
    
    % GET MEAN SLOPE ACROSS ONSHORE-DUNE RANGE
    [p,S] = polyfit(x_dun,z_dun,1)  ;
    z_fit = polyval(p, x_dun);
    rise1 = z_fit(end) - z_fit(1) ;
    run1  = x_dun(end) - x_dun(1) ;
    slope1 = ( rise1 / run1  )   ;
    
    % GET MEAN HTS
    z_avg = mean(z_dun) ;
    ind_mid = round(length(dun_ind)/2) ;
    z_avg_off = mean(z_dun(ind_mid : end)) ;
    z_avg_on  = mean(z_dun(1 : ind_mid)) ;

    % GET MAX HT    
    [z_max, z_max_ind] = max(z_dun) ;
end

%% CATCH BAD PROFILES

if isempty(off_ind)               % Occurs if the profile never gets above high tide level    
    % class1 = nan ;       
    % type1 = 1 ;
    % class_str = 'rollover' ;   
    % cond = nan ;

    class1 = nan ;       
    type1 = 0 ;
    class_str = 'encroach' ;   
    cond = nan ;

    vars = struct(...
        'off_ind', off_ind, 'dun_ind', nan, 'x_dun', nan, 'z_dun', nan, ...
        'z_fit', nan, 'rise', nan, 'run', nan, 'slope', nan, ...
        'z_avg', nan, 'z_avg_on', z_avg_on, 'z_avg_off', z_avg_off, ...
        'z_max', nan, 'z_max_ind', nan, ...
        'class', class1, 'class_str', class_str, 'type', type1) ;

    return             % END FUNCTION HERE (IF BAD PROF)
end

%% DETERMINE CONDITIONS [COND]
cond = [] ;


if slope1 >= crit_slope + slope_buf             % RISING SLOPE
    cond.slope = 1 ;
elseif slope1 <= crit_slope - slope_buf         % FALLING SLOPE
    cond.slope = -1  ;
else
    cond.slope = 0 ;                            % INDETERMINATE SLOPE
end

if z_avg <= crit_z - z_buf  
    cond.z_avg = -1 ;          % LOW AVG HT
elseif  z_avg >= crit_z + z_buf  
    cond.z_avg = 1 ;         % HIGH AVG HT
else
    cond.z_avg  = 0 ;         % INDETERMINATE AVG HT  
end

if  z_max <= crit_z - z_buf     % LOW PEAK HT
    cond.z_max = -1 ;
elseif  z_max >= crit_z + z_buf
    cond.z_max = 1 ;
else
    cond.z_max  = 0 ;         % INDETERMINATE MAX HT  
end


%% CLASSIFY TRANSLATION TYPE (based on COND)

if cond.z_avg == -1  || cond.z_max == -1        % LOW MEAN OR MAX HT ---> ROLLOVER
              
    class1 = 1 ;   % classification
    type1 = 1 ;    % encroachment TYPE matches CLASS1 (unless class1 is indeterminate, then TYPE = DEFAULT]
    
elseif cond.z_avg == 1           % HIGH MEAN  HT ---> ENCROACH
    class1 = 0 ;    
    type1 = 0 ;

elseif cond.slope == -1        % FALLING SLOPE ---> ENCROACH
    class1 = 0 ;      
    type1 = 0 ;

elseif  cond.slope == 1          % RISING SLOPE ---> ROLLOVER
    class1 = 1 ;    
    type1 = 1 ;

else                                % indeterminate ---->> USE DEFAULT TRANSLATION TYPE
    class1 = nan ;       
    type1 = OPT.default_type ;

end

%% SET OUTPUT VARS
OPT.rollover = type1 ;

if class1 == 1
    class_str = 'rollover' ;
elseif class1 == 0
    class_str = 'encroach' ;
elseif isnan(class1)
    class_str = 'indeterminate' ;
end

vars = struct(...
    'off_ind', off_ind, 'dun_ind', dun_ind, 'x_dun', x_dun, 'z_dun', z_dun, ...
    'z_fit', z_fit, 'rise', rise1, 'run', run1, 'slope', slope1, ...
    'z_avg', z_avg, 'z_avg_on', z_avg_on, 'z_avg_off', z_avg_off, ...
    'z_max', z_max, 'z_max_ind', z_max_ind, ...
    'class', class1, 'class_str', class_str, 'type', type1) ;



%% END

end





%%




%%
% vars = [] ;
% vars.off_ind = off_ind ;
% vars.dun_ind = dun_ind ;
% vars.x_dun = x_dun ;
% vars.z_dun = z_dun ;
% vars.z_fit = z_fit ;
% vars.rise = rise1 ;
% vars.run  = run1  ;
% vars.slope = slope1 ;
% 
% vars.z_avg = z_avg ;
% vars.z_avg_on  = z_avg_on ;
% vars.z_avg_off = z_avg_off ;
% 
% vars.type = type1 ;
% vars.type_str = type_str ;






%%





%%
