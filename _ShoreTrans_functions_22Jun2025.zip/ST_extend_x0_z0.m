%% ST_extend_x0_z0 ---> OCT 2024

function [x0, z0, OPT] = ST_extend_x0_z0(x, z, varargin)

%% OPT DEFAULTS

OPT.ext_on = 1 ;
OPT.ext_on_m = 300 ;
OPT.z_on = z(1) ;

OPT.ext_off = 1 ;
OPT.ext_off_m = 300 ;
OPT.slope_off = -0.01 ;
OPT.ext_off_type = 1 ; % 1 - linear ; % 2 - parabola

OPT.nan_fill = 1 ;  % 1 = fill nans with interp / extrap [DEFAULT] ; 0 = do NOT fill nans

x0 = x ;
z0 = z ;

%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField',  'silentIgnore'); % 'silentIgnore' - added Mar2024 (JM)

%% DETECT AND FILL NANS

nonnan_i = find(~isnan(z0)) ;
isgood = false  ;
if length(nonnan_i) > 100      % check prof must have MIN 100 NON-NAN VALUES (ARBITRARY CHOICE, COULD MAKE ADJUSTABLE)
    isgood = true ;
end
OPT.isgood = isgood ;

if OPT.nan_fill == 1 & isgood
    nan_i = find(isnan(z0)) ;
    OPT.nan_i = nan_i ;
end

if OPT.nan_fill == 1 & isgood
    nan_i = find(isnan(z0)) ;

    first_i = find(~isnan(z0), 1, 'first')   ;
    OPT.z_on = z0(first_i) ;
    last_i  = find(~isnan(z0), 1, 'last')    ;

    nan_on_i = find(isnan(z0) & x0 < x0(first_i) )  ;
    nan_off_i = find(isnan(z0) & x0 > x0(last_i) )  ;
    nan_mid_i_01 = isnan(z0) & x0 > x0(first_i) & x0 < x0(last_i)  ;
    nan_mid_i = find(nan_mid_i_01) ;

end

if isgood & OPT.nan_fill == 1
    % ONSHORE NANS ---> fill with first good value
    if ~isempty(nan_on_i)
        z0(nan_on_i) = z0(first_i) ;
    end
    
    % OFFSHORE NANS --> fill with linear slope
    if ~isempty(nan_off_i) 
    
        z_off_nan = linspace(OPT.slope_off, OPT.slope_off*length(nan_off_i) , length(nan_off_i)  )'  ;
        z0(nan_off_i) = z_off_nan + z(last_i) ;
    
    end
    
    % MID-NANS   -----> Linear interp over mid-prof gaps
    if ~isempty(nan_mid_i) 
        ind = nan_mid_i_01 ;
        z0 = interp1(x0(~ind), z0(~ind), x0) ;
    end


end

%% EXTEND ONSHORE

if OPT.ext_on == 1

    x0 = [1 : length(x) + OPT.ext_on_m]' ;
    z0 = [repmat(OPT.z_on, [OPT.ext_on_m,1]); z0] ;

end


%% EXTEND OFFSHORE

if OPT.ext_off == 1
    x0 = [1 : length(x0) + OPT.ext_off_m]' ;

    if OPT.ext_off_type == 1   % LINEAR SLOPE
        z_off = linspace(OPT.slope_off, OPT.slope_off*OPT.ext_off_m, OPT.ext_off_m)'  ;
    
    elseif OPT.ext_off_type == 2   % PARABOLIC SLOPE
        X_poly2 = @(YY, m2,a, m1,b) m2.*(YY + a).^2 + m1.*YY + b ;  
        
        dz = OPT.slope_off ;
        dip_ratio = -dz/10   ;  % curve of line (ratio)
        dip1 = dip_ratio .* length(x)  ;  % curve (magnitude)
        
        a = -length(x)/2 ;           % parabola x-intercept (offset, x-axis)
        m2 = dip1 / a^2 ;        % parabola magnitude
        b2 = dip1    ;           % parabola - y-int (offset, y-axis) 
        b1 = 0 ;      % X-intercept (combined line and parabola)
            % set b1 = 0 to get the 'left half' of a parabola, touching the x-axis on the last pt
        m1 = dz ;     % gradient of line
        z_off = X_poly2(x,  m2, a,   m1,  b1 - b2) ;
    end

    z_off = z_off + z0(end) ;
    z0 = [z0; z_off] ;
end

%% 

end


%%





%%


%%


