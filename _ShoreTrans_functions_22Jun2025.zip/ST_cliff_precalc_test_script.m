
%% SCRIPT TO TEST FUNCTION [ST_CLIFF_PRECALC]

%% ST_cliff_precalc  ---> FEB 2025
% Calculates cliff recession, based on Ashton2011 --> outside of running ShoreTrans (no profile info needed)
%
% Inputs
%   OPT.SLR_rate0  ---> initial rate of SLR (m/yr) --> if empty, default = 0.003 m = 3 mm]
%   OPT.dS  ---> amount of SLR
%   OPT.dt  ---> time period [years]
%   OPT.REC_rate0  ---> initial cliff recession rate
%   OPT.m_val    ----> m-coefficient [default = 0.5]
% 
% Outputs [clf = OPT ---> then add the calculated vars]
%   clf.SLR_rate1 --> final SLR rate (m/yr)
%   clf.REC_rate1 --> final cliff recession rate (m/yr)
%   clf.REC_rate_av --> avg cliff rec rate     ([rate0 + rate1]/2 )

% function [clf] = ST_cliff_precalc(varargin)




%%
clc

OPT.dS = 1.2 ;
OPT.dt = 90 ;
OPT.SLR_rate0 = 0.002 ; % m/yr
OPT.m_val = 0.3 ;
OPT.REC_rate0 = 0.1   ; 

[clf] = ST_cliff_precalc(OPT)  ;

disp(['Average cliff recession rate is ' num2str(clf.REC_rate_av, '%0.4f') ' m/yr']) ;





%%