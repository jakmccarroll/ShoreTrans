%% [shore1] = ST_groyne_2_profs(shore, groyne, profs, T_chain, OPT) - Apr 2024
% Input a groyne-modified shoreline and profiles...
% ... run ST_GROYNE_1_GEOM first
% Output a new profiles and shoreline modified by
% 

function [shore1, prof1, OPT] = ST_groyne_2_profs(shore, prof, T_chain, varargin)


%% SET DEFAULTS (input 'OPT' to varargin when calling function) 

OPT.ST_OPT = []  ; % ST_MAIN OPTIONS
OPT.vx = [] ;
OPT.SHR = [] ;
OPT.dY = 30 ; % alongshore distance between transects

%% [OPT] SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'silentIgnore'); 

if isempty(OPT.ST_OPT)
    ST_OPT = ST_OPT_defaults ;
    ST_OPT.optimizer = 0 ; 
    ST_OPT.dS = 0 ; 
else
    ST_OPT = OPT.ST_OPT;
end

if isempty(OPT.vx)
    vx = [];
    vx.Z1 = 2;           % TOP of beachface
    vx.Z2 = 0.3;           % BOTTOM of BEACHFACE (take angle from TOP to MID and shift onshore)
    vx.Z3 = -1;          % PIVOT pt (join translated MID to original PIVOT pt)
    vx.Z4 = -8;          % BOTTOM of STORM BAR pt (lost volume shifted as a sine curve offshore to 
    vx.err_offset =  (vx.Z1 - vx.Z2)  ;
else
    vx = OPT.vx ;
end

if isempty(OPT.SHR)
    SHR = [] ;
    SHR.z_cont = 1
    SHR.z_in = 'z2'   ; % input 
    SHR.x_out = 'x2'  ; % output x-coord fieldname in SHORE
    SHR.y_out = 'y2'  ; % output y-coord 
    SHR.X_min_shr = -100 ; % shoreline must be offshore of this chainage distance
    SHR.X_max_shr =  100 ; % shoreline must be onshore of this chainage distance

else
    SHR = OPT.SHR  ;

end


%% GET VARS
up_ind = shore.up_ind ;
TID_up = shore.TID(up_ind)   ;
dX1    = shore.dX1 ;


%% LOOP UP-DRIFT PROFS (UP_IND)
for i = 1 : length(prof)  %   length(up_ind)
    TID_ii = prof(i).TID   ;
    dX1_i = dX1(i)    ;

    if ismember(TID_ii, TID_up )
        Xi = dX1_i ;
        ST_OPT.X_off = Xi   ;
        ST_OPT.X_on  = Xi    ;

        x0 = prof(TID_ii).X0  ;       z0 = prof(TID_ii).z0   ;
        [~, outPROFS, ST_OPT] = ST_MAIN(x0, z0, 0, ST_OPT)  ;
        z1 = outPROFS.z_final ;
        dV1 = outPROFS.dV ;

        buf = 20; % interp distance (buffer)
        sti = shore.X_ind1(i)  ;  % start X-index of interp
        eni = sti + buf   ;           % end   indes of interp
        ii = [sti : eni]  ;

        z2 = z1;
        z2(ii) = interp1(  x0([sti, eni])  , [z1(sti), z0(eni)], x0(ii)   )  ;
        z2(eni:end) = z0(eni:end)   ;
        V_z0 = trapz(z0) ;
        V_z2 = trapz(z2) ;
        dV = V_z2 - V_z0;
        dV_err = [];

        S = struct('z1', z1, 'z2', z2, 'dV', dV, 'dX', Xi, 'dV_err', dV_err) ;
        prof(i) = add_vars2struct(prof(i), S);

    else
        z0 = prof(i).z0;
        prof(i).z1 = z0;        prof(i).z2 = z0;        
        prof(i).dV = 0;   prof(i).dX = 0;
        prof(i).dV_err = [];
    end
end


%% VOL CALCS (1) -- NORMALISE VOLUME LOSS ACROSS DOWNDRIFT
dV_up_tot = sum([prof.dV])  ;

X_dn1 = shore.X_dn ;
X_dn_norm = X_dn1 ./ sum(X_dn1)  ;
dn_vx_targ = X_dn_norm .* dV_up_tot  ;

%%  LOOP DOWNDRIFT EROSION (USING STORM VX)
TID_dn = shore.TID(shore.dn_ind)   ;

for i = 1 : length(TID_dn)

    TID_ii = shore.dn_ind(i)   ;
  
    x0 = prof(TID_ii).X0       ;
    z0 = prof(TID_ii).z0      ;

    vx.dV_target = -dn_vx_targ(i)          ;

    [vx] = ST_VARBX(x0', z0', vx, ST_OPT)   ; 
    z1 = vx.z_final;
    z2 = z1;
    z2([vx.i3 : vx.i4]) = z0([vx.i3 : vx.i4])  ;
    prof(TID_ii).z1 = z1;
    prof(TID_ii).z2 = z2;
    prof(TID_ii).dV = vx.dV;
    prof(TID_ii).dX = vx.dX;
    prof(TID_ii).dV_err = vx.dV - vx.dV_target;
end

%% VOL CALCS (2) -- FINAL SHORELINE + TOTAL VOLUME ERROR

[shore2] = prof2shr(prof, T_chain, SHR)  ;
shore.x2 = shore2.x2; shore.y2 = shore2.y2;

prof_dV = [prof.dV]'     ;

dV_tot_up = nansum(prof_dV(shore.up_ind)) .* OPT.dY ;
dV_tot_dn = nansum(prof_dV(shore.dn_ind)) .* OPT.dY ;

dV_tot_err = dV_tot_up + dV_tot_dn    ;

% dV_err_per_m = dV_tot_err ./ OPT.dY ;
dV_err_per_m = nansum(prof_dV) ;

%% ASSIGN OUTPUTS
S = struct('X_dn_norm', X_dn_norm, 'dn_vx_targ', dn_vx_targ, ...
    'dV_tot_up', dV_tot_up, 'dV_tot_dn', dV_tot_dn, 'dV_tot_err', dV_tot_err, ...
    'dV_err_per_m', dV_err_per_m) ;
shore = add_vars2struct(shore, S)   ;

% shore.dV_up_tot = dV_up_tot ;
% shore.X_dn_norm
% shore.dn_vx_targ

shore1  = shore ;
prof1   = prof ;
% groyne1 = groyne ;



%%



%%


%% FUNCTION END
end