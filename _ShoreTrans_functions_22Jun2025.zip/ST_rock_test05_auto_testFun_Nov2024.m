%% VS1_ST_rock_test05_auto_testFun_Nov2024 ----> NOV 2024
% test function [ST_ROCK_AUTO_CLASSIFY_SUBTIDE]

% CCC
HST_Dir
cd(Dir.ST_scripts)
Dir.data1 = fullfile(Dir.data, 'VCMP_Sites', 'cliff_detect_prof_extend') ;
Dir.images = fullfile(Dir.ST, 'images', 'rock05_auto_subt'); mkdir(Dir.images) ;
cd(Dir.images) ;

Site_ID = 27  ;

%% LOAD SITE1 -- FUNCTION CLIFF TO/CR DETECT (1 PROF)
OPT0 = [] ;
OPT0.Site_ID  = Site_ID ;   % SELECT SITE (DEMONS BLUFF EXAMPLE)
OPT0.load_OMNI = 1   ;
OPT0.load_CAMS = 1   ;
OPT0.load_rock_polys = 1 ;
OPT0.load_profs_mrg = 1 ;
[Sites, Site1] = VS1_loading_suite_sites(Dir, OPT0)   ;
VS1_load_get_Site1_vars   ;

SID1 = length(SID) ;

OPT = [];
OPT.SID1 = SID1 ;
prof = VS1_load_get_prof_from_mrg2(Site1, OPT);
clear OPT ;

%% ================ %% TEST 1 PROF ===================== %%

%% TEST 1 PROF ---> SELECT TID1
TID1 = 10
x0 = prof(TID1).X0 ;
z0 = prof(TID1).z ;

z00 = z0 ;

%% MODIFY PROF TO CHECK FOR ERRORS

% TESTING (MGO) TID1 = 15
% z0(400:end) = z0(399) ; % make profile that does NOT get BELOW DoC
% z0(1:157) = 2 ; % make profile that does NOT get ABOVE DUNE TOE

%% PLOT01 --> CHECK INPUT PROF

close all, f1 = figure(1), figpos(0, .2 , .5 , .7), hold on
legend(gca, '-dynamicLegend') ;
plot(x0, z00, ':', 'color', [.6 .6 .6], 'displayname', 'z00') ;
plot(x0, z0, '--', 'color', [0 0 0], 'displayname', 'z0') ;

%% TEST 1 PROF ---> SET [ROCKIND] OPT
OPT.st_z = -1.5  ;   % start of subtidal zone (elevation)
OPT.st_i = [] ;      % start of subtidal zone (index)

OPT.en_z = -10  ;    % end of subtidal zone (elevation)
OPT.en_i = [] ;      % end of subtidal zone (index)   ----> USE IF APPLYING ROCK CHECK ONLY TO DoC [i.e., OPT.go_to_end = false]

OPT.go_to_end = true  ;  % apply rock check to end of profile (if FALSE, do NOT allow rock offshore of OPT.en_i) 

OPT.gap_max = 100 ;         % join rock sections with gaps between less than [GAP_MAX]
OPT.sec_min = 10 ;         % delete rock sections with extent less than [SEC_MIN]
OPT.dz_limit = 0.1  ;  % threshold slope per metre cross-shore (above this, class as rock)


%% TEST 1 PROF ---> CALL [ROCKIND] FUN
clc
[rockInd, OPT] = ST_rock_auto_classify_subtide(x0, z0, OPT) ;

z1 = rockInd.z1 ;


%% PLOT02 ----> CHECK OUTPUT - 1 TEST PROF
xlim1 = [0 1200] ;
ylim1 = [-25 12] ;

try, close(2), end
f2 = figure(2), figpos(0,.05,.6,.7), hold on ;
title(['Auto-detect ROCK in SUBTIDAL, ' num2str(Site_ID) '-' meta.name1 ', TID-' num2str(TID1) 10 ])  ;

legend(gca, '-dynamicLegend', 'location', 'northeast') ;
plot(x0, z0, 'k', 'displayname', 'z0', 'linewidth', 1) ;
plot([x0(1) x0(end)], [0 0], 'b:', 'displayname', 'MSL', 'linewidth', 1) ;

plot(x0, z1, 'r.', 'markersize', 15, 'displayname', 'rockInd') ;

%% ===================================== %%

%% ============= RUN ALL PROFS ================== %%

%% SET [ROCKIND] OPT
OPT.st_z = -1.5  ;   % start of subtidal zone (elevation)
OPT.st_i = [] ;      % start of subtidal zone (index)

OPT.en_z = -10  ;    % end of subtidal zone (elevation)
OPT.en_i = [] ;      % end of subtidal zone (index)   ----> USE IF APPLYING ROCK CHECK ONLY TO DoC [i.e., OPT.go_to_end = false]

OPT.go_to_end = true  ;  % apply rock check to end of profile (if FALSE, do NOT allow rock offshore of OPT.en_i) 

OPT.gap_max = 100 ;         % join rock sections with gaps between less than [GAP_MAX]
OPT.sec_min = 10 ;         % delete rock sections with extent less than [SEC_MIN]
OPT.dz_limit = 0.1  ;  % threshold slope per metre cross-shore (above this, class as rock)


%% SET PLOT OPTIONS
xlim1 = [0 1200] ;
ylim1 = [-25 12] ;

%% LOOP START
cd(Dir.images) ;

for k =   25   : length(TID)
    k

    TID1 = k ;
    x0 = prof(TID1).X0 ;
    z0 = prof(TID1).z ;

    %% call [ROCKIND] FUN
    [rockInd, OPT] = ST_rock_auto_classify_subtide(x0, z0, OPT) ;

    z1 = rockInd.z1 ;
    st_i = OPT.st_i ;
    en_i = OPT.en_i ;

    %% PLOT03 --> ZONES for PROF (LOOP through FULL SITE + SAVE)
    if rockInd.is_good
        try, close(3), end
        f3 = figure(3), figpos(0,.05,.6,.7), hold on ;
        title(['Auto-detect ROCK in SUBTIDAL, ' num2str(Site_ID) '-' meta.name1 ', TID-' num2str(TID1) 10 ])  ;
        
        legend(gca, '-dynamicLegend', 'location', 'northeast') ;
        plot(x0, z0, 'k', 'displayname', 'z0', 'linewidth', 1) ;
        plot([x0(1) x0(end)], [0 0], 'b:', 'displayname', 'MSL', 'linewidth', 1) ;
        
        plot(x0, z1, 'r.', 'markersize', 15, 'displayname', 'rockInd') ;
        plot(x0(st_i), z0(st_i), 'ko', 'markersize', 10, 'markerfacecolor', 'g', 'displayname', 'sub-st-i') ;    
        plot(x0(en_i), z0(en_i), 'ks', 'markersize', 10, 'markerfacecolor', 'y', 'displayname', 'sub-en-i') ;    
    end

    %% SAVE PLOT03
    fname = [num2str(Site_ID) '-' meta.UAV_prefix '_autoRockSubt_TID-' num2str(k, '%02d') '.png'] ;
    print(fname, '-dpng','-r150') ;

%% END LOOP
end

%%




%%