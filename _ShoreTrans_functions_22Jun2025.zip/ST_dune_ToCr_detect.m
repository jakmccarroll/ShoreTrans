%% ST_dune_ToCr_detect --> DEC 2024
% input a profile, find [DUNE BACK-TOE, CREST, TOE] --> determine if translation type is ROLLOVER or ENCROACH

function [ToCr, OPT] = ST_dune_ToCr_detect(x0, z0, varargin)



%% SET DEFAULTS (OPT)

OPT.To_z_lvl = 2.5 ;
OPT.Bk_z_lvl = 2   ;
OPT.Bk_allow_ToCr = false ;   % allow BACK-TOE to be used for translation point

OPT.Cr_z_max = 10 ;
OPT.Cr_x_rng = 200 ;

OPT.default_type = 0 ;  % if translation type is indeterminate, default to [1-ROLLOVER ; 0-ENCROACH ] ;

%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'warnAppend'); 
% [OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'silentIgnore'); 



%% FIND TOE (offshore side)
To_ind = find(z0 > OPT.To_z_lvl, 1 , 'last') + 1 ;

% if To_ind > length(OPT.To_z_lvl) 
%     To_ind = length(OPT.To_z_lvl) ;
% end

if To_ind > length(z0) 
    % To_ind = length(z0) ;
    To_ind = [] ;
end

To_x = x0(To_ind) ;
To_z = z0(To_ind) ;

%% Modified (z) --> z1 (nan offshore of TOE)  ; z2 (nan onshore of Cr_x_rng)
z1 = [] ; z2 = [] ;
if ~isempty(To_ind)
    z1 = z0 ;
    z1(To_ind : end) = nan ;
    % z1 = z0(1 : To_ind) ;
    z2 = z1 ;
    z2(1 : To_ind - OPT.Cr_x_rng) = nan ;
end

%% FIND BACK-TOE (onshore side)

Bk_ind = [] ;
Bk_x = [] ;
Bk_z = [] ;

if ~isempty(To_ind)
    Bk_ind = find(z1 < OPT.Bk_z_lvl, 1, 'last') ;
    Bk_x = x0(Bk_ind) ;
    Bk_z = z0(Bk_ind) ;
end

% if ~isempty(Bk_ind)
%     ToCr_opt = 1 ;
% end

%% FIND CREST
Cr_ind = [] ; Cr_x = [] ; Cr_z = [] ;
Cr_ind_1 = [] ; Cr_z_1 = [] ;

if ~isempty(To_ind) && ~isempty(Bk_ind)
    ind1 = [Bk_ind : To_ind] ;
    [~, ind2] = max(z0([Bk_ind : To_ind])) ;
    Cr_ind_1 = ind1(ind2) ;
    % Cr_x_1   = x0(Cr_ind_1) ;
    Cr_z_1   = z0(Cr_ind_1) ;   

elseif ~isempty(To_ind)

    [pks, locs] = findpeaks(z2) ;
    if ~isempty(pks)
        Cr_ind_1 = locs(end) ;
        % Cr_x_1   = x0(Cr_ind_1) ;
        Cr_z_1   = z0(Cr_ind_1) ;   
    end

end

%% ADJUST CREST --> IF TOO HIGH

if ~isempty(Cr_z_1)
    if Cr_z_1 > OPT.Cr_z_max    % CREST over MAX ALLOWABLE
        Cr_ind = find(  z0 >= OPT.Cr_z_max   &   x0 >= x0(Cr_ind_1), 1, 'last') + 1  ;
        % ToCr_opt = 2 ;  % if CREST IS LOWERED, that becomes the ST_ToCr POINT (using BACK_TOE will shift the TOO HIGH DUNE)
        Cr_1_too_high = true ;
    else
        Cr_1_too_high = false ;
        Cr_ind = Cr_ind_1 ;
    
    end
    Cr_x   = x0(Cr_ind) ;
    Cr_z   = z0(Cr_ind) ;
end


%% SET FINAL ToCr_OPT 
ToCr_opt = [] ;

if ~isempty(Bk_ind)  &&  ~Cr_1_too_high   &&  OPT.Bk_allow_ToCr
    ToCr_opt = 1 ;
    
elseif  ~isempty(Cr_ind)
    ToCr_opt = 2 ;

elseif ~isempty(To_ind)
    ToCr_opt = 3 ;

end


%% SET To/Cr for SHORETRANS

if ToCr_opt == 1    %   ~isempty(Bk_ind)
    ST_ToCr_opt = ToCr_opt ;
    ST_rollover = 1 ;
    ST_ToCr_ind = Bk_ind ;

elseif ToCr_opt == 2     % ~isempty(Cr_ind)
    ST_ToCr_opt = ToCr_opt ;
    ST_rollover = 1 ;
    ST_ToCr_ind = Cr_ind ;

elseif ToCr_opt == 3     % ~isempty(To_ind)
    ST_ToCr_opt = ToCr_opt ;
    ST_rollover = 0 ;    
    ST_ToCr_ind = To_ind ;

else
    ST_ToCr_opt = [] ;
    ST_rollover = [] ;    
    ST_ToCr_ind = [] ;

end


%% SET OUTPUTS

struct_name = 'ToCr' ;
vars = {'Bk_ind', 'Bk_x', 'Bk_z', ...
    'Cr_ind_1', 'Cr_z_1', ...
    'Cr_ind', 'Cr_x', 'Cr_z', ...
    'To_ind', 'To_x', 'To_z', ...
    'ST_ToCr_opt', 'ST_rollover', 'ST_ToCr_ind' }' ;
    % 'z1', 'z2'}' ;
  
struct_addVars_eval ;

% struct_addVars_eval is a SCRIPT
% for i = 1 : length(vars)
%     str1= char(vars{i}) ;
%     eval([struct_name '.' str1 ' = ' str1 ])
% end



%% END FUNCTION
end





%%










































