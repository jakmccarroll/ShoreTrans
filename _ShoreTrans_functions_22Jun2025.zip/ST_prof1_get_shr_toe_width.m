%% function [prof1] = ST_prof1_get_shr_toe_width(x0, z0, OPT)


function [toe_i, shr_i, bw, OPT] = ST_prof1_get_shr_toe_width(x0, z0, varargin)


%% SET DEFAULTS (OPT)
OPT.min_xi =  1  ;            % MIN INDEX (SHORE + TOE MUST BE OFFSHORE OF HERE)
OPT.max_z_check = true ;      % If TRUE --> [SHORE] and [TOE] MUST BE OFFSHORE OF Z_MAX

OPT.shr_level = 0 ;       % SHORELINE ELEVATION
OPT.toe_level = 2.5 ;     % TOE ELEVATION

%% SETPROPERTY -> available with openEarthTools (Deltares)
[OPT, OPT.Set, OPT.Default] = setproperty(OPT, varargin, 'onExtraField', 'silentIgnore'); 


%% max_z_check

if OPT.max_z_check
    [~, max_zi] = max(z0) ;
else
    max_zi = 1 ;
end


%% INDEX TOE + SHORE

toe_i = find(z0 <= OPT.toe_level   & x0 >= x0(OPT.min_xi)  & x0 > x0(max_zi) , 1 , 'first') ;
shr_i = find(z0 <= OPT.shr_level   & x0 >= x0(OPT.min_xi)  & x0 > x0(max_zi) , 1 , 'first') ;

 
%% GET BEACH WIDTH

if ~isempty(toe_i) && ~isempty(shr_i)
    bw = shr_i - toe_i ;
else
    bw = nan ;
end


%% OUTPUTS




%%